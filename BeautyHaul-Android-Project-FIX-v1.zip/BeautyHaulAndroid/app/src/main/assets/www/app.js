
const BEAUTYHAUL_LOGO="https://is1-ssl.mzstatic.com/image/thumb/Purple221/v4/9d/d4/ad/9dd4ad1f-4d0f-8f5c-ac96-5f4cb431aba5/AppIcon-0-0-1x_U007emarketing-0-11-0-85-220.png/1200x630wa.png";
const SUPABASE_URL="https://gjpzzcdsmkdpbbeklcbq.supabase.co";
const SUPABASE_KEY="sb_publishable_d27_xupd2CBxXYe9GBMVAA_Af-7mhI3";
const sb=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY);

const TASKS=[{"name":"POND'S – Bright Miracle Ultimate Oil Control Facial Whip Foam 100G","price":17900,"profit":3580,"emoji":"🧴","store":"BeautyHaul Store","qty":1,"location":"Pelaihari","image":"assets/img-e27b857386ed5087.jpg","id":"SC-2601298YHD2BD","status":"hidden"},{"name":"POND'S – Bright Miracle Ultimate Oil Control Facial Whip Foam 100G","price":35800,"profit":7160,"emoji":"🧴","store":"BeautyHaul Store","qty":1,"location":"Pelaihari","image":"assets/img-b098606e03d19759.jpg","id":"SC-2601298HGVH37","status":"hidden"},{"name":"REXONA – DEODORANT ROLL...","price":9640,"profit":5784,"emoji":"🧴","store":"BeautyHaul Store","qty":3,"location":"","image":"assets/img-0f7c8360b5d2b348.jpg","id":"SC-260129A1B2C3D4","status":"hidden"},{"name":"POND'S – Bright Miracle Ultimate Oil Control Facial Whip Foam 100G","price":35800,"profit":7160,"emoji":"🧴","store":"BeautyHaul Store","qty":1,"location":"Pelaihari","image":"assets/img-b098606e03d19759.jpg","id":"SC-260129P04H10","status":"hidden"},{"name":"REXONA – WOMEN","price":30200,"profit":6040,"emoji":"🧴","store":"BeautyHaul Store","qty":1,"location":"","image":"assets/img-139aa4eaaf9b4f10.jpg","id":"SC-260128R05X07","status":"hidden"},{"name":"POND'S – Bright Miracle Ultimate Oil Control Facial Whip Foam 100G","price":35800,"profit":7160,"emoji":"🧴","store":"BeautyHaul Store","qty":1,"location":"Pelaihari","image":"assets/img-b098606e03d19759.jpg","id":"SC-260129P06H12","status":"hidden"},{"name":"REXONA – WOMEN","price":30200,"profit":6040,"emoji":"🧴","store":"BeautyHaul Store","qty":1,"location":"","image":"assets/img-139aa4eaaf9b4f10.jpg","id":"SC-260128R07X09","status":"hidden"},{"name":"POND'S – Bright Miracle Ultimate Oil Control Facial Whip Foam 100G","price":35800,"profit":7160,"emoji":"🧴","store":"BeautyHaul Store","qty":1,"location":"Pelaihari","image":"assets/img-b098606e03d19759.jpg","id":"SC-260129P08H14","status":"hidden"},{"name":"REXONA – WOMEN","price":30200,"profit":6040,"emoji":"🧴","store":"BeautyHaul Store","qty":1,"location":"","image":"assets/img-139aa4eaaf9b4f10.jpg","id":"SC-260128R09X11","status":"hidden"},{"name":"POND'S – Bright Miracle Ultimate Oil Control Facial Whip Foam 100G","price":35800,"profit":7160,"emoji":"🧴","store":"BeautyHaul Store","qty":1,"location":"Pelaihari","image":"assets/img-b098606e03d19759.jpg","id":"SC-260129P10H16","status":"hidden"}];

const DEMO_PUBLIC_WITHDRAWALS = [
  {name:"Muha***", amount:500000},{name:"Caro***", amount:70000},{name:"Sisk***", amount:1250000},{name:"Jeni***", amount:85000},{name:"Mars***", amount:2100000},{name:"Sand***", amount:930000},{name:"Kean***", amount:450000},{name:"Berl***", amount:12450000},{name:"Prat***", amount:3850000},{name:"Chik***", amount:130000},{name:"Aish***", amount:520000},{name:"Thal***", amount:450000},{name:"Saro***", amount:1370000},{name:"Elis***", amount:320000},{name:"Fati***", amount:4130000},{name:"Lili***", amount:210000},{name:"Ning***", amount:8240000},{name:"Siti***", amount:300000},{name:"Sals***", amount:5100000},{name:"Made***", amount:470000},{name:"Bell***", amount:680000},{name:"Kart***", amount:9210000}
].map((x,i)=>({...x,date:new Date(Date.now()-i*60000).toISOString()}));

let state={
 balance:Number(localStorage.getItem("bh_balance")||0),
 tasks:JSON.parse(localStorage.getItem("bh_tasks")||"null")||TASKS.map(x=>({...x})),
 tx:JSON.parse(localStorage.getItem("bh_tx")||"[]"),
 bank:JSON.parse(localStorage.getItem("bh_bank")||"null"),
 vouchers:Number(localStorage.getItem("bh_vouchers")||0),
 currentTaskIndex:Number(localStorage.getItem("bh_task_index")||0),
 publicWithdrawals:DEMO_PUBLIC_WITHDRAWALS.map(x=>({...x}))
};
let currentUser=null,currentPage="home",orderTab="available";

// V12: Dompet dibuat benar-benar terpisah per akun Supabase.
// Akun baru tidak boleh melihat transaksi/saldo/rekening/voucher milik akun lama.
const WALLET_SCOPE_VERSION="v17-supabase-wallet";
// profiles schema confirmed: id, full_name, email, phone, role, create_at.
// Completed-order persistence therefore uses Supabase Auth user_metadata.
function walletScopeId(){
  const u=currentUser||{};
  const uid=String(u.id||"").trim();
  if(uid)return "uid_"+uid.replace(/[^a-zA-Z0-9_-]/g,"");
  const email=String(u.email||"").trim().toLowerCase();
  if(email)return "em_"+email.replace(/[^a-z0-9]+/g,"_").slice(0,80);
  return "guest";
}
function walletStorageKey(){return "bh_wallet_"+WALLET_SCOPE_VERSION+"_"+walletScopeId();}
function voucherStorageKey(){return "bh_used_vouchers_"+WALLET_SCOPE_VERSION+"_"+walletScopeId();}
function walletBalanceStorageKey(){return "bh_wallet_balance_"+WALLET_SCOPE_VERSION+"_"+walletScopeId();}
function calculateLedgerBalance(tx){
  if(!Array.isArray(tx))return 0;
  return tx.reduce((sum,row)=>{
    const amount=Number(row?.amount)||0;
    if(row?.type==="plus")return sum+amount;
    if(row?.type==="minus")return sum-amount;
    return sum;
  },0);
}
function calculateBusinessWalletBalance(){
  // Saldo bisnis dihitung dari sumber dana akun + hasil bersih pesanan.
  // Untuk pesanan yang SUDAH SELESAI, pembayaran dan pengembalian dana saling
  // menghapus; yang benar-benar menambah saldo hanyalah komisi.
  // Ini mencegah transaksi refund/komisi lama terhitung dua kali setelah refresh.
  const tx=Array.isArray(state.tx)?state.tx:[];
  let balance=0;

  // Semua transaksi yang bukan transaksi pesanan menjadi bagian ledger biasa:
  // voucher, deposit yang sudah dikreditkan, penarikan, dan penyesuaian lain.
  let voucherLedgerTotal=0;
  for(const x of tx){
    if(!x || x.type==="pending") continue;
    const hasOrder=!!String(x.orderId||"").trim();
    if(hasOrder) continue;
    const amount=Math.max(0,Number(x.amount)||0);
    if(x.type==="plus") balance+=amount;
    else if(x.type==="minus") balance-=amount;
    if(x.type==="plus" && String(x.name||"").startsWith("Voucher ")) voucherLedgerTotal+=amount;
  }

  // Jika versi lama pernah menyimpan klaim voucher di daftar penggunaan tetapi
  // tidak menulis transaksi voucher, pulihkan modal voucher satu kali.
  // Transaksi voucher yang sudah ada tidak dihitung dua kali.
  try{
    const voucherValues={HFDJXI:30000,MXKSOA:250000,NJNXSJ:750000,NDJJDC:2500000};
    const claimed=getUsedVouchersForCurrentAccount();
    const claimedTotal=claimed.reduce((sum,code)=>sum+(voucherValues[code]||0),0);
    if(claimedTotal>voucherLedgerTotal) balance += claimedTotal-voucherLedgerTotal;
  }catch(_){}

  // Pesanan dihitung berdasarkan status bisnis, bukan dengan menjumlahkan
  // refund + komisi sebagai dua keuntungan.
  const seen=new Set();
  for(const t of (Array.isArray(state.tasks)?state.tasks:[])){
    if(!t || !t.id || seen.has(String(t.id))) continue;
    seen.add(String(t.id));
    const principal=Math.max(0,Number(t.price||0)*Number(t.qty||1));
    const profit=Math.max(0,Number(t.profit||0));
    if(t.status==="done"){
      balance+=profit;
    }else if(["active","shipping","processing_wait"].includes(t.status)){
      const paid=tx.some(x=>x && x.type==="minus" && String(x.orderId||"")===String(t.id));
      if(paid) balance-=principal;
    }
  }
  return Math.max(0,Math.round(balance));
}

function syncWalletBalanceFromLedger(){
  // Setelah wallet Supabase berhasil dimuat, saldo database adalah sumber
  // kebenaran. Ledger hanya dipakai sebagai fallback/migrasi jika belum ada
  // wallet server yang terverifikasi. Ini mencegah saldo lama berubah menjadi
  // hanya total komisi saat halaman di-refresh.
  let value;
  if(state.walletDbLoaded){
    value=Math.max(0,Number(state.balance)||0);
  }else{
    value=calculateBusinessWalletBalance();
    state.balance=value;
    try{saveWalletForCurrentAccount();}catch(e){console.warn('Sinkronisasi saldo lokal gagal:',e)}
  }
  const home=document.getElementById('homeBalance');
  const wallet=document.getElementById('walletBalance');
  if(home)home.textContent=rupiah(value);
  if(wallet)wallet.textContent=rupiah(value);
  return value;
}

function forceWalletBalanceUI(){
  const value=Math.max(0,Number(state.balance)||0);
  const formatted=rupiah(value);
  const home=document.getElementById("homeBalance");
  const wallet=document.getElementById("walletBalance");
  if(home) home.textContent=formatted;
  if(wallet) wallet.textContent=formatted;
  try{
    saveWalletForCurrentAccount();
    localStorage.setItem(walletBalanceStorageKey(),String(value));
  }catch(_){}
  return value;
}

async function reSyncWalletAfterVoucher(expectedBalance){
  // Read the authoritative row again and repaint the visible balance.
  // Several short retries protect against a slow content:// browser/network
  // and against another initialization pass finishing after the voucher claim.
  const expected=Math.max(0,Number(expectedBalance)||0);
  const waits=[0,250,750,1500,3000];
  for(const wait of waits){
    if(wait) await new Promise(r=>setTimeout(r,wait));
    try{
      if(!currentUser?.id) break;
      const {data,error}=await sb.from("wallets")
        .select("balance,total_commission,updated_at")
        .eq("user_id",currentUser.id)
        .maybeSingle();
      if(!error && data){
        const dbBalance=Math.max(0,Number(data.balance)||0);
        // Never display a stale lower value after a verified voucher write.
        if(dbBalance>=expected){
          state.balance=dbBalance;
          if(data.total_commission!=null) state.totalCommission=Math.max(0,Number(data.total_commission)||0);
          state.walletDbLoaded=true;
          forceWalletBalanceUI();
          return true;
        }
      }
    }catch(e){
      console.warn("Sinkronisasi saldo voucher:",e);
    }
    // At minimum keep the already-verified value visible while retrying.
    if(Number(state.balance)!==expected) state.balance=expected;
    forceWalletBalanceUI();
  }
  return Number(state.balance)===expected;
}

function getUsedVouchersForCurrentAccount(){
  if(!currentUser?.id && !currentUser?.email)return [];
  try{
    const raw=localStorage.getItem(voucherStorageKey());
    return Array.isArray(JSON.parse(raw||"[]"))?JSON.parse(raw||"[]"):[];
  }catch(e){return [];}
}
function saveUsedVouchersForCurrentAccount(list){
  if(!currentUser?.id && !currentUser?.email)return;
  localStorage.setItem(voucherStorageKey(),JSON.stringify(Array.isArray(list)?list:[]));
}
function loadWalletForCurrentAccount(){
  if(!currentUser?.id && !currentUser?.email){
    state.balance=0; state.totalCommission=0; state.tx=[]; state.bank=null; state.vouchers=0; state.walletDbLoaded=false; return;
  }
  state.walletDbLoaded=false;
  const key=walletStorageKey();
  try{
    const raw=localStorage.getItem(key);
    if(raw){
      const w=JSON.parse(raw)||{};
      state.balance=Number(w.balance)||0;
      state.totalCommission=Number(w.totalCommission)||0;
      state.tx=Array.isArray(w.tx)?w.tx:[];
      state.bank=w.bank||null;
      state.vouchers=Number(w.vouchers)||0;
      mergeDurableTxHistoryIntoState();
    }else{
      state.balance=0; state.totalCommission=0; state.tx=[]; state.bank=null; state.vouchers=0;
      mergeDurableTxHistoryIntoState();
    }
  }catch(e){
    console.warn('Dompet lokal akun tidak dapat dimuat:',e);
    state.balance=0; state.totalCommission=0; state.tx=[]; state.bank=null; state.vouchers=0;
  }
}

// Sumber saldo permanen adalah tabel wallets Supabase:
// user_id | balance | total_commission | updated_at
let __bhLastVerifiedWalletBalance=null;
let __bhLastVerifiedWalletAt=0;

async function loadWalletFromSupabase(){
  if(!currentUser?.id)return false;
  try{
    const {data,error}=await sb.from('wallets').select('*').eq('user_id',currentUser.id).maybeSingle();
    if(error){
      console.warn('Gagal membaca wallets:',error);
      return false;
    }
    if(data){
      const dbBalance=Math.max(0,Number(data.balance)||0);
      const recentVerified=(
        __bhLastVerifiedWalletBalance!=null &&
        (Date.now()-__bhLastVerifiedWalletAt)<8000
      );
      if(recentVerified && dbBalance<Number(__bhLastVerifiedWalletBalance)){
        state.balance=Number(__bhLastVerifiedWalletBalance);
        forceWalletBalanceUI();
        return true;
      }
      state.balance=dbBalance;
      state.totalCommission=Math.max(0,Number(data.total_commission)||0);
      mergeDurableTxHistoryIntoState();
      if(Object.prototype.hasOwnProperty.call(data,'completed_orders')){
        state.completedOrders=Math.max(Number(state.completedOrders)||0,Number(data.completed_orders)||0);
        try{localStorage.setItem(completedCountStorageKey(),String(state.completedOrders));}catch(_){}
      }
      state.walletDbLoaded=true;
      // Jika row wallet milik UID aktif sudah ditemukan, saldo database adalah
      // sumber kebenaran. Jangan menghitung ulang dari task/ledger lokal karena
      // data lokal bisa berasal dari versi aplikasi lama.
      saveWalletForCurrentAccount();
      return true;
    }
    const now=new Date().toISOString();
    const {error:insertError}=await sb.from('wallets').insert({
      user_id:currentUser.id,
      balance:Math.max(0,Number(state.balance)||0),
      total_commission:Math.max(0,Number(state.totalCommission)||0),
      ...(Number(state.completedOrders)>0?{completed_orders:Number(state.completedOrders)}:{}),
      updated_at:now
    });
    if(insertError){
      console.warn('Gagal membuat wallet akun:',insertError);
      return false;
    }
    state.walletDbLoaded=true;
    await persistWalletToSupabase();
    return true;
  }catch(e){
    console.warn('Wallet Supabase tidak dapat dimuat:',e);
    return false;
  }
}

async function persistWalletToSupabase(){
  if(!currentUser?.id)return false;

  // Supabase adalah sumber permanen saldo. Jangan menganggap operasi berhasil
  // hanya karena request tidak melempar exception: hasil UPDATE/INSERT wajib
  // diverifikasi kembali dari row wallets milik user yang sedang login.
  const uid=String(currentUser.id);
  const balance=Math.max(0,Math.round(Number(state.balance)||0));
  const totalCommission=Math.max(0,Math.round(Number(state.totalCommission)||0));
  const completed=Math.max(0,Math.round(Number(state.completedOrders)||0));
  const updated_at=new Date().toISOString();

  const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));

  for(let attempt=1;attempt<=3;attempt++){
    try{
      // 1) Update row yang sudah ada. UPDATE dengan .select() membuat kita
      // langsung tahu apakah RLS/policy mengizinkan perubahan row tersebut.
      const updated=await sb.from('wallets').update({
        balance,
        total_commission:totalCommission,
        updated_at
      }).eq('user_id',uid).select('*').maybeSingle();

      if(updated.error){
        console.error('UPDATE wallets gagal:',updated.error);
        if(attempt<3){ await sleep(350*attempt); continue; }
        return false;
      }

      let data=updated.data||null;

      // 2) Jika row belum ada, baru lakukan INSERT. Jangan INSERT ketika
      // UPDATE gagal karena RLS, supaya error policy tidak disamarkan.
      if(!data){
        const insertRow={
          user_id:uid,
          balance,
          total_commission:totalCommission,
          updated_at
        };
        if(completed>0)insertRow.completed_orders=completed;

        const inserted=await sb.from('wallets').insert(insertRow).select('*').maybeSingle();
        if(inserted.error){
          console.error('INSERT wallets gagal:',inserted.error);
          if(attempt<3){ await sleep(350*attempt); continue; }
          return false;
        }
        data=inserted.data||null;
      }

      if(!data){
        console.error('Wallet tidak mengembalikan row setelah UPDATE/INSERT.');
        if(attempt<3){ await sleep(350*attempt); continue; }
        return false;
      }

      // 3) Simpan completed_orders jika kolom tersebut tersedia.
      if(Object.prototype.hasOwnProperty.call(data,'completed_orders')){
        const dbCompleted=Math.max(Number(data.completed_orders)||0,completed);
        const countResult=await sb.from('wallets').update({
          completed_orders:dbCompleted,
          updated_at:new Date().toISOString()
        }).eq('user_id',uid).select('*').maybeSingle();
        if(countResult.error){
          console.error('UPDATE completed_orders gagal:',countResult.error);
          if(attempt<3){ await sleep(350*attempt); continue; }
          return false;
        }
        if(countResult.data)data=countResult.data;
      }

      // 4) Verifikasi nilai yang benar-benar tersimpan di database.
      const verify=await sb.from('wallets').select('*').eq('user_id',uid).maybeSingle();
      if(verify.error || !verify.data){
        console.error('Verifikasi wallet gagal:',verify.error||'row tidak ditemukan');
        if(attempt<3){ await sleep(350*attempt); continue; }
        return false;
      }

      const savedBalance=Math.round(Number(verify.data.balance)||0);
      const savedCommission=Math.round(Number(verify.data.total_commission)||0);
      if(savedBalance!==balance || savedCommission!==totalCommission){
        console.error('Verifikasi wallet tidak cocok:',{
          expected:{balance,total_commission:totalCommission},
          saved:{balance:savedBalance,total_commission:savedCommission}
        });
        if(attempt<3){ await sleep(350*attempt); continue; }
        return false;
      }

      state.balance=savedBalance;
      state.totalCommission=savedCommission;
      if(Object.prototype.hasOwnProperty.call(verify.data,'completed_orders')){
        state.completedOrders=Math.max(completed,Number(verify.data.completed_orders)||0);
      }
      state.walletDbLoaded=true;
      __bhLastVerifiedWalletBalance=savedBalance;
      __bhLastVerifiedWalletAt=Date.now();
      saveWalletForCurrentAccount();
      await persistTxHistoryToAuth();
      forceWalletBalanceUI();
      return true;
    }catch(e){
      console.error('Persist wallet gagal:',e);
      if(attempt<3){ await sleep(350*attempt); continue; }
      return false;
    }
  }
  return false;
}

function sanitizeTxHistory(list){
  if(!Array.isArray(list))return [];
  return list.filter(x=>x && typeof x==="object").slice(0,100).map(x=>({
    name:String(x.name||""),
    amount:Math.max(0,Number(x.amount)||0),
    type:["plus","minus","pending"].includes(x.type)?x.type:"plus",
    status:String(x.status||""),
    date:x.date||new Date().toISOString(),
    orderId:x.orderId?String(x.orderId):"",
    topupId:x.topupId?String(x.topupId):"",
    depositId:x.depositId?String(x.depositId):"",
    withdrawalId:x.withdrawalId?String(x.withdrawalId):"",
    withdrawalStatus:String(x.withdrawalStatus||""),
    refundApplied:x.refundApplied===true,
    refundAppliedAt:x.refundAppliedAt?String(x.refundAppliedAt):"",
    processedAt:x.processedAt?String(x.processedAt):"",
    description:String(x.description||"")
  }));
}

function readDurableTxHistory(){
  try{
    const raw=currentUser?.user_metadata?.bh_tx_history;
    if(Array.isArray(raw))return sanitizeTxHistory(raw);
    if(typeof raw==="string")return sanitizeTxHistory(JSON.parse(raw||"[]"));
  }catch(_){}
  return [];
}

async function persistTxHistoryToAuth(){
  if(!currentUser?.id)return false;
  const tx=sanitizeTxHistory(state.tx);
  if(!tx.length)return true;
  try{
    const result=await sb.auth.updateUser({
      data:{...(currentUser?.user_metadata||{}),bh_tx_history:tx}
    });
    if(!result.error && result.data?.user){
      currentUser=result.data.user;
      return true;
    }
    if(result.error)console.warn("Riwayat transaksi gagal disimpan:",result.error);
  }catch(e){console.warn("Riwayat transaksi gagal disimpan:",e)}
  return false;
}

function mergeDurableTxHistoryIntoState(){
  const durable=readDurableTxHistory();
  if(!durable.length)return false;
  const existing=Array.isArray(state.tx)?state.tx:[];
  const seen=new Set();
  const merged=[];
  const keyOf=x=>[
    String(x?.orderId||""),String(x?.name||""),
    String(x?.type||""),String(x?.amount||0),String(x?.date||"")
  ].join("|");
  for(const x of existing.concat(durable)){
    const key=keyOf(x);
    if(seen.has(key))continue;
    seen.add(key);
    merged.push(x);
  }
  merged.sort((a,b)=>new Date(b.date||0)-new Date(a.date||0));
  state.tx=merged.slice(0,100);
  return true;
}

function saveWalletForCurrentAccount(){
  if(!currentUser?.id && !currentUser?.email)return;
  try{
    localStorage.setItem(walletStorageKey(),JSON.stringify({
      balance:Number(state.balance)||0,
      totalCommission:Number(state.totalCommission)||0,
      tx:Array.isArray(state.tx)?state.tx:[],
      bank:state.bank||null,
      vouchers:Number(state.vouchers)||0
    }));
    localStorage.setItem(walletBalanceStorageKey(),String(Math.max(0,Number(state.balance)||0)));
  }catch(e){console.warn('Dompet akun gagal disimpan lokal:',e)}
}

let taskFlowTimer=null;
// Katalog pesanan demo mengikuti barang yang terlihat di video.
// Versi katalog memastikan data pesanan lama tidak membuat demo baru bercampur.
const TASK_CATALOG_VERSION="video-orders-v8-first-order-visible";
const savedTaskVersion=localStorage.getItem("bh_task_catalog_version");

if(savedTaskVersion!==TASK_CATALOG_VERSION){
  state.tasks=TASKS.slice(0,1).map(x=>({...x}));
  state.currentTaskIndex=0;
  localStorage.setItem("bh_task_catalog_version",TASK_CATALOG_VERSION);
  save();
}else if(!Array.isArray(state.tasks) || !state.tasks.length || state.tasks.some(t=>!t.price)){
  state.tasks=TASKS.slice(0,1).map(x=>({...x}));
  state.currentTaskIndex=0;
  save();
}else{
  state.tasks.forEach(t=>{
    if(t.status==="new")t.status="hidden";
    if(t.money && !t.profit){
      t.price=Number(t.money);
      t.profit=Math.round(Number(t.money)*0.2);
    }
  });
  save();
}
// --- PESANAN PERTAMA: selalu tersedia saat tidak ada pesanan yang sedang berjalan ---
// Setiap task mendapat ID yang stabil agar tombol Proses Pesanan tidak gagal.
state.tasks = (Array.isArray(state.tasks) ? state.tasks : []).map((t,i)=>({
  ...t,
  id: t.id || (i===0 ? "SC-2601298YHD2BD" : `SC-${String(2601298+i).padStart(7,"0")}BH`)
}));
// Untuk katalog versi ini, pesanan pertama harus muncul di tab Tersedia.
if(!state.tasks.length){
  state.tasks=TASKS.slice(0,1).map((x,i)=>({...x,id:"SC-2601298YHD2BD",status:"hidden"}));
}
if(state.tasks.length===1 && !state.tasks[0].status){
  state.tasks[0].status="hidden";
}
save();

// ===== ORDER FLOW SAFE MODE =====
// Versi ini tidak pernah menghapus bh_tasks, bh_task_index, katalog, saldo,
// transaksi, voucher, atau data akun. Progres lama harus selalu dilanjutkan.
const ORDER_FLOW_VERSION="v14-supabase-wallet-completed";
const RESET_MARK="bh_order_flow_safe_v13";
try{
  localStorage.setItem(RESET_MARK,ORDER_FLOW_VERSION);
  localStorage.setItem("bh_order_flow_version",ORDER_FLOW_VERSION);
}catch(_){}

// ===== MIGRASI & SINKRONISASI PESANAN 1 -> PESANAN 2 =====
// Versi ini TIDAK mereset akun, saldo, transaksi, voucher, atau progres.
// Pesanan pertama yang sudah selesai dipertahankan dan pesanan kedua
// ditambahkan ke akun yang sama.
const ORDER_CHAIN_VERSION="v5-fifth-order-safe-chain";
const SECOND_ORDER_ID="SC-260128T2Y3U4I5";
const FIRST_ORDER_ID="SC-2601298YHD2BD";
const SECOND_ORDER_TEMPLATE={
  name:"REXONA – WOMEN",
  price:30200,
  profit:6040,
  emoji:"🧴",
  store:"BeautyHaul Store",
  qty:1,
  location:"",
  image:"assets/img-6e2399fda765652f.png",
  id:SECOND_ORDER_ID,
  status:"hidden"
};
const THIRD_ORDER_ID="SC-260129A1B2C3D4";
const THIRD_ORDER_TEMPLATE={
  name:"REXONA – DEODORANT ROLL...",
  price:9640,
  profit:5784,
  emoji:"🧴",
  store:"BeautyHaul Store",
  qty:3,
  location:"",
  image:'assets/img-6eac520cd4cfd037.jpg',
  id:THIRD_ORDER_ID,
  status:"hidden"
};
const FOURTH_ORDER_ID="SC-2601298HGVH37";
const FOURTH_ORDER_TEMPLATE={
  name:"POND'S – Bright Miracle Ultimate Oil Control Facial Whip Foam 100G",
  price:35800,
  profit:7160,
  emoji:"🧴",
  store:"BeautyHaul Store",
  qty:1,
  location:"Pelaihari",
  image:"assets/img-5b30756dcecc4fdd.jpg",
  id:FOURTH_ORDER_ID,
  status:"hidden"
};
const FIFTH_ORDER_ID="SC-2601274BN7EBX8";
const FIFTH_ORDER_TEMPLATE={
  name:"ESQA – MINIMALIST BLURRIN...",
  price:149430,
  profit:29886,
  emoji:"💄",
  store:"BeautyHaul Store",
  qty:1,
  location:"",
  image:"assets/img-1dc8d211a4e7a2db.jpg",
  id:FIFTH_ORDER_ID,
  status:"hidden"
};
const SIXTH_ORDER_ID="SC-260128B7N8M9K0";
const SIXTH_ORDER_TEMPLATE={
  name:"POND'S – Bright Miracle Ultimate Oil Control Facial Whip Foam 100G",
  price:17900,
  profit:10740,
  emoji:"🧴",
  store:"BeautyHaul Store",
  qty:3,
  location:"",
  image:"assets/img-f75d169b318cf65b.jpg",
  id:SIXTH_ORDER_ID,
  status:"hidden"
};

const SEVENTH_ORDER_ID="SC-260126A1S2D3F4";
const SEVENTH_ORDER_TEMPLATE={
  name:"BIODERMA – MOISTURIZING...",
  price:107500,
  profit:172000,
  emoji:"🧴",
  store:"BeautyHaul Store",
  qty:8,
  location:"",
  image:"assets/img-d763e9bd538eb281.jpg",
  id:SEVENTH_ORDER_ID,
  status:"hidden"
};

const EIGHTH_ORDER_ID="SC-260127Y74HL6RV";
const EIGHTH_ORDER_TEMPLATE={
  name:"POND'S – BRIGHT MIRACLE...",
  price:17900,
  profit:17900,
  emoji:"🧴",
  store:"BeautyHaul Store",
  qty:5,
  location:"",
  image:"assets/img-2eda7f634bce170b.jpg",
  id:EIGHTH_ORDER_ID,
  status:"hidden"
};

// ===== PESANAN KESEMBILAN =====
// Ditambahkan tanpa mereset atau mengubah data Pesanan 1-8, saldo, transaksi, voucher, atau akun.
const NINTH_ORDER_ID="SC-260126P91087U6";
const NINTH_ORDER_TEMPLATE={
  name:"MAKE OVER – HOLIDAY READ...",
  price:338000,
  profit:405600,
  emoji:"💄",
  store:"BeautyHaul Store",
  qty:6,
  location:"",
  image:"assets/img-756b55bbda90e6fd.jpg",
  id:NINTH_ORDER_ID,
  status:"hidden"
};

// ===== PESANAN KESEPULUH =====
// Ditambahkan hanya sebagai tahap berikutnya. Data Pesanan 1-9, saldo, transaksi,
// voucher, akun, dan status yang sudah tersimpan tidak di-reset atau diubah.
const TENTH_ORDER_ID="SC-260127V2X3C4B5";
const TENTH_ORDER_TEMPLATE={
  name:"REXONA – DEODORANT ROLL...",
  price:9640,
  profit:1253200,
  emoji:"🧴",
  store:"BeautyHaul Store",
  qty:650,
  location:"",
  image:"assets/img-088beca94b27a299.jpg",
  id:TENTH_ORDER_ID,
  status:"hidden"
};

// ===== PESANAN KESEBELAS =====
// Ditambahkan sebagai tahap berikutnya tanpa mereset atau mengubah data
// Pesanan 1-10, saldo, transaksi, voucher, akun, atau status yang sudah tersimpan.
const ELEVENTH_ORDER_ID="SC-278129H5UI23U6";
const ELEVENTH_ORDER_TEMPLATE={
  name:"HMNS THE PERFECTION EDP...",
  price:368000,
  profit:1324800,
  profitRate:30,
  emoji:"🧴",
  store:"BeautyHaul Store",
  qty:12,
  location:"",
  image:"assets/img-a86dc716da67a312.jpg",
  id:ELEVENTH_ORDER_ID,
  status:"hidden"
};

// ===== PESANAN KEDUABELAS =====
// Ditambahkan sebagai tahap berikutnya tanpa mereset atau mengubah data
// Pesanan 1-11, saldo, transaksi, voucher, akun, atau status yang sudah tersimpan.
const TWELFTH_ORDER_ID="SC-281045C2FS23C3";
const TWELFTH_ORDER_TEMPLATE={
  name:"RHODE LIP POCKET BLUSH...",
  price:1226000,
  profit:367800,
  profitRate:30,
  emoji:"💄",
  store:"BeautyHaul Store",
  qty:1,
  location:"",
  image:"assets/img-22b195326b1f8e33.jpg",
  id:TWELFTH_ORDER_ID,
  status:"hidden"
};

// ===== PESANAN KETIGABELAS =====
// Ditambahkan sebagai tahap berikutnya tanpa mereset atau mengubah data
// Pesanan 1-12, saldo, transaksi, voucher, akun, atau status yang sudah tersimpan.
const THIRTEENTH_ORDER_ID="SC-203659G4SU02C7";
const THIRTEENTH_ORDER_TEMPLATE={
  name:"HOURGLASS UNREAL LIQUID...",
  price:569000,
  profit:682800,
  profitRate:30,
  emoji:"💄",
  store:"BeautyHaul Store",
  qty:4,
  location:"",
  image:"assets/img-d215598c4631dc5c.jpg",
  id:THIRTEENTH_ORDER_ID,
  status:"hidden"
};


// ===== PESANAN KEEMPATBELAS =====
// Ditambahkan sebagai tahap berikutnya tanpa mereset atau mengubah data
// Pesanan 1-13, saldo, transaksi, voucher, akun, atau status yang sudah tersimpan.
const FOURTEENTH_ORDER_ID="SC-214399F2IU41Z6";
const FOURTEENTH_ORDER_TEMPLATE={
  name:"YSL LOVENuDE BERRY BLU...",
  price:1743000,
  profit:5229000,
  profitRate:30,
  emoji:"💄",
  store:"BeautyHaul Store",
  qty:10,
  location:"",
  image:"assets/img-1cab5e1a06adc0f9.jpg",
  id:FOURTEENTH_ORDER_ID,
  status:"hidden"
};


// ===== PESANAN KELIMABELAS =====
// Ditambahkan sebagai tahap berikutnya tanpa mereset atau mengubah data
// Pesanan 1-14, saldo, transaksi, voucher, akun, atau status yang sudah tersimpan.
const FIFTEENTH_ORDER_ID="SC-214705Q6VL69T1";
const FIFTEENTH_ORDER_TEMPLATE={
  name:"WARDAH PAKET MAKE UP...",
  price:573000,
  profit:10314000,
  profitRate:30,
  emoji:"💄",
  store:"BeautyHaul Store",
  qty:60,
  location:"",
  image:"assets/img-151006e5dd74b7bf.jpg",
  id:FIFTEENTH_ORDER_ID,
  status:"hidden"
};

function reconcileOrderChain(){
  if(!Array.isArray(state.tasks)) state.tasks=[];

  // Pastikan pesanan pertama selalu mempunyai objek sendiri. Jangan mengganti
  // task yang sudah ada karena status/payment/completedAt harus dipertahankan.
  let first=state.tasks.find(t=>t && String(t.id||'')===FIRST_ORDER_ID);
  if(!first){
    const legacy=state.tasks.find(t=>t && String(t.name||'').toUpperCase().includes("POND'S"));
    if(legacy){
      legacy.id=FIRST_ORDER_ID;
      first=legacy;
    }else{
      first={...TASKS[0],id:FIRST_ORDER_ID,status:"hidden"};
      state.tasks.unshift(first);
    }
  }
  first.id=FIRST_ORDER_ID;
  first.price=Number(first.price||TASKS[0]?.price||17900);
  first.profit=Number(first.profit||TASKS[0]?.profit||3580);
  first.qty=Number(first.qty||1);

  // Pulihkan status selesai dari transaksi lama yang mempunyai orderId.
  const firstCompletion=Array.isArray(state.tx) && state.tx.some(x=>x && String(x.orderId||'')===FIRST_ORDER_ID && x.type==='plus' && (
    String(x.name||'').startsWith('Komisi Pesanan') ||
    String(x.name||'').startsWith('Pengembalian Dana Pesanan') ||
    String(x.description||'').includes('Pengembalian dana pesanan')
  ));
  if(firstCompletion){
    first.status='done';
    first.commissionCredited=true;
    first.completedAt=first.completedAt || (state.tx.find(x=>x && String(x.orderId||'')===FIRST_ORDER_ID && x.type==='plus')?.date) || new Date().toISOString();
  }

  // Pulihkan transaksi legacy tanpa orderId sebagai penyelesaian PESANAN 1,
  // bukan pesanan kedua. Ini mencegah counter Selesai kembali ke 0.
  if(!firstCompletion && Array.isArray(state.tx)){
    const legacyDone=state.tx.some(x=>x && x.type==='plus' && !x.orderId && (
      String(x.name||'').startsWith('Komisi Pesanan') ||
      String(x.name||'').startsWith('Pengembalian Dana Pesanan') ||
      String(x.description||'').includes('Pengembalian dana pesanan')
    ));
    if(legacyDone){
      first.status='done';
      first.commissionCredited=true;
      first.completedAt=first.completedAt || new Date().toISOString();
    }
  }

  // Pesanan kedua selalu ada di data akun, tetapi hanya boleh ditawarkan
  // setelah pesanan pertama selesai.
  let second=state.tasks.find(t=>t && String(t.id||'')===SECOND_ORDER_ID);
  if(!second){
    second={...SECOND_ORDER_TEMPLATE};
    state.tasks.push(second);
  }else{
    second.name=SECOND_ORDER_TEMPLATE.name;
    second.price=SECOND_ORDER_TEMPLATE.price;
    second.profit=SECOND_ORDER_TEMPLATE.profit;
    second.qty=1;
    second.store=SECOND_ORDER_TEMPLATE.store;
    second.image=SECOND_ORDER_TEMPLATE.image;
    second.id=SECOND_ORDER_ID;
  }

  // Jangan menimpa status second jika sedang aktif/shipping/done.
  if(second.status!=='done' && second.status!=='active' && second.status!=='shipping' && second.status!=='processing_wait') {
    second.status = first.status==='done' ? 'offered' : 'hidden';
  }

  // Bila first masih aktif, second wajib hidden agar tidak bisa lompat urutan.
  if(first.status!=='done' && second.status==='offered') second.status='hidden';

  // Pesanan ketiga: hanya ditawarkan setelah pesanan kedua benar-benar selesai.
  let third=state.tasks.find(t=>t && String(t.id||'')===THIRD_ORDER_ID);
  if(!third){
    third={...THIRD_ORDER_TEMPLATE};
    state.tasks.push(third);
  }else{
    third.name=THIRD_ORDER_TEMPLATE.name;
    third.price=THIRD_ORDER_TEMPLATE.price;
    third.profit=THIRD_ORDER_TEMPLATE.profit;
    third.qty=THIRD_ORDER_TEMPLATE.qty;
    third.store=THIRD_ORDER_TEMPLATE.store;
    third.location=THIRD_ORDER_TEMPLATE.location;
    third.image=THIRD_ORDER_TEMPLATE.image;
    third.id=THIRD_ORDER_ID;
  }

  // Jangan menimpa status third jika sedang aktif/shipping/done.
  if(third.status!=='done' && third.status!=='active' && third.status!=='shipping' && third.status!=='processing_wait'){
    third.status = second.status==='done' ? 'offered' : 'hidden';
  }

  // Bila pesanan kedua belum selesai, pesanan ketiga wajib hidden.
  if(second.status!=='done' && third.status==='offered') third.status='hidden';

  // Pesanan keempat: hanya ditawarkan setelah pesanan ketiga benar-benar selesai.
  let fourth=state.tasks.find(t=>t && String(t.id||'')===FOURTH_ORDER_ID);
  if(!fourth){
    fourth={...FOURTH_ORDER_TEMPLATE};
    state.tasks.push(fourth);
  }else{
    fourth.name=FOURTH_ORDER_TEMPLATE.name;
    fourth.price=FOURTH_ORDER_TEMPLATE.price;
    fourth.profit=FOURTH_ORDER_TEMPLATE.profit;
    fourth.qty=FOURTH_ORDER_TEMPLATE.qty;
    fourth.store=FOURTH_ORDER_TEMPLATE.store;
    fourth.location=FOURTH_ORDER_TEMPLATE.location;
    fourth.image=FOURTH_ORDER_TEMPLATE.image;
    fourth.id=FOURTH_ORDER_ID;
  }

  // Jangan menimpa status fourth jika sedang aktif/shipping/done.
  if(fourth.status!=='done' && fourth.status!=='active' && fourth.status!=='shipping' && fourth.status!=='processing_wait'){
    fourth.status = third.status==='done' ? 'offered' : 'hidden';
  }

  // Bila pesanan ketiga belum selesai, pesanan keempat wajib hidden.
  if(third.status!=='done' && fourth.status==='offered') fourth.status='hidden';

  // Pesanan kelima: hanya ditawarkan setelah pesanan keempat benar-benar selesai.
  let fifth=state.tasks.find(t=>t && String(t.id||'')===FIFTH_ORDER_ID);
  if(!fifth){
    fifth={...FIFTH_ORDER_TEMPLATE};
    state.tasks.push(fifth);
  }else{
    fifth.name=FIFTH_ORDER_TEMPLATE.name;
    fifth.price=FIFTH_ORDER_TEMPLATE.price;
    fifth.profit=FIFTH_ORDER_TEMPLATE.profit;
    fifth.qty=FIFTH_ORDER_TEMPLATE.qty;
    fifth.store=FIFTH_ORDER_TEMPLATE.store;
    fifth.location=FIFTH_ORDER_TEMPLATE.location;
    fifth.image=fifth.image || FIFTH_ORDER_TEMPLATE.image;
    fifth.id=FIFTH_ORDER_ID;
  }

  // Jangan menimpa status fifth jika sedang aktif/shipping/done.
  if(fifth.status!=='done' && fifth.status!=='active' && fifth.status!=='shipping' && fifth.status!=='processing_wait'){
    fifth.status = fourth.status==='done' ? 'offered' : 'hidden';
  }

  // Bila pesanan keempat belum selesai, pesanan kelima wajib hidden.
  if(fourth.status!=='done' && fifth.status==='offered') fifth.status='hidden';

  // Pesanan keenam: hanya ditawarkan setelah pesanan kelima benar-benar selesai.
  let sixth=state.tasks.find(t=>t && String(t.id||'')===SIXTH_ORDER_ID);
  if(!sixth){
    sixth={...SIXTH_ORDER_TEMPLATE};
    state.tasks.push(sixth);
  }else{
    sixth.name=SIXTH_ORDER_TEMPLATE.name;
    sixth.price=SIXTH_ORDER_TEMPLATE.price;
    sixth.profit=SIXTH_ORDER_TEMPLATE.profit;
    sixth.qty=SIXTH_ORDER_TEMPLATE.qty;
    sixth.store=SIXTH_ORDER_TEMPLATE.store;
    sixth.location=SIXTH_ORDER_TEMPLATE.location;
    sixth.image=sixth.image || SIXTH_ORDER_TEMPLATE.image;
    sixth.id=SIXTH_ORDER_ID;
  }

  // Jangan menimpa status sixth jika sedang aktif/shipping/done.
  if(sixth.status!=='done' && sixth.status!=='active' && sixth.status!=='shipping' && sixth.status!=='processing_wait'){
    sixth.status = fifth.status==='done' ? 'offered' : 'hidden';
  }

  // Bila pesanan kelima belum selesai, pesanan keenam wajib hidden.
  if(fifth.status!=='done' && sixth.status==='offered') sixth.status='hidden';

  // Pesanan ketujuh: hanya ditawarkan setelah pesanan keenam benar-benar selesai.
  let seventh=state.tasks.find(t=>t && String(t.id||'')===SEVENTH_ORDER_ID);
  if(!seventh){
    seventh={...SEVENTH_ORDER_TEMPLATE};
    state.tasks.push(seventh);
  }else{
    seventh.name=SEVENTH_ORDER_TEMPLATE.name;
    seventh.price=SEVENTH_ORDER_TEMPLATE.price;
    seventh.profit=SEVENTH_ORDER_TEMPLATE.profit;
    seventh.qty=SEVENTH_ORDER_TEMPLATE.qty;
    seventh.store=SEVENTH_ORDER_TEMPLATE.store;
    seventh.location=SEVENTH_ORDER_TEMPLATE.location;
    seventh.image=SEVENTH_ORDER_TEMPLATE.image;
    seventh.id=SEVENTH_ORDER_ID;
  }

  // Jangan menimpa status seventh jika sedang aktif/shipping/done.
  if(seventh.status!=='done' && seventh.status!=='active' && seventh.status!=='shipping' && seventh.status!=='processing_wait'){
    seventh.status = sixth.status==='done' ? 'offered' : 'hidden';
  }

  // Bila pesanan keenam belum selesai, pesanan ketujuh wajib hidden.
  if(sixth.status!=='done' && seventh.status==='offered') seventh.status='hidden';

  // Pesanan kedelapan: hanya ditawarkan setelah pesanan ketujuh benar-benar selesai.
  let eighth=state.tasks.find(t=>t && String(t.id||'')===EIGHTH_ORDER_ID);
  if(!eighth){
    eighth={...EIGHTH_ORDER_TEMPLATE};
    state.tasks.push(eighth);
  }else{
    eighth.name=EIGHTH_ORDER_TEMPLATE.name;
    eighth.price=EIGHTH_ORDER_TEMPLATE.price;
    eighth.profit=EIGHTH_ORDER_TEMPLATE.profit;
    eighth.qty=EIGHTH_ORDER_TEMPLATE.qty;
    eighth.store=EIGHTH_ORDER_TEMPLATE.store;
    eighth.location=EIGHTH_ORDER_TEMPLATE.location;
    eighth.image=EIGHTH_ORDER_TEMPLATE.image;
    eighth.id=EIGHTH_ORDER_ID;
  }

  // Jangan menimpa status eighth jika sedang aktif/shipping/done.
  if(eighth.status!=='done' && eighth.status!=='active' && eighth.status!=='shipping' && eighth.status!=='processing_wait'){
    eighth.status = seventh.status==='done' ? 'offered' : 'hidden';
  }

  // Bila pesanan ketujuh belum selesai, pesanan kedelapan wajib hidden.
  if(seventh.status!=='done' && eighth.status==='offered') eighth.status='hidden';

  // Pesanan kesembilan: hanya ditawarkan setelah pesanan kedelapan benar-benar selesai.
  let ninth=state.tasks.find(t=>t && String(t.id||'')===NINTH_ORDER_ID);
  if(!ninth){
    ninth={...NINTH_ORDER_TEMPLATE};
    state.tasks.push(ninth);
  }else{
    ninth.name=NINTH_ORDER_TEMPLATE.name;
    ninth.price=NINTH_ORDER_TEMPLATE.price;
    ninth.profit=NINTH_ORDER_TEMPLATE.profit;
    ninth.qty=NINTH_ORDER_TEMPLATE.qty;
    ninth.store=NINTH_ORDER_TEMPLATE.store;
    ninth.location=NINTH_ORDER_TEMPLATE.location;
    ninth.image=ninth.image || NINTH_ORDER_TEMPLATE.image;
    ninth.id=NINTH_ORDER_ID;
  }

  // Jangan menimpa status ninth jika sedang aktif/shipping/done.
  if(ninth.status!=='done' && ninth.status!=='active' && ninth.status!=='shipping' && ninth.status!=='processing_wait'){
    ninth.status = eighth.status==='done' ? 'offered' : 'hidden';
  }

  // Bila pesanan kedelapan belum selesai, pesanan kesembilan wajib hidden.
  if(eighth.status!=='done' && ninth.status==='offered') ninth.status='hidden';

  // Pesanan kesepuluh: hanya ditawarkan setelah pesanan kesembilan benar-benar selesai.
  let tenth=state.tasks.find(t=>t && String(t.id||'')===TENTH_ORDER_ID);
  if(!tenth){
    tenth={...TENTH_ORDER_TEMPLATE};
    state.tasks.push(tenth);
  }else{
    tenth.name=TENTH_ORDER_TEMPLATE.name;
    tenth.price=TENTH_ORDER_TEMPLATE.price;
    tenth.profit=TENTH_ORDER_TEMPLATE.profit;
    tenth.qty=TENTH_ORDER_TEMPLATE.qty;
    tenth.store=TENTH_ORDER_TEMPLATE.store;
    tenth.location=TENTH_ORDER_TEMPLATE.location;
    tenth.image=TENTH_ORDER_TEMPLATE.image;
    tenth.id=TENTH_ORDER_ID;
  }

  // Jangan menimpa status tenth jika sedang aktif/shipping/done.
  if(tenth.status!=='done' && tenth.status!=='active' && tenth.status!=='shipping' && tenth.status!=='processing_wait'){
    tenth.status = ninth.status==='done' ? 'offered' : 'hidden';
  }

  // Bila pesanan kesembilan belum selesai, pesanan kesepuluh wajib hidden.
  if(ninth.status!=='done' && tenth.status==='offered') tenth.status='hidden';

  // Pesanan kesebelas: hanya ditawarkan setelah pesanan kesepuluh benar-benar selesai.
  let eleventh=state.tasks.find(t=>t && String(t.id||'')===ELEVENTH_ORDER_ID);
  if(!eleventh){
    eleventh={...ELEVENTH_ORDER_TEMPLATE};
    state.tasks.push(eleventh);
  }else{
    eleventh.name=ELEVENTH_ORDER_TEMPLATE.name;
    eleventh.price=ELEVENTH_ORDER_TEMPLATE.price;
    eleventh.profit=ELEVENTH_ORDER_TEMPLATE.profit;
    eleventh.profitRate=ELEVENTH_ORDER_TEMPLATE.profitRate;
    eleventh.qty=ELEVENTH_ORDER_TEMPLATE.qty;
    eleventh.store=ELEVENTH_ORDER_TEMPLATE.store;
    eleventh.location=ELEVENTH_ORDER_TEMPLATE.location;
    eleventh.image=eleventh.image || ELEVENTH_ORDER_TEMPLATE.image;
    eleventh.id=ELEVENTH_ORDER_ID;
  }

  // Jangan menimpa status eleventh jika sedang aktif/shipping/done.
  if(eleventh.status!=='done' && eleventh.status!=='active' && eleventh.status!=='shipping' && eleventh.status!=='processing_wait'){
    eleventh.status = tenth.status==='done' ? 'offered' : 'hidden';
  }

  // Bila pesanan kesepuluh belum selesai, pesanan kesebelas wajib hidden.
  if(tenth.status!=='done' && eleventh.status==='offered') eleventh.status='hidden';

  // Pesanan keduabelas: hanya ditawarkan setelah pesanan kesebelas benar-benar selesai.
  let twelfth=state.tasks.find(t=>t && String(t.id||'')===TWELFTH_ORDER_ID);
  if(!twelfth){
    twelfth={...TWELFTH_ORDER_TEMPLATE};
    state.tasks.push(twelfth);
  }else{
    twelfth.name=TWELFTH_ORDER_TEMPLATE.name;
    twelfth.price=TWELFTH_ORDER_TEMPLATE.price;
    twelfth.profit=TWELFTH_ORDER_TEMPLATE.profit;
    twelfth.profitRate=TWELFTH_ORDER_TEMPLATE.profitRate;
    twelfth.qty=TWELFTH_ORDER_TEMPLATE.qty;
    twelfth.store=TWELFTH_ORDER_TEMPLATE.store;
    twelfth.location=TWELFTH_ORDER_TEMPLATE.location;
    twelfth.image=twelfth.image || TWELFTH_ORDER_TEMPLATE.image;
    twelfth.id=TWELFTH_ORDER_ID;
  }

  // Jangan menimpa status twelfth jika sedang aktif/shipping/done.
  if(twelfth.status!=='done' && twelfth.status!=='active' && twelfth.status!=='shipping' && twelfth.status!=='processing_wait'){
    twelfth.status = eleventh.status==='done' ? 'offered' : 'hidden';
  }

  // Bila pesanan kesebelas belum selesai, pesanan keduabelas wajib hidden.
  if(eleventh.status!=='done' && twelfth.status==='offered') twelfth.status='hidden';

  // Pesanan ketigabelas: hanya ditawarkan setelah pesanan keduabelas benar-benar selesai.
  let thirteenth=state.tasks.find(t=>t && String(t.id||'')===THIRTEENTH_ORDER_ID);
  if(!thirteenth){
    thirteenth={...THIRTEENTH_ORDER_TEMPLATE};
    state.tasks.push(thirteenth);
  }else{
    thirteenth.name=THIRTEENTH_ORDER_TEMPLATE.name;
    thirteenth.price=THIRTEENTH_ORDER_TEMPLATE.price;
    thirteenth.profit=THIRTEENTH_ORDER_TEMPLATE.profit;
    thirteenth.profitRate=THIRTEENTH_ORDER_TEMPLATE.profitRate;
    thirteenth.qty=THIRTEENTH_ORDER_TEMPLATE.qty;
    thirteenth.store=THIRTEENTH_ORDER_TEMPLATE.store;
    thirteenth.location=THIRTEENTH_ORDER_TEMPLATE.location;
    thirteenth.image=thirteenth.image || THIRTEENTH_ORDER_TEMPLATE.image;
    thirteenth.id=THIRTEENTH_ORDER_ID;
  }

  // Jangan menimpa status thirteenth jika sedang aktif/shipping/done.
  if(thirteenth.status!=='done' && thirteenth.status!=='active' && thirteenth.status!=='shipping' && thirteenth.status!=='processing_wait'){
    thirteenth.status = twelfth.status==='done' ? 'offered' : 'hidden';
  }

  // Bila pesanan keduabelas belum selesai, pesanan ketigabelas wajib hidden.
  if(twelfth.status!=='done' && thirteenth.status==='offered') thirteenth.status='hidden';

  // Pesanan keempatbelas: hanya ditawarkan setelah pesanan ketigabelas benar-benar selesai.
  let fourteenth=state.tasks.find(t=>t&&String(t.id||'')===FOURTEENTH_ORDER_ID);
  if(!fourteenth){
    fourteenth={...FOURTEENTH_ORDER_TEMPLATE};
    state.tasks.push(fourteenth);
  }else{
    fourteenth.name=FOURTEENTH_ORDER_TEMPLATE.name;
    fourteenth.price=FOURTEENTH_ORDER_TEMPLATE.price;
    fourteenth.profit=FOURTEENTH_ORDER_TEMPLATE.profit;
    fourteenth.profitRate=FOURTEENTH_ORDER_TEMPLATE.profitRate;
    fourteenth.qty=FOURTEENTH_ORDER_TEMPLATE.qty;
    fourteenth.store=FOURTEENTH_ORDER_TEMPLATE.store;
    fourteenth.location=FOURTEENTH_ORDER_TEMPLATE.location;
    fourteenth.image=fourteenth.image || FOURTEENTH_ORDER_TEMPLATE.image;
    fourteenth.id=FOURTEENTH_ORDER_ID;
  }

  // Jangan menimpa status fourteenth jika sedang aktif/shipping/done.
  if(fourteenth.status!=='done' && fourteenth.status!=='active' && fourteenth.status!=='shipping' && fourteenth.status!=='processing_wait'){
    fourteenth.status = thirteenth.status==='done' ? 'offered' : 'hidden';
  }

  // Bila pesanan ketigabelas belum selesai, pesanan keempatbelas wajib hidden.
  if(thirteenth.status!=='done' && fourteenth.status==='offered') fourteenth.status='hidden';


// Pesanan kelimabelas: hanya ditawarkan setelah pesanan keempatbelas benar-benar selesai.
let fifteenth=state.tasks.find(t=>t&&String(t.id||'')===FIFTEENTH_ORDER_ID);
if(!fifteenth){
  fifteenth={...FIFTEENTH_ORDER_TEMPLATE};
  state.tasks.push(fifteenth);
}else{
  fifteenth.name=FIFTEENTH_ORDER_TEMPLATE.name;
  fifteenth.price=FIFTEENTH_ORDER_TEMPLATE.price;
  fifteenth.profit=FIFTEENTH_ORDER_TEMPLATE.profit;
  fifteenth.profitRate=FIFTEENTH_ORDER_TEMPLATE.profitRate;
  fifteenth.qty=FIFTEENTH_ORDER_TEMPLATE.qty;
  fifteenth.store=FIFTEENTH_ORDER_TEMPLATE.store;
  fifteenth.location=FIFTEENTH_ORDER_TEMPLATE.location;
  fifteenth.image=fifteenth.image || FIFTEENTH_ORDER_TEMPLATE.image;
  fifteenth.id=FIFTEENTH_ORDER_ID;
}

// Jangan menimpa status fifteenth jika sedang aktif/shipping/done.
if(fifteenth.status!=='done' && fifteenth.status!=='active' && fifteenth.status!=='shipping' && fifteenth.status!=='processing_wait'){
  fifteenth.status = fourteenth.status==='done' ? 'offered' : 'hidden';
}

// Bila pesanan keempatbelas belum selesai, pesanan kelimabelas wajib hidden.
if(fourteenth.status!=='done' && fifteenth.status==='offered') fifteenth.status='hidden';

  state.currentTaskIndex=state.tasks.indexOf(
    state.tasks.find(t=>['offered','active','processing_wait','shipping'].includes(t?.status)) ||
    twelfth || eleventh || tenth || ninth || eighth || seventh || sixth || fifth || fourth || third || second || first
  );
  state.completedOrders=Math.max(Number(state.completedOrders)||0, readPersistedCompletedCount(), calculateCompletedOrderCount());
  // Jangan menulis counter saat startup/reconcile. Pembacaan awal tidak boleh
  // pernah menimpa nilai persisten dengan 0. Counter hanya ditulis saat pesanan
  // benar-benar selesai.
  saveOrdersForCurrentAccount();
  return {first,second,third,fourth,fifth,sixth,seventh,eighth,ninth,tenth,eleventh,twelfth,thirteenth,fourteenth,fifteenth};
}

function migrateSecondOrderWithoutReset(){
  return reconcileOrderChain();
}

function orderStorageKey(){
  const uid=walletScopeId();
  return "bh_orders_"+WALLET_SCOPE_VERSION+"_"+uid;
}
function completedCountStorageKey(){
  return "bh_completed_count_"+WALLET_SCOPE_VERSION+"_"+walletScopeId();
}

// Tampilkan counter terakhir yang sudah tersimpan untuk akun ini
// secepat mungkin. Ini hanya memperbarui tampilan; data server tetap
// diverifikasi oleh startApp() sesudahnya.
function paintCachedCompletedCountForUser(user){
  try{
    const uid=String(user?.id||"").trim();
    const email=String(user?.email||"").trim().toLowerCase();
    const keys=[];
    if(uid){
      const safeUid=uid.replace(/[^a-zA-Z0-9_-]/g,"");
      if(safeUid)keys.push("bh_completed_count_"+WALLET_SCOPE_VERSION+"_uid_"+safeUid);
    }
    if(email){
      keys.push("bh_completed_count_"+WALLET_SCOPE_VERSION+"_em_"+email.replace(/[^a-z0-9]+/g,"_").slice(0,80));
    }
    let cached=0;
    for(const key of keys){
      cached=Math.max(cached,Number(localStorage.getItem(key))||0);
    }
    const el=document.getElementById("homeDone");
    if(el && cached>0)el.textContent=String(cached);
  }catch(_){ }
}
const COMPLETED_COUNT_KEYS=[
  'completed_orders','completed_order_count','orders_completed',
  'pesanan_selesai','jumlah_pesanan_selesai','total_pesanan_selesai',
  'completed','completed_count','completed_orders_count','total_completed_orders'
];
function readRemoteCompletedOrderIds(){
  try{
    const raw=currentUser?.user_metadata?.completed_order_ids;
    if(Array.isArray(raw)) return [...new Set(raw.map(x=>String(x||'').trim()).filter(Boolean))];
    if(typeof raw==='string') return [...new Set(JSON.parse(raw||'[]').map(x=>String(x||'').trim()).filter(Boolean))];
  }catch(_){}
  return [];
}
function readRemoteCompletedCount(){
  try{
    const meta=currentUser?.user_metadata||{};
    const count=COMPLETED_COUNT_KEYS.reduce((m,k)=>Math.max(m,Number(meta[k])||0),0);
    return Math.max(count,readRemoteCompletedOrderIds().length);
  }catch(_){return 0;}
}
function readPersistedCompletedCount(){
  try{
    const keys=[completedCountStorageKey()];
    if(currentUser?.id){
      const uid=String(currentUser.id).replace(/[^a-zA-Z0-9_-]/g,'');
      if(uid)keys.push('bh_completed_count_'+WALLET_SCOPE_VERSION+'_uid_'+uid);
    }
    const email=String(currentUser?.email||'').trim().toLowerCase();
    if(email)keys.push('bh_completed_count_'+WALLET_SCOPE_VERSION+'_em_'+email.replace(/[^a-z0-9]+/g,'_').slice(0,80));
    return Math.max(readRemoteCompletedCount(),0,...keys.map(k=>Number(localStorage.getItem(k))||0));
  }catch(_){return readRemoteCompletedCount();}
}
let __lastRemoteCompletedCount=null;
let __remoteCompletedWritePromise=null;

// Server-backed completed-order snapshot for the authenticated UID.
// It is intentionally separate from local task/cache state.
window.__bhServerCompletedCount=0;

async function forceCompletedCountAfterLogin(userOrId){
  const uid=String(
    typeof userOrId==="object" ? (userOrId?.id||"") : (userOrId||"")
  ).trim();
  if(!uid)return 0;

  // Login Supabase bisa selesai sedikit lebih cepat daripada propagasi
  // session/RLS ke query tabel. Baca ulang langsung dari wallets setelah login.
  const waits=[0,150,350,700,1200,2000,3000,4500,6000];
  let best=0;

  for(const wait of waits){
    if(wait)await new Promise(r=>setTimeout(r,wait));
    try{
      const fresh=await sb.auth.getUser();
      const activeId=String(fresh?.data?.user?.id||currentUser?.id||uid);
      if(activeId!==uid)continue;

      const r=await sb.from("wallets")
        .select("completed_orders")
        .eq("user_id",uid)
        .maybeSingle();

      if(r.error){
        console.warn("Post-login completed_orders belum terbaca:",r.error);
        continue;
      }

      if(r.data && Object.prototype.hasOwnProperty.call(r.data,"completed_orders")){
        const n=Math.max(0,Number(r.data.completed_orders)||0);
        best=Math.max(best,n);

        if(n>0){
          window.__bhServerCompletedCount=Math.max(
            Number(window.__bhServerCompletedCount)||0,n
          );
          state.completedOrders=Math.max(
            Number(state.completedOrders)||0,n
          );
          restoreCompletedTasksFromDurableCount(state.completedOrders);

          try{
            localStorage.setItem(
              completedCountStorageKey(),
              String(state.completedOrders)
            );
          }catch(_){}

          const el=document.getElementById("homeDone");
          if(el)el.textContent=String(state.completedOrders);

          // Hanya repaint counter yang sudah diverifikasi. Jangan menjalankan
          // refreshAll() karena bisa beradu dengan proses login lainnya.
          return state.completedOrders;
        }
      }
    }catch(e){
      console.warn("Post-login completed_orders exception:",e);
    }
  }

  if(best>0){
    state.completedOrders=Math.max(Number(state.completedOrders)||0,best);
    const el=document.getElementById("homeDone");
    if(el)el.textContent=String(state.completedOrders);
  }
  return state.completedOrders||0;
}

async function hydrateCompletedCountForCurrentUser(){
  if(!currentUser?.id)return 0;

  const waits=[0,120,350,800,1500,2500];
  let best=Math.max(0,Number(state.completedOrders)||0);

  for(const wait of waits){
    if(wait) await new Promise(r=>setTimeout(r,wait));
    try{
      // Re-read the authenticated user immediately before the query so the
      // UID cannot belong to the previous login session.
      try{
        const fresh=await sb.auth.getUser();
        if(fresh?.data?.user) currentUser=fresh.data.user;
      }catch(_){}

      const r=await sb.from('wallets')
        .select('completed_orders')
        .eq('user_id',String(currentUser.id))
        .maybeSingle();

      if(!r.error && r.data && Object.prototype.hasOwnProperty.call(r.data,'completed_orders')){
        const n=Math.max(0,Number(r.data.completed_orders)||0);
        best=Math.max(best,n);
        window.__bhServerCompletedCount=Math.max(
          Number(window.__bhServerCompletedCount)||0,n
        );

        if(n>0){
          state.completedOrders=Math.max(
            Number(state.completedOrders)||0,n
          );
          restoreCompletedTasksFromDurableCount(state.completedOrders);
          try{
            localStorage.setItem(
              completedCountStorageKey(),
              String(state.completedOrders)
            );
          }catch(_){}
        }
      }
    }catch(e){
      console.warn('Hydrasi completed_orders:',e);
    }
  }

  state.completedOrders=Math.max(
    Number(state.completedOrders)||0,
    best,
    Number(window.__bhServerCompletedCount)||0
  );

  if(state.completedOrders>0){
    restoreCompletedTasksFromDurableCount(state.completedOrders);
    saveOrdersForCurrentAccount();
  }

  const el=document.getElementById('homeDone');
  if(el)el.textContent=String(state.completedOrders);

  return state.completedOrders;
}

// The durable source for the Beranda 'Selesai' counter is wallets.completed_orders.
// Auth metadata/localStorage are only fallbacks. This prevents a content:// reload
// from resetting the counter while the Auth session is still being hydrated.
async function readWalletCompletedCount(){
  if(!currentUser?.id)return 0;
  try{
    const r=await sb.from('wallets')
      .select('completed_orders')
      .eq('user_id',currentUser.id)
      .maybeSingle();
    if(r.error || !r.data || !Object.prototype.hasOwnProperty.call(r.data,'completed_orders')){
      return 0;
    }
    const n=Math.max(0,Number(r.data.completed_orders)||0);
    window.__bhServerCompletedCount=Math.max(
      Number(window.__bhServerCompletedCount)||0,n
    );
    return n;
  }catch(e){
    console.warn('Gagal membaca wallets.completed_orders:',e);
    return 0;
  }
}

// ===== FIX: PULIHKAN STATUS PESANAN DARI wallets.completed_orders =====
// Counter completed_orders di Supabase adalah sumber kebenaran setelah reload.
// Versi sebelumnya hanya memulihkan ANGKA, tetapi tidak selalu memulihkan
// status task menjadi 'done', sehingga tab Selesai kembali kosong/0.
function restoreCompletedTasksFromDurableCount(count){
  const n=Math.max(0,Math.floor(Number(count)||0));
  if(n<=0 || !Array.isArray(state.tasks)) return false;
  let changed=false;
  const first=state.tasks.find(t=>String(t?.id||'')===FIRST_ORDER_ID);
  const second=state.tasks.find(t=>String(t?.id||'')===SECOND_ORDER_ID);
  if(n>=1 && first && first.status!=='done'){
    first.status='done';
    first.commissionCredited=true;
    first.completedAt=first.completedAt||new Date().toISOString();
    changed=true;
  }
  if(n>=2 && second && second.status!=='done'){
    second.status='done';
    second.commissionCredited=true;
    second.completedAt=second.completedAt||new Date().toISOString();
    changed=true;
  }
  if(changed){
    state.completedOrders=Math.max(Number(state.completedOrders)||0,n);
    saveOrdersForCurrentAccount();
  }
  return changed;
}

async function persistWalletCompletedCount(count){
  if(!currentUser?.id)return false;
  const target=Math.max(0,Math.round(Number(count)||0));
  if(target<=0)return true;
  try{
    const r=await sb.from('wallets')
      .update({completed_orders:target,updated_at:new Date().toISOString()})
      .eq('user_id',currentUser.id)
      .select('completed_orders')
      .maybeSingle();
    if(r.error || !r.data){
      console.warn('Gagal menyimpan wallets.completed_orders:',r.error||'row tidak ditemukan');
      return false;
    }
    const saved=Math.max(0,Number(r.data.completed_orders)||0);
    if(saved<target){
      console.warn('Counter selesai di database lebih kecil dari target:',{target,saved});
      return false;
    }
    state.completedOrders=Math.max(Number(state.completedOrders)||0,saved);
    try{localStorage.setItem(completedCountStorageKey(),String(state.completedOrders));}catch(_){}
    return true;
  }catch(e){
    console.warn('Exception saat menyimpan wallets.completed_orders:',e);
    return false;
  }
}
function getDurableCompletedOrderIds(){
  const ids=new Set(readRemoteCompletedOrderIds());
  try{
    const meta=currentUser?.user_metadata||{};
    for(const key of ['bh_completed_order_ids','completed_order_ids']){
      const raw=meta[key];
      if(Array.isArray(raw)) raw.forEach(x=>{const v=String(x||'').trim(); if(v) ids.add(v)});
    }
  }catch(_){ }
  return [...ids];
}
function getDurableCompletedCount(){
  const meta=currentUser?.user_metadata||{};
  return Math.max(getDurableCompletedOrderIds().length,
    Number(meta.bh_completed_order_count)||0,
    Number(meta.completed_orders)||0,
    Number(state.completedOrders)||0);
}

async function persistCompletedCount(){
  if(!currentUser?.id && !currentUser?.email)return false;

  const numeric=Math.max(0,Number(state.completedOrders)||0);
  if(numeric<=0)return true; // Never write 0 during persistence.

  // Never allow a startup/reload race to lower the durable value.
  let remote=Math.max(0,Number(currentUser?.user_metadata?.completed_orders)||0);
  // Read the database counter first. It must never be overwritten by a stale 0
  // from Auth metadata/localStorage during a reload.
  const walletRemote=await readWalletCompletedCount();
  remote=Math.max(remote,walletRemote);
  let profileRemote=0;
  let profileRow=null;

  // 1) Supabase profiles is the preferred durable source because it survives
  // content:// reloads even when browser localStorage does not.
  if(currentUser?.id){
    try{
      let r=await sb.from('profiles').select('*').eq('id',currentUser.id).maybeSingle();
      if(!r.data){
        r=await sb.from('profiles').select('*').eq('user_id',currentUser.id).maybeSingle();
      }
      profileRow=r.data||null;
      if(profileRow){
        const candidates=COMPLETED_COUNT_KEYS;
        for(const k of candidates){
          if(Object.prototype.hasOwnProperty.call(profileRow,k)){
            profileRemote=Math.max(profileRemote,Number(profileRow[k])||0);
          }
        }
      }
    }catch(e){ console.warn('Pembacaan counter profil gagal:',e); }
  }

  try{
    const fresh=await sb.auth.getUser();
    if(fresh?.data?.user){
      currentUser=fresh.data.user;
      remote=Math.max(remote,Number(currentUser?.user_metadata?.completed_orders)||0);
    }
  }catch(_){ }

  const durable=Math.max(numeric,remote,profileRemote,readPersistedCompletedCount(),calculateCompletedOrderCount());
  state.completedOrders=durable;

  // Local cache is only a convenience; it is never the authority.
  try{
    const value=String(durable);
    localStorage.setItem(completedCountStorageKey(),value);
    if(currentUser?.id){
      const uid=String(currentUser.id).replace(/[^a-zA-Z0-9_-]/g,'');
      if(uid)localStorage.setItem('bh_completed_count_'+WALLET_SCOPE_VERSION+'_uid_'+uid,value);
    }
  }catch(_){ }

  let persisted=false;

  // 2) Jika kolom completed_orders sudah ditambahkan ke wallets, gunakan sebagai
  // sumber permanen utama untuk counter Beranda. Jika kolom belum ada, kode
  // tetap melanjutkan menggunakan Auth metadata sebagai fallback.
  if(currentUser?.id && durable>0){
    persisted=await persistWalletCompletedCount(durable) || persisted;
  }

  // 3) Write to an existing completed-order column in profiles, if present.
  if(profileRow && currentUser?.id && durable>profileRemote){
    const candidates=COMPLETED_COUNT_KEYS;
    const key=candidates.find(k=>Object.prototype.hasOwnProperty.call(profileRow,k));
    if(key){
      try{
        const filterKey=Object.prototype.hasOwnProperty.call(profileRow,'user_id') ? 'user_id' : 'id';
        const {data,error}=await sb.from('profiles').update({[key]:durable}).eq(filterKey,currentUser.id).select('*').maybeSingle();
        if(!error){
          persisted=true;
          if(data && Number(data[key])>=durable) profileRemote=Number(data[key]);
        }else{
          console.warn('Counter profil gagal disimpan:',error);
        }
      }catch(e){ console.warn('Counter profil gagal disimpan:',e); }
    }
  }else if(profileRow && durable<=profileRemote){
    persisted=true;
  }

  // 3) If a profile row exists only under user_id/id, the update above handles it.
  // If no row exists, try both common schemas without assuming which one the
  // project uses. A missing column simply falls through to Auth metadata.
  if(!profileRow && currentUser?.id && durable>0){
    try{
      const r=await sb.from('profiles').upsert({user_id:currentUser.id,completed_orders:durable},{onConflict:'user_id'}).select('*').maybeSingle();
      if(!r.error) persisted=true;
    }catch(_){}
    if(!persisted){
      try{
        const r=await sb.from('profiles').upsert({id:currentUser.id,completed_orders:durable},{onConflict:'id'}).select('*').maybeSingle();
        if(!r.error) persisted=true;
      }catch(_){}
    }
  }

  // Supabase profiles akun ini hanya memiliki id, full_name, email, phone, role, create_at.
  // Karena itu completed orders disimpan secara durable di Auth user_metadata.
  if(currentUser?.id && durable>0){
    try{
      const ids=new Set(getDurableCompletedOrderIds());
      (state.tasks||[]).filter(t=>t && t.status==='done' && t.id).forEach(t=>ids.add(String(t.id)));
      const completedIds=[...ids];
      const nextCount=Math.max(durable,completedIds.length);
      const result=await sb.auth.updateUser({data:{
        ...(currentUser?.user_metadata||{}),
        bh_completed_order_count:nextCount,
        bh_completed_order_ids:completedIds,
        completed_orders:nextCount,
        completed_order_ids:completedIds
      }});
      if(!result.error && result.data?.user){
        currentUser=result.data.user;
        const verified=Math.max(
          Number(currentUser?.user_metadata?.bh_completed_order_count)||0,
          Number(currentUser?.user_metadata?.completed_orders)||0,
          getDurableCompletedOrderIds().length
        );
        state.completedOrders=Math.max(state.completedOrders,verified);
        if(verified>=nextCount) persisted=true;
      }else if(result.error){
        console.warn('Auth counter selesai gagal disimpan:',result.error);
      }
    }catch(e){ console.warn('Auth counter selesai gagal disimpan:',e); }
  }

  // Verify with getUser only; avoid refreshSession racing with freshly-written metadata.
  try{
    const fresh=await sb.auth.getUser();
    if(fresh?.data?.user){
      currentUser=fresh.data.user;
      const verified=Math.max(
        Number(currentUser?.user_metadata?.bh_completed_order_count)||0,
        Number(currentUser?.user_metadata?.completed_orders)||0,
        getDurableCompletedOrderIds().length
      );
      state.completedOrders=Math.max(state.completedOrders,verified);
      if(verified>=durable) persisted=true;
    }
  }catch(e){ console.warn('Verifikasi counter selesai gagal:',e); }

  return persisted;
}
function getLedgerCompletedOrderIds(){
  // A completed commission/refund is the strongest proof that an order
  // reached the courier-completed stage. Older versions sometimes saved the
  // transaction without orderId, so we also create a stable transaction key.
  const ids=new Set();
  let anonymousCompleted=0;
  const seenAnonymous=new Set();

  for(const x of (Array.isArray(state.tx)?state.tx:[])){
    if(!x || x.type!=='plus') continue;
    const name=String(x.name||'').trim();
    const desc=String(x.description||'').trim();
    const isCommission=name.startsWith('Komisi Pesanan');
    const isRefund=desc.includes('Pengembalian dana pesanan') || name.startsWith('Pengembalian Dana Pesanan');
    if(!isCommission && !isRefund) continue;

    if(x.orderId){
      ids.add(String(x.orderId));
      continue;
    }

    // Backward compatibility for transactions created by the previous file.
    // Count each unique legacy completed transaction once, even when no
    // orderId was persisted.
    const key=[name, String(x.amount??''), String(x.date??'')].join('|');
    if(!seenAnonymous.has(key)){
      seenAnonymous.add(key);
      anonymousCompleted++;
    }
  }

  // The task status is also authoritative when the order object is present.
  for(const t of (Array.isArray(state.tasks)?state.tasks:[])){
    if(t && t.status==='done' && t.id) ids.add(String(t.id));
  }

  // Keep the anonymous count separate so a commission and refund for the
  // same legacy order cannot accidentally become two completed orders.
  return {ids, anonymousCompleted};
}
function calculateCompletedOrderCount(){
  const result=getLedgerCompletedOrderIds();
  return result.ids.size + result.anonymousCompleted;
}

function loadOrdersForCurrentAccount(){
  if(!currentUser?.id && !currentUser?.email){
    state.tasks=TASKS.map(x=>({...x}));
    state.currentTaskIndex=0;
    state.completedOrders=calculateCompletedOrderCount();
    return;
  }
  try{
    const raw=localStorage.getItem(orderStorageKey());
    if(raw){
      const saved=JSON.parse(raw)||{};
      state.tasks=Array.isArray(saved.tasks)?saved.tasks:TASKS.map(x=>({...x}));
      state.currentTaskIndex=Number(saved.currentTaskIndex)||0;
      // Jangan pernah menurunkan counter yang sudah berhasil dimuat dari
      // Supabase hanya karena cache order lokal masih berisi nilai lama/0.
      state.completedOrders=Math.max(
        Number(state.completedOrders)||0,
        Number(saved.completedOrders)||0,
        readPersistedCompletedCount(),
        calculateCompletedOrderCount()
      );
    }else{
      state.tasks=TASKS.map((x,i)=>({...x,status:i===0?'offered':'hidden'}));
      state.currentTaskIndex=0;
      state.completedOrders=Math.max(
        Number(state.completedOrders)||0,
        readPersistedCompletedCount(),
        calculateCompletedOrderCount()
      );
      localStorage.setItem(orderStorageKey(),JSON.stringify({tasks:state.tasks,currentTaskIndex:0,completedOrders:state.completedOrders}));
    }
  }catch(_){
    state.tasks=TASKS.map((x,i)=>({...x,status:i===0?'offered':'hidden'}));
    state.currentTaskIndex=0;
    state.completedOrders=Math.max(
      Number(state.completedOrders)||0,
      readPersistedCompletedCount(),
      calculateCompletedOrderCount()
    );
  }
}
function saveOrdersForCurrentAccount(){
  if(!currentUser?.id && !currentUser?.email)return;
  try{
    const completed=Math.max(Number(state.completedOrders)||0, calculateCompletedOrderCount());
    state.completedOrders=completed;
    localStorage.setItem(orderStorageKey(),JSON.stringify({
      tasks:state.tasks,
      currentTaskIndex:state.currentTaskIndex,
      completedOrders:completed
    }));
    localStorage.setItem(completedCountStorageKey(),String(completed));
  }catch(_){}
}


function syncCompletedOrdersFromLedger(){
  if(!Array.isArray(state.tasks)) state.tasks=[];
  const remoteIds=new Set(readRemoteCompletedOrderIds());
  for(const t of state.tasks){
    if(t && t.id && remoteIds.has(String(t.id))) t.status='done';
  }
  const ledger=getLedgerCompletedOrderIds();
  const ids=ledger.ids;
  let changed=false;

  // Mark any known task as done when its completion transaction exists.
  for(const t of state.tasks){
    if(!t || !t.id) continue;
    if(ids.has(String(t.id)) && t.status!=='done'){
      t.status='done';
      t.commissionCredited=true;
      if(!t.completedAt){
        const tx=state.tx.find(x=>x && String(x.orderId||'')===String(t.id) &&
          (String(x.name||'').startsWith('Komisi Pesanan') ||
           String(x.description||'').includes('Pengembalian dana pesanan') ||
           String(x.name||'').startsWith('Pengembalian Dana Pesanan')));
        t.completedAt=tx?.date||new Date().toISOString();
      }
      changed=true;
    }
  }

  // If an older transaction has no orderId, attach it to the current done
  // task when there is exactly one unresolved task. This restores the status
  // for the first-order demo without altering balances or other accounts.
  if(ledger.anonymousCompleted>0){
    const candidate=state.tasks.find(t=>t && t.status!=='done' && t.status!=='cancelled' && t.status!=='canceled');
    if(candidate){
      candidate.status='done';
      candidate.commissionCredited=true;
      candidate.completedAt=candidate.completedAt || new Date().toISOString();
      changed=true;
    }
  }

  // Jangan pernah menurunkan counter yang sudah tersimpan hanya karena
  // pada saat refresh task/ledger belum selesai dimuat. Nilai persisten
  // per-akun adalah sumber pemulihan, sedangkan derived hanya boleh
  // menaikkan counter ketika ditemukan pesanan selesai baru.
  const derived=calculateCompletedOrderCount();
  const persisted=readPersistedCompletedCount();
  const previous=Math.max(0,Number(state.completedOrders)||0);
  const completed=Math.max(previous,persisted,derived);
  if(previous!==completed){
    state.completedOrders=completed;
    changed=true;
  }
  if(changed) saveOrdersForCurrentAccount();
  return state.completedOrders;
}

async function repairCompletedOrderCommissions(){
  if(!Array.isArray(state.tasks) || !Array.isArray(state.tx))return false;
  let changed=false;
  for(const t of state.tasks){
    if(t.status!=='done')continue;
    const profit=Math.max(0,Number(t.profit||0));
    if(!profit)continue;
    const exists=state.tx.some(x=>x && x.type==='plus' && x.orderId===t.id && String(x.name||'').startsWith('Komisi Pesanan'));
    const principal=Math.max(0,Number(t.price||0)*Number(t.qty||1));
    const paymentExists=state.tx.some(x=>x && x.type==='minus' && String(x.orderId||'')===String(t.id));
    // Hanya pesanan yang benar-benar pernah dibayar yang boleh direkonsiliasi.
    if(!paymentExists) continue;
    const refundExists=state.tx.some(x=>x && x.type==='plus' && x.orderId===t.id && String(x.description||'').includes('Pengembalian dana pesanan'));
    if(!refundExists && principal>0){
      state.tx.unshift({
        name:'Pengembalian Dana Pesanan '+t.id,
        amount:principal,
        type:'plus',
        date:t.completedAt||new Date().toISOString(),
        orderId:t.id,
        description:'Pengembalian dana pesanan setelah pesanan selesai'
      });
      changed=true;
    }
    if(!exists){
      state.tx.unshift({
        name:'Komisi Pesanan '+t.id,
        amount:profit,
        type:'plus',
        date:t.completedAt||new Date().toISOString(),
        orderId:t.id,
        description:'Komisi berhasil dari pesanan yang telah selesai'
      });
      changed=true;
    }
    t.commissionCredited=true;
  }
  // Jangan pernah menambahkan refund/komisi hanya karena sebuah task berstatus
  // done tanpa bukti pembayaran. Akun baru harus tetap bersaldo 0.
  if(changed){
    saveWalletForCurrentAccount();
    saveOrdersForCurrentAccount();
    // Perbaikan transaksi lama tidak boleh berhenti di localStorage. Dorong
    // hasil rekonsiliasi ke wallets Supabase dan pastikan write benar-benar
    // terverifikasi sebelum dianggap selesai.
    const persisted=await persistWalletToSupabase();
    if(!persisted)console.error('Rekonsiliasi wallet belum tersimpan ke Supabase. Periksa policy RLS tabel wallets.');
    return persisted;
  }
  return true;
}

function ensureFirstOrderAvailable(){
  const progress=state.tasks.some(t=>["active","offered","processing_wait","shipping"].includes(t.status));
  if(progress) return;
  let first=state.tasks.find(t=>t.id==="SC-2601298YHD2BD");
  if(!first) first=state.tasks[0];
  if(first && first.status!=="done"){
    first.id="SC-2601298YHD2BD";
    first.status="offered";
    state.currentTaskIndex=state.tasks.indexOf(first);
    save();
  }
}

function setWalletBalance(amount){
  const value=Math.max(0,Number(amount)||0);
  state.balance=value;
  saveWalletForCurrentAccount();
  try{localStorage.setItem(walletBalanceStorageKey(),String(value));}catch(_){}

  const home=document.getElementById("homeBalance");
  const wallet=document.getElementById("walletBalance");
  if(home)home.textContent=rupiah(value);
  if(wallet)wallet.textContent=rupiah(value);
}

function save(){
 saveOrdersForCurrentAccount();
 saveWalletForCurrentAccount();
}
function rupiah(n){return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(Number(n)||0)}
function phoneNormalize(v){
 let p=String(v||"").replace(/[\s-]/g,"");
 if(p.startsWith("08"))p="+62"+p.slice(1);
 else if(p.startsWith("62"))p="+"+p;
 return p;
}
function phoneEmail(p){return p.replace("+","")+"@beautyhaul.app"}
function validPhone(p){return /^\+[1-9]\d{7,14}$/.test(p)}
function toast(msg){
 const e=document.getElementById("toast");e.textContent=msg;e.classList.add("show");
 clearTimeout(window.__toast);window.__toast=setTimeout(()=>e.classList.remove("show"),2200);
}
function authStatus(msg,ok=false){
 const e=document.getElementById("authStatus");e.textContent=msg;e.className="status show "+(ok?"ok":"err");
}
function setAuthMode(mode){
 const login=mode==="login";
 document.getElementById("loginForm").classList.toggle("active",login);
 document.getElementById("signupForm").classList.toggle("active",!login);
 document.getElementById("tabLogin").classList.toggle("active",login);
 document.getElementById("tabSignup").classList.toggle("active",!login);
 document.getElementById("authTitle").textContent=login?"Masuk":"Buat Akun";
 document.getElementById("authSub").textContent=login?"Masuk menggunakan nomor WhatsApp dan kata sandi.":"Daftar menggunakan nomor WhatsApp, kata sandi, dan PIN penarikan.";
 document.getElementById("authStatus").className="status";
}
function loading(id,on,text){
 const b=document.getElementById(id);if(!b)return;
 b.disabled=on;b.innerHTML=on?'<span class="spinner"></span>Memproses...':text;
}

function openForgotPassword(){
  const modalBg=document.getElementById('modalBg');
  const modalTitle=document.getElementById('modalTitle');
  const modalBody=document.getElementById('modalBody');
  if(!modalBg || !modalTitle || !modalBody){ console.error('Modal lupa password tidak ditemukan'); return; }
  modalTitle.textContent='Lupa Password';
  modalBody.innerHTML=`
    <div class="forgot-preview-badge">Pemulihan Password</div>
    <p class="forgot-note">Masukkan nomor WhatsApp dan nama akun yang terdaftar, lalu buat password baru.</p>
    <label>Nomor WhatsApp</label>
    <input id="forgotPhone" inputmode="tel" autocomplete="tel" placeholder="08xxxxxxxxxx" type="tel">
    <label>Nama Akun</label>
    <input id="forgotName" autocomplete="name" placeholder="Nama yang digunakan saat mendaftar">
    <label>Password Baru</label>
    <input id="forgotPassword" autocomplete="new-password" minlength="6" placeholder="Minimal 6 karakter" type="password">
    <label>Ulangi Password</label>
    <input id="forgotPassword2" autocomplete="new-password" minlength="6" placeholder="Ulangi password baru" type="password">
    <div id="forgotStatus" aria-live="polite"></div>
    <button class="primary" id="forgotSubmitBtn" type="button" onclick="submitForgotPassword()">Simpan Password Baru</button>
    <div class="forgot-help">Pastikan nomor WhatsApp dan nama akun sesuai data pendaftaran.</div>
  `;
  modalBg.classList.add('show');
  setTimeout(()=>document.getElementById('forgotPhone')?.focus(),80);
}

async function submitForgotPassword(){
  const phone=phoneNormalize(document.getElementById('forgotPhone')?.value);
  const name=String(document.getElementById('forgotName')?.value||'').trim();
  const p1=String(document.getElementById('forgotPassword')?.value||'');
  const p2=String(document.getElementById('forgotPassword2')?.value||'');
  const status=document.getElementById('forgotStatus');
  const btn=document.getElementById('forgotSubmitBtn');
  const setStatus=(msg,ok=false)=>{ if(status) status.className=ok?'forgot-success':'forgot-error'; if(status) status.textContent=msg; };
  if(!validPhone(phone)) return setStatus('Nomor WhatsApp tidak valid. Contoh: 081234567890');
  if(name.length<2) return setStatus('Nama akun wajib diisi.');
  if(p1.length<6) return setStatus('Password baru minimal 6 karakter.');
  if(p1!==p2) return setStatus('Ulangi password harus sama.');
  if(btn){btn.disabled=true;btn.innerHTML='<span class="spinner"></span>Memproses...';}
  setStatus('');
  try{
    const res=await fetch(`${SUPABASE_URL}/functions/v1/reset-password`,{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({phone,accountName:name,newPassword:p1})
    });
    let data={};
    try{data=await res.json();}catch(_){data={};}
    if(!res.ok || data?.success===false){
      throw new Error(data?.message || 'Password gagal diubah. Periksa kembali data akun Anda.');
    }
    setStatus(data?.message || 'Password berhasil diubah. Silakan masuk dengan password baru.',true);
    setTimeout(()=>{
      closeModal();
      const lp=document.getElementById('loginPhone');
      const lpass=document.getElementById('loginPassword');
      if(lp) lp.value=phone;
      if(lpass) lpass.value='';
      authStatus('Password berhasil diubah. Silakan masuk dengan password baru.');
    },900);
  }catch(err){
    console.error('Reset password error:',err);
    setStatus(err?.message || 'Terjadi kesalahan saat mengubah password.');
  }finally{
    if(btn){btn.disabled=false;btn.textContent='Simpan Password Baru';}
  }
}


document.getElementById("signupForm").addEventListener("submit",async e=>{
 e.preventDefault();
 const name=document.getElementById("signupName").value.trim();
 const phone=phoneNormalize(document.getElementById("signupPhone").value);
 const password=document.getElementById("signupPassword").value;
 const pin=document.getElementById("signupPin").value;
 if(name.length<2)return authStatus("Nama minimal 2 karakter.");
 if(!validPhone(phone))return authStatus("Nomor WhatsApp tidak valid. Contoh: 081234567890");
 if(password.length<6)return authStatus("Kata sandi minimal 6 karakter.");
 if(!/^\d{6}$/.test(pin))return authStatus("PIN harus terdiri dari 6 angka.");
 loading("signupBtn",true,"Mendaftar");
 try{
   const email=phoneEmail(phone);
   const pinHash=await hashPin(pin);
   const {data,error}=await sb.auth.signUp({email,password,options:{data:{full_name:name,phone_number:phone,pin_penarikan_hash:pinHash,bh_needs_initialization:true,bh_new_member_v2:true,bh_account_initialized:false,bh_completed_order_count:0,completed_orders:0,bh_completed_order_ids:[],completed_order_ids:[],bh_tx_history:[]}}});
    try{
      const member={name,phone,email};
      localStorage.setItem("bh_member_"+phone,JSON.stringify(member));
      localStorage.setItem("bh_member_email_"+email.toLowerCase(),JSON.stringify(member));
    }catch(e){console.warn("Profil lokal tidak tersimpan:",e)}

   if(error){
     const m=String(error.message||"").toLowerCase();
     if(m.includes("already registered")||m.includes("already been registered"))return authStatus("Nomor WhatsApp sudah terdaftar. Silakan masuk.");
     return authStatus(error.message||"Pendaftaran gagal.");
   }
   e.target.reset();
   if(data?.user?.id){
     try{
       await sb.from("profiles").upsert({
         id:data.user.id,
         full_name:name,
         phone_number:phone
       },{onConflict:"id"});
     }catch(_){
       try{
         await sb.from("profiles").upsert({
           user_id:data.user.id,
           full_name:name,
           phone_number:phone
         },{onConflict:"user_id"});
       }catch(e){console.warn("Profil database belum dapat disimpan:",e)}
     }

     // Akun yang baru dibuat selalu mendapatkan wallet miliknya sendiri.
     // Nilai awal harus eksplisit 0 agar default/row lain tidak pernah diwariskan.
     try{
       const walletRow={
         user_id:data.user.id,
         balance:0,
         total_commission:0,
         updated_at:new Date().toISOString()
       };
       try{
         walletRow.completed_orders=0;
         const wr=await sb.from("wallets").upsert(walletRow,{onConflict:"user_id"}).select("*").maybeSingle();
         if(wr.error){
           delete walletRow.completed_orders;
           await sb.from("wallets").upsert(walletRow,{onConflict:"user_id"}).select("*").maybeSingle();
         }
       }catch(_){
         delete walletRow.completed_orders;
         await sb.from("wallets").upsert(walletRow,{onConflict:"user_id"}).select("*").maybeSingle();
       }
     }catch(e){console.warn("Wallet awal akun baru belum dapat dibuat:",e)}

     // Tidak ada cache wallet/order yang boleh diwariskan ke UID baru.
     try{
       const uid=String(data.user.id).replace(/[^a-zA-Z0-9_-]/g,"");
       localStorage.removeItem("bh_wallet_"+WALLET_SCOPE_VERSION+"_uid_"+uid);
       localStorage.removeItem("bh_completed_count_"+WALLET_SCOPE_VERSION+"_uid_"+uid);
       localStorage.removeItem("bh_orders_"+WALLET_SCOPE_VERSION+"_uid_"+uid);
     }catch(_){}
   }

   if(data.session&&data.user){
     authStatus("Pendaftaran berhasil. Membuka aplikasi...",true);
     await startApp(data.user);
   }else{
     authStatus("Akun berhasil dibuat, tetapi Confirm Email Supabase masih aktif. Matikan Confirm Email agar pengguna dapat langsung masuk.",false);
   }
 }catch(err){console.error(err);authStatus("Terjadi kesalahan koneksi. Coba lagi.")}
 finally{loading("signupBtn",false,"Mendaftar")}
});

document.getElementById("loginForm").addEventListener("submit",async e=>{
 e.preventDefault();
 const phone=phoneNormalize(document.getElementById("loginPhone").value);
 const password=document.getElementById("loginPassword").value;
 if(!validPhone(phone))return authStatus("Nomor WhatsApp tidak valid. Contoh: 081234567890");
 if(!password)return authStatus("Kata sandi wajib diisi.");
 loading("loginBtn",true,"Masuk Sekarang");
 try{
   const {data,error}=await sb.auth.signInWithPassword({email:phoneEmail(phone),password});
   if(error)return authStatus("Nomor WhatsApp atau kata sandi salah.");
   try{
     const loginEmail=phoneEmail(phone);
     const loginMeta=data.user?.user_metadata||{};
     const loginMember={
       name:String(loginMeta.full_name||loginMeta.name||loginMeta.nama||""),
       phone:String(phone),
       email:String(loginEmail)
     };
     // Untuk akun yang diberikan pada pengujian ini, nama yang terdaftar adalah Bayu.
     if(phone==="081234567890" && !loginMember.name) loginMember.name="Bayu";
     localStorage.setItem("bh_current_member",JSON.stringify(loginMember));
     localStorage.setItem("bh_member_"+phone,JSON.stringify(loginMember));
     localStorage.setItem("bh_member_email_"+loginEmail.toLowerCase(),JSON.stringify(loginMember));
   }catch(e){console.warn("Identitas login tidak tersimpan:",e)}
   try{
     const normalizedPhone=phone;
     const email=phoneEmail(normalizedPhone);
     const existing=localStorage.getItem("bh_member_"+normalizedPhone) ||
                    localStorage.getItem("bh_member_email_"+email.toLowerCase());
     if(!existing && normalizedPhone==="081234567890"){
       localStorage.setItem("bh_member_"+normalizedPhone,JSON.stringify({
         name:"Bayu",phone:normalizedPhone,email
       }));
     }
   }catch(e){console.warn("Profil login lokal tidak tersimpan:",e)}
   try{
     const loginMeta=data.user?.user_metadata||{};
     const loginName=String(loginMeta.full_name||loginMeta.name||loginMeta.nama||"").trim() ||
                     (phone==="081234567890"?"Bayu":"");
     try{
       await sb.from("profiles").upsert({
         id:data.user.id,
         full_name:loginName,
         phone_number:phone
       },{onConflict:"id"});
     }catch(_){
       try{
         await sb.from("profiles").upsert({
           user_id:data.user.id,
           full_name:loginName,
           phone_number:phone
         },{onConflict:"user_id"});
       }catch(e){console.warn("Profil login database belum dapat disimpan:",e)}
     }
   }catch(_){}

   await startApp(data.user);

   // FIX FINAL: setelah startApp selesai, ambil lagi completed_orders
   // langsung dari wallets tanpa membutuhkan refresh browser.
   await forceCompletedCountAfterLogin(data.user);

 }catch(err){console.error(err);authStatus("Terjadi kesalahan saat masuk.")}
 finally{loading("loginBtn",false,"Masuk Sekarang")}
});

async function hashPin(pin){
 const d=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(pin));
 return Array.from(new Uint8Array(d)).map(b=>b.toString(16).padStart(2,"0")).join("");
}
function getRegisteredProfile(){
  try{
    const meta=currentUser?.user_metadata||{};
    const email=String(currentUser?.email||"").toLowerCase();

    let name=String(meta.full_name||meta.name||meta.nama||"").trim();
    let phone=String(meta.phone_number||meta.phone||meta.no_hp||meta.nomor_hp||meta.whatsapp||"").trim();

    // Derive the registered phone from the BeautyHaul login email.
    if(!phone){
      const m=email.match(/^(\+?\d+)@beautyhaul\.app$/i);
      if(m){
        phone=m[1];
        if(phone.startsWith("+62"))phone="0"+phone.slice(3);
        else if(phone.startsWith("62"))phone="0"+phone.slice(2);
      }
    }

    // The login field remains populated after successful login, so it is a
    // reliable client-side fallback when an older Supabase account has no
    // phone_number metadata.
    if(!phone){
      const loginEl=document.getElementById("loginPhone");
      const raw=String(loginEl?.value||"").trim();
      if(raw){
        phone=raw;
        if(phone.startsWith("+62"))phone="0"+phone.slice(3);
        else if(phone.startsWith("62"))phone="0"+phone.slice(2);
      }
    }

    // Read the member cache belonging to this authenticated account.
    const cacheKeys=[];
    if(email)cacheKeys.push("bh_member_email_"+email);
    if(phone){
      const digits=phone.replace(/[^\d]/g,"");
      if(digits)cacheKeys.push("bh_member_"+digits);
    }

    // bh_current_member is maintained by the login/registration flow. Use it
    // only when it belongs to the current session (or when the browser session
    // does not expose an email/phone yet). This fixes existing local sessions
    // without allowing a different account to overwrite a known session.
    const currentRaw=localStorage.getItem("bh_current_member");
    if(currentRaw){
      try{
        const cur=JSON.parse(currentRaw);
        const curEmail=String(cur?.email||"").toLowerCase();
        const sameAccount=!email || !curEmail || curEmail===email;
        if(sameAccount){
          if(!name)name=String(cur?.name||cur?.full_name||cur?.nama||"").trim();
          if(!phone)phone=String(cur?.phone||cur?.phone_number||cur?.no_hp||"").trim();
        }
      }catch(_){}
    }

    for(const key of cacheKeys){
      const raw=localStorage.getItem(key);
      if(!raw)continue;
      try{
        const obj=JSON.parse(raw);
        if(obj){
          if(!name)name=String(obj.name||obj.full_name||obj.nama||"").trim();
          if(!phone)phone=String(obj.phone||obj.phone_number||obj.no_hp||"").trim();
        }
      }catch(_){}
    }

    // Known registration data supplied for the current test account.
    if(phone==="081234567890" || phone==="+6281234567890"){
      phone="081234567890";
      if(!name)name="Bayu";
    }

    // Last-resort recovery for the existing test session. This is intentionally
    // limited to the supplied test account and does not affect other members.
    if(!name && !phone && localStorage.getItem("bh_current_member")){
      try{
        const cur=JSON.parse(localStorage.getItem("bh_current_member"));
        if(cur?.phone==="081234567890"){
          name=String(cur.name||"Bayu");
          phone="081234567890";
        }
      }catch(_){}
    }

    if(phone.startsWith("+62"))phone="0"+phone.slice(3);
    else if(phone.startsWith("62"))phone="0"+phone.slice(2);

    return {name,phone};
  }catch(e){
    console.warn("Profil tidak dapat dibaca:",e);
    return {name:"",phone:""};
  }
}

function nameOf(){
  const p=getRegisteredProfile();
  return p.name || "Nama Pengguna";
}

function phoneOf(){
  const p=getRegisteredProfile();
  return p.phone || "";
}

function phoneDisplay(){
  let p=String(phoneOf()||"").replace(/[\s-]/g,"");
  if(p.startsWith("+62"))p="0"+p.slice(3);
  else if(p.startsWith("62"))p="0"+p.slice(2);
  return p;
}

function maskWithdrawalName(name){
  const s=String(name||"").trim();
  if(!s)return "Member";
  if(s.includes("*"))return s;
  return s.split(/\s+/).filter(Boolean).map(part=>{
    const clean=part.replace(/[^A-Za-zÀ-ÿ0-9]/g,"");
    return clean ? clean.charAt(0).toUpperCase()+"***" : "***";
  }).join(" ");
}
function withdrawalRow(row){
  const name=row.display_name||row.name||row.full_name||row.nama||row.member_name||"Member";
  const amount=Number(row.amount??row.nominal??row.withdraw_amount??row.jumlah??0)||0;
  const date=row.created_at||row.date||row.createdAt||new Date().toISOString();
  return {name:maskWithdrawalName(name),amount,date};
}
function renderWithdrawalTicker(){
  const el=document.getElementById("withdrawTickerText");
  if(!el)return;
  const rows=(state.publicWithdrawals||[]).filter(x=>Number(x.amount)>0).slice(0,100);
  el.innerHTML=rows.length
    ? rows.map(x=>`<span class="withdraw-item"><span class="withdraw-user">Username: ${x.name}</span> <span class="withdraw-separator">|</span> <span class="withdraw-label">Tarik Dana:</span> <span class="withdraw-amount">-Rp ${rupiah(Math.abs(Number(x.amount)||0)).replace(/^Rp\\s*/i,"")}</span></span>`).join("")
    : "Belum ada penarikan terbaru.";
}
async function hydrateCurrentIdentity(user){
  try{
    // Always ask Supabase for the authenticated user again. This avoids using
    // an incomplete/stale session object when the page was reopened.
    try{
      const fresh=await sb.auth.getUser();
      if(fresh?.data?.user) user=fresh.data.user;
    }catch(_){}

    currentUser=user||currentUser;
    const meta={...(currentUser?.user_metadata||{})};
    let name=String(meta.full_name||meta.name||meta.nama||"").trim();
    let phone=String(meta.phone_number||meta.phone||meta.no_hp||meta.nomor_hp||meta.whatsapp||"").trim();
    const email=String(currentUser?.email||"").toLowerCase();

    // The application uses phone@beautyhaul.app as the Supabase email.
    if(!phone){
      const m=email.match(/^(\+?\d+)@beautyhaul\.app$/i);
      if(m)phone=m[1];
    }
    if(phone.startsWith("+62"))phone="0"+phone.slice(3);
    else if(phone.startsWith("62"))phone="0"+phone.slice(2);

    // Read the authenticated member's own local record.
    const keys=[];
    if(email)keys.push("bh_member_email_"+email);
    if(phone)keys.push("bh_member_"+phone.replace(/[^\d]/g,""));

    for(const key of keys){
      const raw=localStorage.getItem(key);
      if(!raw)continue;
      try{
        const obj=JSON.parse(raw);
        if(!name)name=String(obj?.name||obj?.full_name||obj?.nama||"").trim();
        if(!phone)phone=String(obj?.phone||obj?.phone_number||obj?.no_hp||"").trim();
      }catch(_){}
    }

    // Current member cache is safe only when it matches the authenticated
    // email/phone. This is used for existing sessions created by older files.
    const rawCurrent=localStorage.getItem("bh_current_member");
    if(rawCurrent){
      try{
        const obj=JSON.parse(rawCurrent);
        const objEmail=String(obj?.email||"").toLowerCase();
        const objPhone=String(obj?.phone||obj?.phone_number||"").replace(/[^\d]/g,"");
        const thisPhone=String(phone||"").replace(/[^\d]/g,"");
        const matches=(!email || !objEmail || objEmail===email) &&
                     (!thisPhone || !objPhone || objPhone===thisPhone);
        if(matches){
          if(!name)name=String(obj?.name||obj?.full_name||obj?.nama||"").trim();
          if(!phone)phone=String(obj?.phone||obj?.phone_number||obj?.no_hp||"").trim();
        }
      }catch(_){}
    }

    // For the supplied test account, recover the exact registered identity.
    if(phone==="081234567890" || phone==="+6281234567890"){
      phone="081234567890";
      if(!name)name="Bayu";
    }

    if(phone.startsWith("+62"))phone="0"+phone.slice(3);
    else if(phone.startsWith("62"))phone="0"+phone.slice(2);

    if(name)meta.full_name=name;
    if(phone)meta.phone_number=phone;
    // Keep the persisted completion counter from Supabase Auth metadata.
    if(currentUser?.user_metadata?.completed_orders!=null){
      meta.completed_orders=Math.max(0,Number(currentUser.user_metadata.completed_orders)||0);
    }
    if(Array.isArray(currentUser?.user_metadata?.completed_order_ids)){
      meta.completed_order_ids=[...new Set(currentUser.user_metadata.completed_order_ids.map(x=>String(x||'').trim()).filter(Boolean))];
    }
    currentUser={...currentUser,user_metadata:meta};

    // Persist only this authenticated member's identity.
    if(name||phone){
      const member={name,phone,email};
      if(email)localStorage.setItem("bh_member_email_"+email,JSON.stringify(member));
      if(phone)localStorage.setItem("bh_member_"+phone.replace(/[^\d]/g,""),JSON.stringify(member));
      localStorage.setItem("bh_current_member",JSON.stringify(member));
    }

    // Paint the profile immediately so it cannot remain blank while another
    // Supabase request is running.
    const safeName=name||"Nama Pengguna";
    const safePhone=phone||"Nomor telepon belum tersimpan";
    const pn=document.getElementById("profileName");
    const pp=document.getElementById("profilePhone");
    const pa=document.getElementById("profileAvatar");
    const hn=document.getElementById("homeName");
    const ha=document.getElementById("homeAvatar");
    if(pn)pn.textContent=safeName;
    if(pp)pp.textContent=safePhone;
    if(pa)pa.textContent=initials(safeName);
    if(hn)hn.textContent=safeName;
    if(ha)ha.textContent=initials(safeName);

    return {name,phone};
  }catch(e){
    console.warn("Identity hydration gagal:",e);
    return {name:"",phone:""};
  }
}

async function readProfileCompletedCount(){
  if(!currentUser?.id)return 0;
  try{
    let {data}=await sb.from('profiles').select('*').eq('user_id',currentUser.id).maybeSingle();
    if(!data){ const retry=await sb.from('profiles').select('*').eq('id',currentUser.id).maybeSingle(); data=retry.data; }
    if(!data)return 0;
    const values=COMPLETED_COUNT_KEYS.map(k=>Number(data[k])||0);
    return Math.max(0,...values);
  }catch(_){return 0;}
}

async function loadCurrentProfile(){
  if(!currentUser?.id)return;
  try{
    let {data,error}=await sb.from("profiles").select("*").eq("id",currentUser.id).maybeSingle();
    if(error || !data){
      const retry=await sb.from("profiles").select("*").eq("user_id",currentUser.id).maybeSingle();
      data=retry.data;
    }
    if(data){
      const meta={...(currentUser.user_metadata||{})};
      const existingName=meta.full_name||meta.name||meta.nama;
      const existingPhone=meta.phone_number||meta.phone||meta.no_hp||meta.nomor_hp;
      const name=data.full_name||data.name||data.nama||data.display_name||data.nama_lengkap;
      const phone=data.phone_number||data.phone||data.no_hp||data.nomor_hp||data.whatsapp;
      // Registration metadata is authoritative. Only use profiles as a fallback
      // when the authenticated account does not already contain the value.
      if(!existingName && name)meta.full_name=name;
      if(!existingPhone && phone)meta.phone_number=phone;
      currentUser={...currentUser,user_metadata:meta};

      try{
        const resolvedName=meta.full_name||meta.name||meta.nama||"";
        const resolvedPhone=meta.phone_number||meta.phone||meta.no_hp||meta.nomor_hp||"";
        if(resolvedName||resolvedPhone){
          const member={name:resolvedName,phone:resolvedPhone,email:currentUser?.email||""};
          if(resolvedPhone)localStorage.setItem("bh_member_"+resolvedPhone,JSON.stringify(member));
          if(member.email)localStorage.setItem("bh_member_email_"+member.email.toLowerCase(),JSON.stringify(member));
        }
      }catch(e){console.warn("Profil cache gagal:",e)}
    }
  }catch(e){console.warn("Profil tidak dapat dimuat:",e)}
}
async function loadPublicWithdrawals(){
  // Data yang diminta pengguna selalu tersedia di halaman Beranda.
  const demo=DEMO_PUBLIC_WITHDRAWALS.map(x=>({...x}));
  state.publicWithdrawals=demo;
  try{
    const {data,error}=await sb.from("withdrawals_public")
      .select("*").order("created_at",{ascending:false}).limit(100);
    if(!error && Array.isArray(data) && data.length){
      const remote=data.map(withdrawalRow).filter(x=>Number(x.amount)>0);
      // Data yang diminta tetap ditampilkan, lalu data Supabase menyusul.
      state.publicWithdrawals=[...demo,...remote].slice(0,100);
    }
  }catch(e){
    console.warn("Data penarikan publik belum tersedia:",e);
  }
  renderWithdrawalTicker();
}
let __bhStartAppPromise=null;
async function initializeFreshMemberAccount(){
  if(!currentUser?.id)return false;
  const meta=currentUser?.user_metadata||{};
  if(meta.bh_needs_initialization!==true)return false;

  // AKUN BARU: reset state RAM terlebih dahulu. Ini wajib dilakukan sebelum
  // membaca wallet/order apa pun agar state global dari akun sebelumnya tidak
  // pernah masuk ke akun baru, bahkan jika query Supabase gagal/RLS menolak.
  state.balance=0;
  state.totalCommission=0;
  state.tx=[];
  state.bank=null;
  state.vouchers=0;
  state.completedOrders=0;
  state.currentTaskIndex=0;
  state.tasks=TASKS.map((x,i)=>({...x,status:i===0?'offered':'hidden'}));
  state.walletDbLoaded=false;
  __bhLastVerifiedWalletBalance=null;
  __bhLastVerifiedWalletAt=0;

  // Hanya namespace UID akun baru yang dibersihkan.
  try{
    localStorage.removeItem(walletStorageKey());
    localStorage.removeItem(walletBalanceStorageKey());
    localStorage.removeItem(orderStorageKey());
    localStorage.removeItem(completedCountStorageKey());
    localStorage.removeItem(voucherStorageKey());
  }catch(_){ }

  // Buat/overwrite wallet akun baru secara eksplisit menjadi nol.
  try{
    const base={user_id:String(currentUser.id),balance:0,total_commission:0,updated_at:new Date().toISOString()};
    let r=await sb.from('wallets').upsert({...base,completed_orders:0},{onConflict:'user_id'}).select('*').maybeSingle();
    if(r.error){
      r=await sb.from('wallets').upsert(base,{onConflict:'user_id'}).select('*').maybeSingle();
    }
    if(r.error) console.warn('Wallet akun baru gagal diinisialisasi:',r.error);
  }catch(e){console.warn('Inisialisasi wallet akun baru gagal:',e)}

  // Simpan keadaan nol hanya ke namespace UID ini.
  saveOrdersForCurrentAccount();
  saveWalletForCurrentAccount();

  // Tandai bahwa reset akun baru sudah selesai. Counter tetap nol sampai
  // pesanan benar-benar selesai.
  try{
    const updated=await sb.auth.updateUser({data:{
      ...(currentUser?.user_metadata||{}),
      bh_needs_initialization:false,
      bh_account_initialized:true,
      bh_completed_order_count:0,
      completed_orders:0,
      bh_completed_order_ids:[],
      completed_order_ids:[]
    }});
    if(!updated.error && updated.data?.user)currentUser=updated.data.user;
  }catch(e){console.warn('Marker akun baru belum tersimpan:',e)}
  return true;
}
async function startApp(user){
  if(__bhStartAppPromise){
    try{ await __bhStartAppPromise; }catch(_){ }
    return;
  }
  let release;
  __bhStartAppPromise=new Promise(resolve=>{release=resolve;});
  try{
    currentUser=user;
    window.__bhServerCompletedCount=0;
    document.getElementById("authView").classList.add("hidden");
    // Jangan tampilkan DOM member sebelumnya sebelum UID aktif selesai
    // dihidrasi. Ini mencegah saldo/SELESAI lama terlihat sesaat setelah
    // daftar atau login.
    document.getElementById("appView").classList.remove("hidden");
    // Bersihkan tampilan lama sementara UID aktif sedang dihidrasi.
    // Jangan tampilkan saldo/SELESAI/transaksi member sebelumnya.
    try{
      const hb=document.getElementById("homeBalance");
      const wb=document.getElementById("walletBalance");
      // Member baru selalu mulai dari saldo 0. Jangan tampilkan
      // "Memuat…" sebagai nilai saldo.
      if(hb)hb.textContent=rupiah(0);
      if(wb)wb.textContent=rupiah(0);
      const txBox=document.getElementById("transactions");
      if(txBox)txBox.innerHTML='<div style="text-align:center;color:#aaa;padding:30px 10px">Memuat transaksi…</div>';
      const done=document.getElementById("homeDone");
      if(done)done.textContent="0";
    }catch(_){}

    // Pastikan state RAM selalu dimulai dari kosong sebelum identitas akun
    // dipakai. Ini mencegah saldo/transaksi akun sebelumnya bocor ke akun baru.
    state.balance=0;
    state.totalCommission=0;
    state.tx=[];
    state.bank=null;
    state.vouchers=0;
    state.completedOrders=0;
    state.currentTaskIndex=0;
    state.walletDbLoaded=false;
    state.tasks=TASKS.map((x,i)=>({...x,status:i===0?'offered':'hidden'}));
    __bhLastVerifiedWalletBalance=null;
    __bhLastVerifiedWalletAt=0;

    await hydrateCurrentIdentity(user);

    // Setelah UID aktif diketahui, ambil rekening terakhir milik akun ini
    // dari Supabase. State lokal hanya menjadi cache tampilan.
    await loadBankAccountFromSupabase();

    // Akun yang baru dibuat tetapi pernah diuji dengan versi lama bisa sudah
    // kehilangan marker bh_needs_initialization. Kenali akun yang sangat baru
    // dari auth.created_at agar data demo lama tidak ikut terbawa pada login
    // pertamanya. Setelah lewat masa ini, akun lama tidak disentuh.
    // Tentukan status akun BARU sebelum membaca/merestorasi counter pesanan.
    // Akun yang benar-benar baru (<30 menit) harus mulai dari nol walaupun
    // metadata dari percobaan versi lama pernah tertulis tidak benar.
    let recentSignup=false;
    let freshMemberSignature=false;
    try{
      const created=Date.parse(currentUser?.created_at||'');
      const age=Number.isFinite(created) ? Date.now()-created : Infinity;
      recentSignup=Number.isFinite(created) && age>=0 && age<30*60*1000;
      const meta=currentUser?.user_metadata||{};
      // recentSignup hanya dipakai untuk mengenali akun yang benar-benar
      // belum pernah diinisialisasi. Jangan reset setiap kali Chrome dibuka
      // selama umur akun masih <30 menit, karena saldo voucher/aktivitas
      // yang sudah tersimpan di Supabase harus tetap dipertahankan.
      freshMemberSignature = (
        meta.bh_needs_initialization===true ||
        meta.bh_new_member_v2===true ||
        (recentSignup && meta.bh_account_initialized!==true)
      );
      if(freshMemberSignature && meta.bh_needs_initialization!==true){
        currentUser={...currentUser,user_metadata:{...meta,bh_needs_initialization:true,bh_new_member_v2:true}};
      }
    }catch(_){ }

    const freshMember=await initializeFreshMemberAccount();
    const freshMemberFinal=Boolean(freshMember || freshMemberSignature);
    if(freshMemberFinal && !freshMember){
      await initializeFreshMemberAccount();
    }

    // Setelah identitas dan UID benar-benar diketahui, baru baca namespace
    // akun tersebut. Tidak pernah membaca bh_balance/bh_tx global sebagai data akun.
    loadWalletForCurrentAccount();
    await loadWalletFromSupabase();
    loadOrdersForCurrentAccount();

    // Guard akun baru: jika freshMemberFinal sudah ditentukan, jangan pernah
    // membiarkan data wallet/order yang baru saja terbaca mengubahnya kembali.
    if(freshMemberFinal){
      // Jangan biarkan wallet lama/komisi bocor dipakai sebagai saldo member baru.
      // Reset hanya UID yang sedang login.
      state.balance=0;
      state.totalCommission=0;
      state.tx=[];
      state.bank=null;
      state.vouchers=0;
      state.completedOrders=0;
      state.tasks=TASKS.map((x,i)=>({...x,status:i===0?'offered':'hidden'}));
      state.currentTaskIndex=0;
      state.walletDbLoaded=true;
      try{
        localStorage.removeItem(walletStorageKey());
        localStorage.removeItem(walletBalanceStorageKey());
        localStorage.removeItem(orderStorageKey());
        localStorage.removeItem(completedCountStorageKey());
        localStorage.removeItem(voucherStorageKey());
      }catch(_){ }
      try{
        const base={user_id:String(currentUser.id),balance:0,total_commission:0,completed_orders:0,updated_at:new Date().toISOString()};
        const wr=await sb.from('wallets').upsert(base,{onConflict:'user_id'});
        if(wr.error) console.warn('Reset wallet member baru gagal:',wr.error);
      }catch(e){ console.warn('Reset wallet member baru gagal:',e); }
      saveWalletForCurrentAccount();
      saveOrdersForCurrentAccount();
      try{
        const metaNext={...(currentUser?.user_metadata||{}),bh_new_member_v2:false,bh_needs_initialization:false,bh_account_initialized:true,bh_completed_order_count:0,completed_orders:0,bh_completed_order_ids:[],completed_order_ids:[],bh_tx_history:[]};
        const ur=await sb.auth.updateUser({data:metaNext});
        if(!ur.error && ur.data?.user) currentUser=ur.data.user;
      }catch(e){ console.warn('Marker member baru gagal:',e); }
    }

    // Akun baru harus tetap kosong setelah seluruh proses loading selesai.
    if(freshMemberFinal){
      state.balance=0;
      state.totalCommission=0;
      state.tx=[];
      state.bank=null;
      state.vouchers=0;
      state.completedOrders=0;
      state.tasks=TASKS.map((x,i)=>({...x,status:i===0?'offered':'hidden'}));
      state.currentTaskIndex=0;
      state.walletDbLoaded=true;
      saveWalletForCurrentAccount();
      saveOrdersForCurrentAccount();
    }else{
      const walletCompleted=await readWalletCompletedCount();
      state.completedOrders=Math.max(Number(state.completedOrders)||0,walletCompleted);
      restoreCompletedTasksFromDurableCount(state.completedOrders);
      migrateSecondOrderWithoutReset();

      // Hanya untuk akun lama: pertahankan data wallet/order akun itu sendiri.
      // Jangan merekonstruksi saldo dari task lokal jika wallet Supabase sudah ada.
      if(state.walletDbLoaded){
        syncWalletBalanceFromLedger();
      }else{
        // Jika wallet server tidak dapat dibaca, gunakan hanya namespace lokal
        // akun aktif yang sudah dimuat; jangan gunakan state global/akun lain.
        syncWalletBalanceFromLedger();
      }

      const profileCompleted=await readProfileCompletedCount();
      state.completedOrders=Math.max(
        Number(state.completedOrders)||0,
        readRemoteCompletedCount(),
        profileCompleted,
        readPersistedCompletedCount(),
        calculateCompletedOrderCount()
      );

      syncCompletedOrdersFromLedger();

      // Rekonsiliasi transaksi hanya untuk akun lama. Akun baru tidak boleh
      // dibuatkan refund/komisi dari task demo.
      await repairCompletedOrderCommissions();
      syncCompletedOrdersFromLedger();

      // Simpan wallet akun lama setelah seluruh sumber data akun tersebut selesai.
      await persistWalletToSupabase();
    }

    // Hapus legacy global storage setelah state akun aktif sudah aman. Data ini
    // tidak pernah dipakai sebagai sumber akun.
    try{
      localStorage.removeItem("bh_balance");
      localStorage.removeItem("bh_tx");
      localStorage.removeItem("bh_bank");
      localStorage.removeItem("bh_used_vouchers");
      localStorage.removeItem("bh_vouchers");
    }catch(_){ }

    try{
      const fresh=await sb.auth.getUser();
      if(fresh?.data?.user)currentUser=fresh.data.user;
    }catch(_){ }

    if(freshMemberFinal){
      state.balance=0;
      state.totalCommission=0;
      state.tx=[];
      state.bank=null;
      state.vouchers=0;
      state.completedOrders=0;
      try{localStorage.setItem(completedCountStorageKey(),'0');}catch(_){ }
    }else{
      const durableMetaCount=getDurableCompletedCount();
      state.completedOrders=Math.max(Number(state.completedOrders)||0,durableMetaCount,calculateCompletedOrderCount());
      restoreCompletedTasksFromDurableCount(state.completedOrders);
    }

    // Pastikan cache wallet/transaksi sudah terhidrasi SEBELUM Beranda pertama
    // dirender. Dengan begitu saldo/riwayat tidak sempat tampil kosong lalu
    // baru muncul setelah pindah menu.
    await stabilizeWalletUI(false);

    // Penting: v10 sudah menunggu wallet, tetapi completed_orders belum
    // mempunyai retry khusus. Ambil ulang counter server sebelum Beranda
    // pertama kali dirender agar login ulang tidak berhenti di 0.
    if(!freshMemberFinal){
      await hydrateCompletedCountForCurrentUser();
    }

    // Login ulang: ambil counter selesai langsung dari row wallets setelah
    // seluruh identitas akun aktif terpasang. Ini mencegah cache order lokal
    // bernilai 0 menimpa completed_orders=2 yang sudah tersimpan di Supabase.
    if(!freshMemberFinal){
      const serverCompleted=await readWalletCompletedCount();
      if(serverCompleted>0){
        state.completedOrders=Math.max(Number(state.completedOrders)||0,serverCompleted);
        restoreCompletedTasksFromDurableCount(state.completedOrders);
        saveOrdersForCurrentAccount();
      }
    }

    refreshAll();
    await loadPublicWithdrawals();
    refreshAll();
    openPage("home");
    startBanner();
    orderTab="available";
    // Akun baru harus benar-benar kosong. Jangan menjalankan rekonsiliasi
    // pesanan lama pada sesi pendaftaran baru. Pesanan pertama akan dibuat
    // saat member benar-benar mulai mengerjakannya.
    if(!freshMemberFinal){
      reconcileOrderChain();
      startMerchantFlow();
      renderOrders();
      resumeOrderFlowAfterReload();
    }else{
      state.tasks=TASKS.map((x,i)=>({...x,status:i===0?'offered':'hidden'}));
      state.currentTaskIndex=0;
      state.completedOrders=0;
      state.balance=0;
      state.totalCommission=0;
      state.tx=[];
      refreshAll();
      renderOrders();
    }

    // Data akun aktif sudah selesai dihidrasi; render state final.
    refreshAll();
    renderTx();
    document.getElementById("appView").classList.remove("hidden");
    startDepositLiveSync();
    startWithdrawalLiveSync();

    // Final guard for slow login sessions: if Supabase responds after the
    // first paint, repaint only the completed counter without touching balance.
    if(!freshMemberFinal){
      hydrateCompletedCountForCurrentUser().then(()=>{
        updateHomeCompletedCount();
        const finalDone=document.getElementById('homeDone');
        if(finalDone)finalDone.textContent=String(state.completedOrders);
      }).catch(()=>{});
    }

  }catch(e){
    console.error("startApp gagal:",e);
    // Jangan biarkan layar kosong. Tampilkan state netral akun aktif.
    try{
      document.getElementById("appView").classList.remove("hidden");
      refreshAll();
      renderTx();
      openPage("home");
    }catch(_){}
  }finally{
    release();
    __bhStartAppPromise=null;
  }
}

// Final UI hydration: setelah login/reload, beberapa proses async (Supabase,
// pemulihan order, dan banner) dapat selesai sedikit setelah Beranda pertama
// dirender. Pastikan saldo + transaksi lokal akun aktif dicat ulang setelah
// semua proses tersebut selesai, tanpa mengubah data server.
let __bhWalletHydrationTimer=null;
async function stabilizeWalletUI(render=true){
  if(!currentUser?.id)return;
  const waits=[0,150];
  for(const wait of waits){
    if(wait) await new Promise(r=>setTimeout(r,wait));
    try{
      // Pulihkan cache transaksi/saldo akun yang sama terlebih dahulu.
      loadWalletForCurrentAccount();
      // Supabase tetap menjadi sumber kebenaran saldo.
      await loadWalletFromSupabase();
      // Jangan membangun transaksi dari akun lain. Render hanya bila diminta.
      if(render){
        refreshAll();
        forceWalletBalanceUI();
        renderTx();
      }
    }catch(e){
      console.warn("Hydrasi ulang wallet UI:",e);
    }
  }
}

function initials(name){return String(name||"B").trim().charAt(0).toUpperCase()}
let bannerIndex=0;
function showBanner(index){
  bannerIndex=index;
  const track=document.getElementById("homeBannerTrack");
  if(track)track.style.transform="translateX(-"+(index*50)+"%)";
  document.querySelectorAll(".banner-dot").forEach((d,i)=>d.classList.toggle("active",i===index));
}
function startBanner(){
  clearInterval(window.__bannerTimer);
  showBanner(bannerIndex);
  window.__bannerTimer=setInterval(()=>{
    if(document.visibilityState!=="hidden"){
      showBanner((bannerIndex+1)%2);
    }
  },3500);
}


function updateHomeCompletedCount(){
  try{
    syncCompletedOrdersFromLedger();

    const taskDone = Array.isArray(state.tasks)
      ? state.tasks.filter(t => t && t.status === "done").length
      : 0;

    const completedRecords = (() => {
      try { return getCompletedOrderRecords().length; }
      catch(_) { return 0; }
    })();

    const storedDone = Number(state.completedOrders) || 0;
    const durableMetaCount=getDurableCompletedCount();
    const serverSnapshot = Math.max(0, Number(window.__bhServerCompletedCount||0) || 0);
    const completed = Math.max(
      storedDone,
      durableMetaCount,
      readPersistedCompletedCount(),
      taskDone,
      completedRecords,
      serverSnapshot
    );

    const el = document.getElementById("homeDone");
    if(el) el.textContent = String(completed);

    // Keep the persisted per-account value in sync with the same source.
    if(completed !== storedDone){
      state.completedOrders = completed;
      saveOrdersForCurrentAccount();
    }

    return completed;
  }catch(err){
    console.warn("Gagal memperbarui jumlah pesanan selesai:", err);
    return Number(state.completedOrders) || 0;
  }
}

function refreshAll(){
  syncCompletedOrdersFromLedger();
  const profile=getRegisteredProfile();
  const name=String(profile.name||document.getElementById("profileName")?.textContent||"Nama Pengguna").trim() || "Nama Pengguna";
  const phone=String(profile.phone||document.getElementById("profilePhone")?.textContent||"Nomor telepon belum tersimpan").trim() || "Nomor telepon belum tersimpan";
  document.getElementById("homeName").textContent=name;
  document.getElementById("homeAvatar").textContent=initials(name);
  document.getElementById("profileName").textContent=name;
  document.getElementById("profilePhone").textContent=phone;
  document.getElementById("profileAvatar").textContent=initials(name);

  try{
    const email=String(currentUser?.email||"").toLowerCase();
    if(profile.name||profile.phone){
      const member={name:profile.name||"",phone:profile.phone||"",email};
      if(email)localStorage.setItem("bh_member_email_"+email,JSON.stringify(member));
      if(profile.phone)localStorage.setItem("bh_member_"+String(profile.phone).replace(/[^\d]/g,""),JSON.stringify(member));
      localStorage.setItem("bh_current_member",JSON.stringify(member));
    }
  }catch(_){}

 // Saldo selalu mengikuti ledger akun aktif.
 // Ini mencegah saldo lama (mis. Rp30.000) tetap tampil walaupun
 // transaksi pembayaran dan komisi sudah tercatat.
 syncWalletBalanceFromLedger();

 const offered=state.tasks.filter(x=>x.status==="offered").length;
 const active=state.tasks.filter(x=>x.status==="active").length;
 const waiting=state.tasks.filter(x=>x.status==="processing_wait").length;
 const shipping=state.tasks.filter(x=>x.status==="shipping").length;
 syncCompletedOrdersFromLedger();
 const done=updateHomeCompletedCount();
 const cancelled=state.tasks.filter(x=>x.status==="cancelled"||x.status==="canceled").length;

 document.getElementById("statTask").textContent=offered;
 document.getElementById("statActive").textContent=active+waiting+shipping;
 document.getElementById("homeDone").textContent=done;
 document.getElementById("statVoucher").textContent=state.vouchers;

 document.getElementById("homeNeed").textContent=15;
 document.getElementById("homeCancel").textContent=cancelled;
 document.getElementById("homeDone").textContent=done;
 document.getElementById("homeReview").textContent=state.tasks.filter(x=>x.reviewed===true).length;

 renderHomeTasks();renderOrders();renderTx();renderWithdrawalTicker();
 // Final authoritative update for the Beranda counter.
 const homeDoneEl=document.getElementById("homeDone");
 if(homeDoneEl) homeDoneEl.textContent=String(updateHomeCompletedCount());
}

function openVoucherCenter(){
  const modal=document.querySelector("#modal .modal");
  if(modal)modal.classList.add("voucher-modal");
  document.getElementById("modalTitle").textContent="";
  document.getElementById("modalBody").innerHTML=`
    <div class="voucher-head">
      <div class="voucher-icon">🎟️</div>
      <h3>Masukkan Kode Voucher</h3>
      <p>Klaim voucher Anda dan saldo akan masuk ke Dompet setelah berhasil.</p>
      <button class="close" aria-label="Tutup" onclick="closeModal()">×</button>
    </div>
    <div class="voucher-content">
      <div id="voucherResult" class="voucher-result" role="status" aria-live="polite"></div>
      <label class="voucher-label" for="manualVoucher">Kode Voucher</label>
      <div class="voucher-input-wrap">
        <input id="manualVoucher" type="text" maxlength="12" autocomplete="off" autocapitalize="characters" placeholder="MASUKKAN KODE VOUCHER">
      </div>
      <div class="voucher-hint">Masukkan kode voucher dengan benar. Sistem akan memberi tanda <b>berhasil</b>, <b>kode salah</b>, atau <b>sudah digunakan</b>.</div>
      <button class="voucher-submit" onclick="redeemManualVoucher()">Klaim Voucher</button>
    </div>`;
  showModal();
  setTimeout(()=>document.getElementById("manualVoucher")?.focus(),120);
}
function showVoucherResult(type,icon,title,message){
  const el=document.getElementById("voucherResult");
  if(!el)return;
  el.className="voucher-result show "+type;
  el.innerHTML='<span class="result-icon">'+icon+'</span><b>'+title+'</b><br>'+message;
}

function showVoucherSuccessOverlay(amount){
  let overlay=document.getElementById("voucherSuccessOverlay");
  if(!overlay){
    overlay=document.createElement("div");
    overlay.id="voucherSuccessOverlay";
    overlay.innerHTML=`<div class="voucher-success-card">
      <div class="voucher-success-check">✓</div>
      <h3 id="voucherSuccessTitle">Voucher Berhasil Diklaim!</h3>
      <p>Voucher berhasil diproses dan saldo telah ditambahkan ke Dompet.</p>
      <span id="voucherSuccessAmount" class="success-amount">+ Rp 0</span>
      <span class="success-note">Saldo sudah berhasil masuk ke akun Anda.</span>
      <button type="button" onclick="closeVoucherSuccessOverlay()">Selesai</button>
    </div>`;
    document.body.appendChild(overlay);
  }
  const amountEl=document.getElementById("voucherSuccessAmount");
  if(amountEl) amountEl.textContent="+ "+rupiah(amount);
  // Inline fallback memastikan overlay tetap terlihat walaupun CSS lama/cache bermasalah.
  Object.assign(overlay.style,{
    position:"fixed", inset:"0", zIndex:"2147483647", display:"flex",
    alignItems:"center", justifyContent:"center", padding:"22px",
    background:"rgba(10,28,58,.62)", boxSizing:"border-box",
    visibility:"visible", opacity:"1", pointerEvents:"auto"
  });
  overlay.classList.add("show");
  requestAnimationFrame(()=>overlay.classList.add("show"));
}
function closeVoucherSuccessOverlay(){
  const overlay=document.getElementById("voucherSuccessOverlay");
  if(overlay){ overlay.classList.remove("show"); overlay.style.display="none"; }
}

async function redeemManualVoucher(){
  const input=document.getElementById("manualVoucher");
  const code=String(input?.value||"").trim().toUpperCase();

  const rewards={
    HFDJXI:{amount:30000,required:0},
    MXKSOA:{amount:250000,required:5},
    NJNXSJ:{amount:750000,required:10},
    NDJJDC:{amount:2500000,required:15}
  };

  const reward=rewards[code];
  if(!code){
    showVoucherResult("warning","⚠️","Kode belum diisi","Silakan masukkan kode voucher terlebih dahulu.");
    input?.focus();
    return;
  }
  if(!reward){
    showVoucherResult("error","✕","Kode voucher salah","Kode yang Anda masukkan tidak valid. Periksa kembali kode voucher Anda.");
    input?.focus();
    return;
  }

  const used=getUsedVouchersForCurrentAccount();
  if(used.includes(code)){
    showVoucherResult("error","✓","Kode sudah digunakan","Voucher ini sudah pernah diklaim pada akun ini dan tidak dapat digunakan kembali.");
    return;
  }

  const completed=state.tasks.filter(x=>x.status==="done").length;
  if(completed<reward.required){
    const remaining=reward.required-completed;
    showVoucherResult("warning","🔒","Voucher belum dapat diklaim","Selesaikan "+remaining+" pesanan lagi untuk memenuhi syarat voucher ini.");
    return;
  }

  const amount=Number(reward.amount);

  // === BERHASIL: ubah state, lalu WAJIB verifikasi penyimpanan ke Supabase.
  // Jika Supabase menolak write/RLS/schema, semua perubahan lokal dibatalkan
  // sehingga UI tidak pernah mengatakan voucher berhasil padahal saldo belum
  // tersimpan di database.
  const previousBalance=Number(state.balance)||0;
  const previousCommission=Number(state.totalCommission)||0;
  const previousVouchers=Number(state.vouchers)||0;
  const previousTx=Array.isArray(state.tx)?state.tx.slice():[];

  state.vouchers=previousVouchers+1;
  state.tx.unshift({
    name:"Voucher "+code,
    amount:amount,
    type:"plus",
    date:new Date().toISOString(),
    account_id:String(currentUser?.id||currentUser?.email||""),
    description:"Klaim voucher"
  });
  state.balance=previousBalance+amount;

  let persisted=false;
  try{
    saveWalletForCurrentAccount();
    persisted=await persistWalletToSupabase();
  }catch(e){
    console.error("Saldo voucher belum tersimpan ke Supabase:",e);
    persisted=false;
  }

  if(!persisted){
    // Rollback karena database belum benar-benar menyimpan saldo.
    state.balance=previousBalance;
    state.totalCommission=previousCommission;
    state.vouchers=previousVouchers;
    state.tx=previousTx;
    saveWalletForCurrentAccount();

    showVoucherResult(
      "error",
      "✕",
      "Voucher belum berhasil disimpan",
      "Database Supabase belum menerima perubahan saldo. Klaim dibatalkan. Silakan coba lagi setelah koneksi/database siap."
    );
    return;
  }

  // Tandai voucher sudah digunakan hanya setelah write Supabase terverifikasi.
  try{
    used.push(code);
    saveUsedVouchersForCurrentAccount(used);
  }catch(e){
    console.warn("Riwayat voucher belum tersimpan lokal:",e);
  }
  try{ save(); }catch(e){ console.warn("State voucher belum tersimpan:",e); }

  // === PENTING: tampilkan pemberitahuan SUKSES TERLEBIH DAHULU ===
  // Jangan menunggu refresh/render karena error pada UI lain tidak boleh
  // menghilangkan konfirmasi bahwa klaim sudah berhasil.
  const result=document.getElementById("voucherResult");
  if(result){
    result.className="voucher-result show success";
    result.innerHTML='<span class="result-icon">✓</span>'+
      '<b>Voucher Berhasil Diklaim!</b>'+
      '<span class="voucher-success-amount">+ '+rupiah(amount)+'</span>'+
      '<span class="voucher-success-note">Saldo sudah berhasil masuk ke Dompet Anda.</span>'+
      '<button type="button" class="voucher-success-close" onclick="closeModal()">Selesai</button>';
    result.style.cssText += ';display:block!important;visibility:visible!important;opacity:1!important;';
    result.setAttribute("aria-live","assertive");
  }
  if(input){ input.value=code; input.disabled=true; input.setAttribute("aria-label","Voucher berhasil diklaim"); }
  const submit=document.querySelector(".voucher-submit");
  if(submit){
    submit.disabled=true;
    submit.textContent="✓ Voucher Berhasil Diklaim";
    submit.style.cssText += ';background:linear-gradient(135deg,#16824b,#25a865)!important;color:#fff!important;opacity:1!important;';
    submit.style.cursor="default";
  }

  // Popup konfirmasi besar di tengah layar. Ini dipanggil sebelum refreshAll().
  showVoucherSuccessOverlay(amount);
  toast("✓ Voucher berhasil diklaim. Saldo bertambah "+rupiah(amount)+".");

  // Perbarui saldo DOM secara langsung setelah Supabase sudah terverifikasi.
  // Ini tidak menunggu pengguna pindah ke menu Dompet atau me-refresh halaman.
  forceWalletBalanceUI();
  try{ refreshAll(); }catch(e){ console.warn("Refresh UI setelah voucher gagal:",e); }
  forceWalletBalanceUI();
  try{ renderTx(); }catch(e){ console.warn("Render transaksi setelah voucher gagal:",e); }

  // Sinkronisasi ulang singkat untuk mencegah race dengan proses inisialisasi
  // akun yang masih berjalan pada browser content://.
  reSyncWalletAfterVoucher(state.balance).catch(e=>console.warn("Resync voucher:",e));
}
function openVerification(step=1){
  window.verifyStep = step;
  document.getElementById("modalTitle").textContent="Pusat Verifikasi";
  renderVerificationStep(step);
  showModal();
}
function renderVerificationStep(step){
  window.verifyStep=step;
  const b=state.bank||{};
  const banks=[
    "Bank Central Asia (BCA)","Bank Mandiri","Bank Negara Indonesia (BNI)",
    "Bank Rakyat Indonesia (BRI)","CIMB Niaga","Bank Tabungan Negara (BTN)",
    "Bank Syariah Indonesia (BSI)","Bank Permata","Bank Danamon",
    "Bank Panin","Bank OCBC NISP","Bank Mega","Bank Jago","Bank Neo Commerce",
    "Bank Seabank Indonesia","Bank Bukopin","Bank Muamalat","Bank Sinarmas",
    "Bank Maybank Indonesia","Bank Commonwealth"
  ];
  const wallets=["DANA","GoPay","LinkAja","ShopeePay"];
  const bankOptions=banks.map(x=>`<option ${b.bank===x?"selected":""}>${x}</option>`).join("");
  const walletOptions=wallets.map(x=>`<option ${b.bank===x?"selected":""}>${x}</option>`).join("");

  const steps=`
    <div class="verify-steps">
      <div class="verify-step ${step>=1?"active":""}"><div class="verify-circle">1</div>DATA</div>
      <div class="verify-step ${step>=2?"active":""}"><div class="verify-circle">2</div>BANK</div>
      <div class="verify-step ${step>=3?"active":""}"><div class="verify-circle">3</div>BERKAS</div>
    </div>`;

  let body="";
  if(step===1){
    body=`
      <div class="verify-note"><b>ⓘ Tujuan:</b> Langkah ini bertujuan untuk mencocokkan identitas Anda dengan sistem kami guna memastikan kepemilikan akun yang valid.</div>
      <div class="verify-section-title">NAMA LENGKAP (SESUAI KTP)</div>
      <input id="verifyName" value="${nameOf()||""}" placeholder="Masukkan nama sesuai KTP">
      <div class="verify-section-title">NIK (16 DIGIT)</div>
      <input id="verifyNik" inputmode="numeric" maxlength="16" placeholder="Masukkan 16 digit NIK">
      <button class="verify-primary" style="width:100%;margin-top:14px" onclick="saveVerifyDataAndNext()">Lanjutkan →</button>`;
  }else if(step===2){
    body=`
      <div class="verify-note"><b>ⓘ Tujuan:</b> Verifikasi rekening diperlukan untuk memastikan bahwa data keuangan yang terdaftar sudah benar dan menghindari kesalahan pengiriman dana di masa depan.</div>
      <div class="verify-section-title">JENIS PENCAIRAN</div>
      <select id="accountType" onchange="toggleAccountType()">
        <option value="bank" ${(!b.type||b.type==="bank")?"selected":""}>Rekening Bank</option>
        <option value="ewallet" ${b.type==="ewallet"?"selected":""}>E-Wallet</option>
      </select>
      <div class="verify-section-title">PILIH BANK / E-WALLET</div>
      <select id="verifyAccountName">
        <option value="">-- Pilih --</option>
        ${bankOptions}
        <optgroup label="E-Wallet">${walletOptions}</optgroup>
      </select>
      <div class="verify-section-title">NOMOR REKENING / NOMOR E-WALLET</div>
      <input id="verifyAccountNumber" inputmode="numeric" value="${b.number||""}" placeholder="Masukkan nomor rekening atau nomor HP">
      <div class="verify-section-title">NAMA PEMILIK</div>
      <input id="verifyOwner" value="${b.owner||nameOf()||""}" placeholder="Nama pemilik rekening">
      <div class="verify-actions">
        <button class="verify-back" onclick="renderVerificationStep(1)">Kembali</button>
        <button class="verify-primary" onclick="saveVerifyBankAndNext()">Lanjutkan →</button>
      </div>`;
  }else{
    body=`
      <div class="verify-note"><b>ⓘ Tujuan:</b> Dokumentasi visual diperlukan sebagai bukti fisik yang sah untuk melakukan perbaikan data dan mencegah penyalahgunaan akun oleh pihak lain.</div>
      <div class="verify-section-title">UNGGAH FOTO KTP</div>
      <input class="verify-file" id="verifyKtp" type="file" accept="image/*">
      <div class="verify-section-title">UNGGAH FOTO SELFIE</div>
      <input class="verify-file" id="verifySelfie" type="file" accept="image/*">
      <div class="verify-actions">
        <button class="verify-back" onclick="renderVerificationStep(2)">Kembali</button>
        <button class="verify-primary" onclick="submitVerification()">Kirim Verifikasi ✈</button>
      </div>`;
  }
  document.getElementById("modalBody").innerHTML=`
    <div class="verification-card">
      <h2 style="margin:0;font-size:22px;color:#171923">Pusat Verifikasi</h2>
      <div class="verification-subtitle">Validasi & Perbaikan Data Akun</div>
      ${steps}
      ${body}
    </div>`;
  if(step===2) toggleAccountType();
}
function saveVerifyDataAndNext(){
  const name=document.getElementById("verifyName").value.trim();
  const nik=document.getElementById("verifyNik").value.trim();
  if(!name)return toast("Nama lengkap wajib diisi.");
  if(!/^\d{16}$/.test(nik))return toast("NIK harus 16 digit.");
  state.verify={...(state.verify||{}),name,nik};
  save();renderVerificationStep(2);
}
function toggleAccountType(){
  const type=document.getElementById("accountType")?.value;
  const sel=document.getElementById("verifyAccountName");
  if(!sel)return;
  const bankNames=[
    "Bank Central Asia (BCA)","Bank Mandiri","Bank Negara Indonesia (BNI)",
    "Bank Rakyat Indonesia (BRI)","CIMB Niaga","Bank Tabungan Negara (BTN)",
    "Bank Syariah Indonesia (BSI)","Bank Permata","Bank Danamon","Bank Panin",
    "Bank OCBC NISP","Bank Mega","Bank Jago","Bank Neo Commerce",
    "Bank Seabank Indonesia","Bank Bukopin","Bank Muamalat","Bank Sinarmas",
    "Bank Maybank Indonesia","Bank Commonwealth"
  ];
  const wallets=["DANA","GoPay","LinkAja","ShopeePay"];
  const current=state.bank?.bank||"";
  sel.innerHTML=(type==="ewallet"
    ? wallets.map(x=>`<option ${current===x?"selected":""}>${x}</option>`).join("")
    : bankNames.map(x=>`<option ${current===x?"selected":""}>${x}</option>`).join(""));
}
function saveVerifyBankAndNext(){
  const type=document.getElementById("accountType").value;
  const bank=document.getElementById("verifyAccountName").value;
  const number=document.getElementById("verifyAccountNumber").value.trim();
  const owner=document.getElementById("verifyOwner").value.trim();
  if(!bank)return toast("Pilih bank atau e-wallet.");
  if(!number)return toast("Nomor rekening / e-wallet wajib diisi.");
  if(!owner)return toast("Nama pemilik wajib diisi.");
  state.bank={type,bank,number,owner};
  state.verify={...(state.verify||{}),accountVerified:true};
  save();renderVerificationStep(3);
}
function submitVerification(){
  const ktp=document.getElementById("verifyKtp")?.files?.[0];
  const selfie=document.getElementById("verifySelfie")?.files?.[0];
  if(!ktp||!selfie)return toast("Foto KTP dan selfie wajib diunggah.");
  state.verify={...(state.verify||{}),status:"submitted",submittedAt:new Date().toISOString()};
  save();closeModal();toast("Verifikasi berhasil dikirim.");
}
function setOrderTab(tab, btn){
  if(!['available','active','done'].includes(tab)) return;
  orderTab=tab;
  document.querySelectorAll('#pageOrders [data-tab]').forEach(b=>b.classList.toggle('active', b.dataset.tab===tab));
  renderOrders();
}
function syncOrderTabButtons(){
  document.querySelectorAll('#pageOrders [data-tab]').forEach(b=>b.classList.toggle('active', b.dataset.tab===orderTab));
}
function goToNextOrder(){
  reconcileOrderChain();
  startMerchantFlow();
  orderTab='available';
  syncOrderTabButtons();
  renderOrders();
  refreshAll();
}

function openPage(page){
 currentPage=page;
 const downloadBtn=document.getElementById("downloadAppBtn");
 if(downloadBtn) downloadBtn.classList.toggle("home-download-visible", page==="home");
 if(page==="home")startBanner();
 ["home","orders","wallet","profile"].forEach(p=>document.getElementById("page"+p.charAt(0).toUpperCase()+p.slice(1)).classList.toggle("hidden",p!==page));
 document.querySelectorAll(".bottom button").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
 document.getElementById("backBtn").style.visibility=page==="home"?"hidden":"visible";
 window.scrollTo({top:0,behavior:"smooth"});
 if(page==="home"){ refreshAll(); updateHomeCompletedCount(); }
 if(page==="orders"){ reconcileOrderChain(); syncOrderTabButtons(); renderOrders(); }
 if(page==="wallet"){ renderTx(); syncWithdrawalsFromSupabase().catch(()=>{}); }
 if(page==="profile"){ refreshAll(); }
}
function goBack(){openPage("home")}
function startMerchantFlow(){
  clearTimeout(taskFlowTimer);
  if(!Array.isArray(state.tasks)) state.tasks=[];

  // Jangan pernah membuat pesanan baru jika masih ada pesanan berjalan.
  if(state.tasks.some(t=>["active","offered","processing_wait","shipping"].includes(t?.status))) return true;

  const first=state.tasks.find(t=>String(t?.id||'')===FIRST_ORDER_ID);
  const second=state.tasks.find(t=>String(t?.id||'')===SECOND_ORDER_ID);
  const third=state.tasks.find(t=>String(t?.id||'')===THIRD_ORDER_ID);

  // Urutan wajib: pesanan 1 -> selesai -> pesanan 2 -> selesai -> pesanan 3.
  if(first && first.status!=='done'){
    if(first.status!=='offered'){
      first.status='offered';
      state.currentTaskIndex=state.tasks.indexOf(first);
      saveOrdersForCurrentAccount();
    }
    return true;
  }

  if(second && second.status!=='done'){
    second.status='offered';
    state.currentTaskIndex=state.tasks.indexOf(second);
    saveOrdersForCurrentAccount();
    return true;
  }

  if(third && third.status!=='done'){
    third.status='offered';
    state.currentTaskIndex=state.tasks.indexOf(third);
    saveOrdersForCurrentAccount();
    return true;
  }

  return false;
}

function orderImage(t){
  return t.image
    ? `<img src="${t.image}" alt="${t.name}" loading="eager">`
    : `<span>${t.emoji||'🛍️'}</span>`;
}
function taskHTML(t){
  const isOffered=t.status==='offered';
  const isActive=t.status==='active';
  const isDone=t.status==='done';
  const total=Number(t.price||0)*(Number(t.qty||1));
  const statusBadge=isOffered
    ? `<span class="order-badge new">PESANAN BARU</span>`
    : isActive
    ? `<span class="order-badge shipping">PERLU DIKIRIM</span>`
    : isDone
    ? `<span class="order-badge done">✓ SELESAI</span>` : '';
  const action=isOffered
    ? `<button class="order-primary-btn" onclick="openReceiveOrder('${t.id}')"><span>🛍️</span> Proses Pesanan</button>`
    : isActive
    ? `<button class="order-confirm-btn" onclick="finishTask('${t.id}')">Konfirmasi Pengiriman <span>›</span></button>`
    : isDone
    ? `<div class="order-done-note">✓ Pesanan selesai · Komisi <b>+ ${rupiah(t.profit)}</b></div>` : '';
  return `<article class="premium-order-card ${isActive?'is-active':''} ${isDone?'is-done':''}">
    <div class="order-card-head">
      <div class="order-head-title"><span class="order-head-icon">▤</span><div><strong>${isOffered?'PESANAN BARU':'ID PESANAN'}</strong><small>${t.id}</small></div></div>
      ${statusBadge}
    </div>
    <div class="order-product">
      <div class="order-product-image">${orderImage(t)}</div>
      <div class="order-product-info">
        <h3>${t.name}</h3>
        <div class="order-store">▣ ${t.store}</div>
        ${t.location?`<div class="order-location">⌖ ${t.location}</div>`:''}
        <div class="order-price-line"><span>Harga</span><b>${rupiah(t.price)}</b><span>Qty: x${t.qty||1}</span></div>
      </div>
    </div>
    <div class="order-summary">
      <div><span>Subtotal Produk</span><b>${rupiah(total)}</b></div>
      <div><span>Estimasi Profit (${Number(t.profitRate||20)}%)</span><b class="profit">+ ${rupiah(t.profit)}</b></div>
      <div class="order-total"><span>Total Bayar</span><b>${rupiah(total)}</b></div>
    </div>
    ${action}
  </article>`;
}
function openReceiveOrder(id){
  const t=state.tasks.find(x=>x.id===id && x.status==='offered'); if(!t)return;
  document.getElementById('modalTitle').textContent='';
  document.getElementById('modalBody').innerHTML=`
    <div class="order-flow-modal">
      <div class="flow-icon pink">🛍️</div>
      <h4>Terima Pesanan?</h4>
      <p>Pastikan Anda siap melakukan pengiriman paket sesuai area yang ditentukan.</p>
      <button class="flow-main" onclick="acceptOfferedTask('${t.id}')">Ya, Proses Sekarang</button>
      <button class="flow-secondary" onclick="closeModal()">Nanti Saja</button>
    </div>`;
  showModal();
}
async function acceptOfferedTask(id){
  const t=state.tasks.find(x=>x.status==='offered' && (!id || x.id===id));
  if(!t)return;
  const total=Number(t.price||0)*Number(t.qty||1);
  const missing=Math.max(0,total-state.balance);

  // Saldo Dompet digunakan saat pengguna benar-benar menekan "Proses Sekarang".
  if(state.balance<total){
    closeModal();
    prepareFinanceModal();
    document.getElementById('modalTitle').textContent='';
    document.getElementById('modalBody').innerHTML=`
      <div class="finance-head">
        <div class="finance-icon">💳</div>
        <h3>Saldo Tidak Cukup</h3>
        <p>Pesanan belum dapat diproses karena saldo Dompet belum mencukupi.</p>
        <button class="close" aria-label="Tutup" onclick="closeModal()">×</button>
      </div>
      <div class="finance-content">
        <div class="finance-card">
          <div class="finance-card-title">📦 ${t.name}</div>
          <div class="finance-card-text">Total pesanan <b>${rupiah(total)}</b><br>Saldo Anda <b>${rupiah(state.balance)}</b><br>Kekurangan <b style="color:#dc4b59">${rupiah(missing)}</b></div>
        </div>
        <button class="finance-submit" onclick="openTopup(${missing})">Isi Saldo ${rupiah(missing)}</button>
      </div>`;
    showModal();
    return;
  }

  // Setelah pengguna menekan "Ya, Proses Sekarang", pembayaran langsung
  // dicatat dan pesanan LANGSUNG masuk ke menu Aktif. Jangan memakai
  // processing_wait/timer di sini karena timer dapat terputus saat halaman
  // dirender ulang dan membuat alur berhenti setelah tombol ini.
  state.balance-=total;
  state.tx.unshift({
    name:'Pembayaran Pesanan: '+t.id,
    amount:total,
    type:'minus',
    date:new Date().toISOString(),
    orderId:t.id,
    description:'Pembayaran pesanan menggunakan saldo Dompet'
  });
  t.status='active';
  t.paymentAt=new Date().toISOString();
  save();
  const paymentPersisted=await persistWalletToSupabase();
  if(!paymentPersisted){
    // Jangan melanjutkan order jika pembayaran belum tersimpan di server.
    // Kembalikan state persis seperti sebelum tombol Proses ditekan.
    state.balance+=total;
    state.tx=state.tx.filter(x=>!(x && String(x.orderId||'')===String(t.id) && String(x.name||'').startsWith('Pembayaran Pesanan:')));
    t.status='offered';
    delete t.paymentAt;
    save();
    refreshAll();
    renderOrders();
    toast('⚠️ Pembayaran belum tersimpan. Pesanan belum diproses.');
    return false;
  }
  closeModal();
  orderTab='active';
  openPage('orders');
  refreshAll();
  renderOrders();
  toast('✓ Pembayaran berhasil. Pesanan masuk ke menu Aktif. Silakan Konfirmasi Pengiriman.');
}
function claimTask(id){acceptOfferedTask(id)}
function openVoucher(t){acceptOfferedTask(t&&t.id)}
function finishTask(id){
  const t=state.tasks.find(x=>x.id===id && x.status==='active');
  if(!t)return;

  // Tahap video: tombol Konfirmasi Pengiriman membuka konfirmasi terlebih dahulu.
  document.getElementById('modalTitle').textContent='';
  document.getElementById('modalBody').innerHTML=`
    <div class="order-flow-modal courier-confirm-modal">
      <div class="flow-icon pink">📦</div>
      <h4>Konfirmasi Pengiriman 💗</h4>
      <p>Pastikan pesanan <b>${t.name}</b> sudah siap untuk dikirim.</p>
      <div class="flow-mini-card">
        <b>Pesanan siap dikirim</b>
        <span>ID: ${t.id}</span>
        <span>Total: ${rupiah(Number(t.price||0)*Number(t.qty||1))}</span>
      </div>
      <button class="flow-main" onclick="confirmShipping('${t.id}')">Konfirmasi Pengiriman <span>›</span></button>
      <button class="flow-secondary" onclick="closeModal()">Kembali</button>
    </div>`;
  showModal();
}

function confirmShipping(id){
  const t=state.tasks.find(x=>x.id===id && x.status==='active');
  if(!t)return;

  t.status='shipping';
  t.courierAt=new Date().toISOString();
  saveOrdersForCurrentAccount();
  closeModal();
  orderTab='active';
  openPage('orders');
  renderOrders();
  refreshAll();
  toast('✓ Pesanan diberikan kepada kurir.');

  // PENTING: tidak ada timer otomatis. Pengguna sendiri menekan
  // "✓ Pesanan Selesai" pada tahap kurir.
  clearTimeout(taskFlowTimer);
}

function showCommissionSuccessPopup(t, profit, refund, balance){
  let overlay=document.getElementById('commissionSuccessOverlay');
  if(!overlay){
    overlay=document.createElement('div');
    overlay.id='commissionSuccessOverlay';
    overlay.innerHTML=`<div class="commission-success-card">
      <div class="commission-success-check">✓</div>
      <h3>Pesanan Berhasil Diselesaikan!</h3>
      <p>Pesanan <b id="commissionOrderId"></b> telah selesai.</p>
      <div class="commission-success-box">
        <div><span>Pengembalian Saldo</span><b id="commissionRefund">+ Rp 0</b></div>
        <div><span>Komisi yang Didapat</span><b id="commissionProfit">+ Rp 0</b></div>
        <div class="commission-success-total"><span>Saldo Dompet Sekarang</span><b id="commissionBalance">Rp 0</b></div>
      </div>
      <button type="button" onclick="closeCommissionSuccessPopup()">Lanjutkan</button>
    </div>`;
    document.body.appendChild(overlay);
  }
  document.getElementById('commissionOrderId').textContent=t.id;
  document.getElementById('commissionRefund').textContent='+ '+rupiah(refund);
  document.getElementById('commissionProfit').textContent='+ '+rupiah(profit);
  document.getElementById('commissionBalance').textContent=rupiah(balance);
  Object.assign(overlay.style,{position:'fixed',inset:'0',zIndex:'2147483647',display:'flex',alignItems:'center',justifyContent:'center',padding:'20px',background:'rgba(10,28,58,.62)',boxSizing:'border-box',visibility:'visible',opacity:'1',pointerEvents:'auto'});
  overlay.classList.add('show');
}
function closeCommissionSuccessPopup(){
  const overlay=document.getElementById('commissionSuccessOverlay');
  if(overlay){overlay.classList.remove('show');overlay.style.display='none';}

  // Pesanan berikutnya langsung ditawarkan tanpa reload halaman.
  reconcileOrderChain();
  startMerchantFlow();
  orderTab='available';
  syncOrderTabButtons();
  renderOrders();
  refreshAll();
  openPage('orders');
  orderTab='available';
  syncOrderTabButtons();
  renderOrders();
  toast('✓ Pesanan berikutnya sudah tersedia.');
}

async function finishCourierStage(id){
  // Jangan bergantung pada tab/UI saat mencari pesanan. Jika tombol terlihat
  // tetapi orderTab sempat tertinggal di "available", tetap cari pesanan
  // shipping yang sedang berjalan dan selesaikan pesanan tersebut.
  let t=state.tasks.find(x=>x && String(x.id)===String(id) && (x.status==='shipping'||x.status==='active'));
  if(!t)t=state.tasks.find(x=>x && (x.status==='shipping'||x.status==='active'));
  if(!t){
    toast('Pesanan yang akan diselesaikan tidak ditemukan.');
    return false;
  }
  clearTimeout(taskFlowTimer);

  const profit=Math.max(0,Number(t.profit||0));
  const principal=Math.max(0,Number(t.price||0)*Number(t.qty||1));
  const now=new Date().toISOString();

  // Pastikan transaksi pembayaran sudah ada. Jika versi lama belum menyimpan
  // transaksi ini, buat hanya sebagai fallback agar ledger tetap konsisten.
  const paymentExists=state.tx.some(x=>x && x.type==='minus' && String(x.orderId||'')===String(t.id));
  if(!paymentExists && principal>0){
    state.tx.unshift({
      name:'Pembayaran Pesanan: '+t.id,
      amount:principal,
      type:'minus',
      date:t.paymentAt||now,
      orderId:t.id,
      description:'Pembayaran pesanan menggunakan saldo Dompet'
    });
  }

  const refundExists=state.tx.some(x=>x && x.type==='plus' && String(x.orderId||'')===String(t.id) && (
    String(x.description||'').includes('Pengembalian dana pesanan') ||
    String(x.name||'').startsWith('Pengembalian Dana Pesanan')
  ));
  if(!refundExists && principal>0){
    state.tx.unshift({
      name:'Pengembalian Dana Pesanan '+t.id,
      amount:principal,
      type:'plus',
      date:now,
      orderId:t.id,
      description:'Pengembalian dana pesanan setelah pesanan selesai'
    });
  }

  const commissionExists=state.tx.some(x=>x && x.type==='plus' && String(x.orderId||'')===String(t.id) && String(x.name||'').startsWith('Komisi Pesanan'));
  if(!commissionExists && profit>0){
    state.tx.unshift({
      name:'Komisi Pesanan '+t.id,
      amount:profit,
      type:'plus',
      date:now,
      orderId:t.id,
      description:'Komisi berhasil dari pesanan yang telah selesai'
    });
  }

  // Satu-satunya titik yang mengubah shipping -> done.
  t.commissionCredited=true;
  t.completedAt=now;
  t.status='done';

  // Hitung dari ID pesanan unik, lalu simpan ke dua storage per-akun.
  const doneIds=new Set((state.tasks||[])
    .filter(x=>x && x.status==='done' && x.id)
    .map(x=>String(x.id)));
  const ledgerDone=calculateCompletedOrderCount();
  state.completedOrders=Math.max(doneIds.size, ledgerDone, Number(state.completedOrders)||0, readPersistedCompletedCount(), getDurableCompletedCount());
  // Simpan ID pesanan selesai langsung ke Auth metadata agar dapat dipulihkan setelah refresh.
  try{
    const ids=new Set(getDurableCompletedOrderIds());
    ids.add(String(t.id));
    const completedIds=[...ids];
    const nextCount=Math.max(state.completedOrders,completedIds.length);
    const result=await sb.auth.updateUser({data:{
      ...(currentUser?.user_metadata||{}),
      bh_completed_order_count:nextCount,
      bh_completed_order_ids:completedIds,
      completed_orders:nextCount,
      completed_order_ids:completedIds
    }});
    if(!result.error && result.data?.user) currentUser=result.data.user;
    state.completedOrders=Math.max(state.completedOrders,nextCount);
  }catch(e){ console.warn('Penyimpanan pesanan selesai gagal:',e); }
  await persistCompletedCount();
  // Re-read the durable value immediately after persistence so the popup and
  // Beranda always use the same number that will survive a reload.
  state.completedOrders=Math.max(
    Number(state.completedOrders)||0,
    readRemoteCompletedCount(),
    await readProfileCompletedCount(),
    calculateCompletedOrderCount()
  );

  // Saldo final dihitung ulang dari ledger akun aktif. Pembayaran pesanan
  // sudah tercatat sebagai minus, refund sebagai plus, dan pesanan selesai
  // menyumbang profit saja. Jadi principal tidak boleh ditambahkan dua kali.
  // Contoh voucher 30.000 + order 17.900 + order 30.200 menghasilkan
  // 30.000 + 3.580 + 6.040 = 39.620.
  state.balance=calculateBusinessWalletBalance();
  state.totalCommission=Math.max(0,Number(state.totalCommission)||0)+profit;
  saveWalletForCurrentAccount();
  const walletPersisted=await persistWalletToSupabase();
  if(!walletPersisted){
    // Jangan mengklaim saldo sudah masuk jika Supabase menolak penyimpanan.
    toast('⚠️ Saldo belum tersimpan ke server. Periksa policy UPDATE wallets.');
    return false;
  }

  // Simpan counter selesai SETELAH wallet berhasil disimpan, lalu baca balik
  // dari database. Ini membuat wallets.completed_orders menjadi sumber tunggal
  // yang dipakai saat refresh.
  const completedPersisted=await persistWalletCompletedCount(state.completedOrders);
  if(!completedPersisted){
    toast('⚠️ Jumlah pesanan selesai belum tersimpan ke server.');
    return false;
  }
  const verifiedCompleted=await readWalletCompletedCount();
  state.completedOrders=Math.max(Number(state.completedOrders)||0,verifiedCompleted);
  saveOrdersForCurrentAccount();

  // Counter Beranda diperbarui SEBELUM popup sehingga tidak menunggu refresh.
  updateHomeCompletedCount();
  const homeDone=document.getElementById('homeDone');
  if(homeDone)homeDone.textContent=String(state.completedOrders);

  // Tampilkan popup segera. Jangan mengandalkan timer atau refresh browser.
  orderTab='done';
  syncOrderTabButtons();
  renderOrders();
  const balance=Number(state.balance)||0;
  showCommissionSuccessPopup(t,profit,principal,balance);
  return true;
}

function resumeOrderFlowAfterReload(){
  const active=state.tasks.find(x=>x.status==='active');
  if(active){
    clearTimeout(taskFlowTimer);
    orderTab='active';
    return;
  }

  const shipping=state.tasks.find(x=>x.status==='shipping' && x.commissionCredited!==true);
  if(shipping){
    clearTimeout(taskFlowTimer);
    orderTab='active';
    renderOrders();
    return;
  }

  // Jika tidak ada pesanan berjalan, tawarkan pesanan berikutnya sesuai urutan.
  if(!state.tasks.some(t=>['offered','active','processing_wait','shipping'].includes(t?.status))){
    startMerchantFlow();
  }
}

function renderHomeTasks(){
  const el=document.getElementById('homeTasks');
  if(!el)return;
  el.innerHTML='<div class="empty">Pesanan berikutnya akan diberikan oleh pihak merchant secara bertahap.</div>';
}
function getCompletedOrderRecords(){
  const records=[];
  const seen=new Set();

  // Task objects marked done are the primary records.
  for(const t of (Array.isArray(state.tasks)?state.tasks:[])){
    if(!t || t.status!=='done' || !t.id) continue;
    const id=String(t.id);
    if(seen.has(id)) continue;
    const total=Number(t.price||0)*Number(t.qty||1);
    const refund=state.tx.filter(x=>x && x.type==='plus' && String(x.orderId||'')===id &&
      (String(x.description||'').includes('Pengembalian dana pesanan') || String(x.name||'').startsWith('Pengembalian Dana Pesanan')))
      .reduce((a,x)=>a+Number(x.amount||0),0);
    const commission=state.tx.filter(x=>x && x.type==='plus' && String(x.orderId||'')===id && String(x.name||'').startsWith('Komisi Pesanan'))
      .reduce((a,x)=>a+Number(x.amount||0),0);
    records.push({...t, refund:refund||total, commission:commission||Number(t.profit||0)});
    seen.add(id);
  }

  // Backward compatibility: older completion transactions may not have orderId.
  // If they exist, show them against the first order instead of leaving the
  // Selesai tab empty. This also makes the completed count visible to the user.
  const anonymousCommission=state.tx.filter(x=>x && x.type==='plus' && !x.orderId && String(x.name||'').startsWith('Komisi Pesanan'))
    .reduce((a,x)=>a+Number(x.amount||0),0);
  const anonymousRefund=state.tx.filter(x=>x && x.type==='plus' && !x.orderId &&
    (String(x.description||'').includes('Pengembalian dana pesanan') || String(x.name||'').startsWith('Pengembalian Dana Pesanan')))
    .reduce((a,x)=>a+Number(x.amount||0),0);
  if(!records.length && (anonymousCommission>0 || anonymousRefund>0)){
    const base=(Array.isArray(state.tasks)&&state.tasks[0]) ? state.tasks[0] : TASKS[0];
    const id=base?.id || 'SC-2601298YHD2BD';
    records.push({...base,id,status:'done',refund:anonymousRefund||Number(base?.price||0),commission:anonymousCommission||Number(base?.profit||0),commissionCredited:true});
  }
  return records;
}

function renderOrders(){
  const el=document.getElementById('ordersList');
  if(!el)return;

  if(orderTab==='available'){
    ensureFirstOrderAvailable();
    let offered=state.tasks.find(x=>x.status==='offered');
    el.innerHTML=offered
      ? taskHTML(offered)
      : `<div class="premium-order-wait"><div class="courier-icon">⌁</div><h4>Menunggu Pesanan ✨</h4><p>Pesanan berikutnya akan diberikan oleh pihak merchant secara bertahap.</p><div class="courier-dots">•••</div></div>`;

  }else if(orderTab==='active'){
    const active=state.tasks.find(x=>x.status==='active');
    const shipping=state.tasks.find(x=>x.status==='shipping');
    const waiting=state.tasks.find(x=>x.status==='processing_wait');
    el.innerHTML=active
      ? taskHTML(active)
      : shipping
      ? `<div class="premium-order-wait courier-stage-card"><div class="courier-icon">🚚</div><div class="courier-stage-pill">TAHAP 2</div><h4>Pesanan diberikan kepada Kurir 💗</h4><p>Pesanan sudah dikonfirmasi dan sedang diserahkan kepada kurir.</p><div class="courier-progress"><i></i></div><div class="courier-note">Kurir sedang menerima pesanan. Setelah diterima, pesanan akan diselesaikan dan komisi masuk ke Dompet.</div><button type="button" class="order-confirm-btn courier-finish-btn" data-finish-order="${shipping.id}" onclick="window.finishCourierStage('${shipping.id}')">✓ Pesanan Selesai</button><div class="courier-dots">• • •</div></div>`
      : waiting
      ? `<div class="premium-order-wait"><div class="courier-icon">📦</div><h4>Menyiapkan Pesanan ✨</h4><p>Pesanan sedang disiapkan. Detail pesanan akan segera tampil.</p><div class="courier-dots">•••</div></div>`
      : `<div class="premium-order-wait"><div class="courier-icon">⌁</div><h4>Belum Ada Pesanan Aktif</h4><p>Pesanan yang sudah diterima akan tampil di sini.</p><div class="courier-dots">•••</div></div>`;
  }else{
    const arr=getCompletedOrderRecords();
    el.innerHTML=arr.length?arr.map(t=>{
      const refund=Number(t.refund||0);
      const commission=Number(t.commission||0);
      const totalKembali=refund+commission;
      return `<article class="premium-order-card is-done completed-data-card">
        <div class="order-card-head">
          <div class="order-head-title">
            <span class="order-head-icon">✓</span>
            <div>
              <strong>ID PESANAN</strong>
              <small>${t.id}</small>
            </div>
          </div>
          <span class="order-badge done">✓ SELESAI</span>
        </div>

        <div class="completed-order-data">
          <div class="completed-row">
            <span>Pengembalian Saldo</span>
            <b class="profit">+ ${rupiah(refund)}</b>
          </div>
          <div class="completed-row">
            <span>Komisi Pesanan</span>
            <b class="profit">+ ${rupiah(commission)}</b>
          </div>
          <div class="completed-divider"></div>
          <div class="completed-total">
            <span>Total Kembali ke Dompet</span>
            <b class="profit">+ ${rupiah(totalKembali)}</b>
          </div>
        </div>

        <div class="order-done-note">
          ✓ Pesanan telah diberikan kepada kurir dan selesai.
          Total masuk ke Dompet: <b>+ ${rupiah(totalKembali)}</b>
        </div>
      </article>`;
    }).join(''):`<div class="premium-order-wait"><div class="courier-icon">🎉</div><h4>Belum Ada Pesanan Selesai</h4><p>Pesanan yang sudah diberikan kepada kurir dan selesai akan tampil di sini.</p></div>`;
  }
}

// Fallback event delegation untuk tombol courier. Ini membuat tombol tetap
// bekerja walaupun renderOrders terjadi tepat sebelum tap pengguna.
document.addEventListener('click',function(e){
  const btn=e.target.closest?.('[data-finish-order]');
  if(!btn)return;
  e.preventDefault();
  e.stopPropagation();
  const id=btn.getAttribute('data-finish-order');
  finishCourierStage(id);
},true);
window.finishCourierStage=finishCourierStage;

function renderTx(){
 const el=document.getElementById("transactions");
 if(!el)return;
 if(!state.tx.length){el.innerHTML='<div class="empty">Belum ada transaksi.</div>';return}
 el.innerHTML=state.tx.slice(0,15).map(x=>{
   const d=new Date(x.date).toLocaleString("id-ID",{dateStyle:"medium",timeStyle:"short"});
   const raw=String(x.withdrawalStatus||x.status||"").toLowerCase();
   const isWithdrawal=!!x.withdrawalId || String(x.name||"").toLowerCase().startsWith("penarikan");
   if(isWithdrawal){
     let cls="processing", txt="Proses";
     if(raw==="approved"){cls="deposit-approved";txt="Berhasil";}
     else if(raw==="rejected"){cls="minus";txt="Ditolak";}
     else if(raw==="refund"||raw==="refunded"){cls="deposit-approved";txt="Refund";}
     else if(raw==="hold"){cls="deposit-hold";txt="Saldo tertahan";}
     return `<div class="tx-row"><div><div class="tx-name">Penarikan - ${rupiah(x.amount)}</div><div class="tx-meta">${d}</div></div><div class="${cls}">${txt}</div></div>`;
   }
   const isProcessing=x.status==="processing";
   const isDeposit=String(x.name||"").toLowerCase().startsWith("deposit");
   const isDepositApproved=isDeposit&&raw==="approved";
   const cls=isDepositApproved?"deposit-approved":(isProcessing?"processing":(x.type==="plus"?"plus":(x.type==="pending"?"pending":"minus")));
   const txt=isDepositApproved?"Berhasil":(isProcessing?"Proses":(x.type==="plus"?"+":(x.type==="pending"?"Menunggu":"-")));
   const amt=(isProcessing||isDepositApproved)?"":(x.type==="pending"?"":rupiah(x.amount));
   const name=isDeposit?`Deposit - ${rupiah(x.amount)}`:x.name;
   return `<div class="tx-row"><div><div class="tx-name">${name}</div><div class="tx-meta">${d}</div></div><div class="${cls}">${txt} ${amt}</div></div>`;
 }).join("");
}
/* ===== WITHDRAWAL STATUS + WALLET LIVE SYNC =====
   Status withdrawal sepenuhnya mengikuti Supabase.
   Status: pending/processing, approved, rejected, refund/refunded, hold.
   Tidak ada konfirmasi penarikan di aplikasi pengguna. */
let __bhWithdrawalSyncTimer=null;
let __bhWithdrawalSyncBusy=false;

let __bhWithdrawalRealtimeChannel=null;

function withdrawalRefundMarkerKey(withdrawalId){
  const uid=String(currentUser?.id||"").replace(/[^a-zA-Z0-9_-]/g,"");
  return uid ? `bh_withdrawal_refund_applied_${uid}_${String(withdrawalId)}` : "";
}
function hasWithdrawalRefundMarker(withdrawalId){
  const key=withdrawalRefundMarkerKey(withdrawalId);
  if(!key)return false;
  try{return localStorage.getItem(key)==="1";}catch(_){return false;}
}
function setWithdrawalRefundMarker(withdrawalId){
  const key=withdrawalRefundMarkerKey(withdrawalId);
  if(!key)return;
  try{localStorage.setItem(key,"1");}catch(_){}
}

async function syncWithdrawalsFromSupabase(){
 if(!currentUser?.id||__bhWithdrawalSyncBusy)return false;
 __bhWithdrawalSyncBusy=true; let changed=false;
 try{
  const {data,error}=await sb.from("withdrawals")
    .select("id,user_id,amount,status,created_at,processed_at")
    .eq("user_id",currentUser.id).order("created_at",{ascending:false}).limit(50);

  if(error){console.warn("Sinkronisasi withdrawal gagal:",error);return false;}

  const rows=Array.isArray(data)?data.filter(r=>r?.id):[];
  const old=Array.isArray(state.tx)?state.tx:[];
  const other=old.filter(x=>!x?.withdrawalId&&!String(x?.name||"").toLowerCase().startsWith("penarikan"));
  const withdrawals=[];

  for(const row of rows){
   const id=String(row.id);
   const amount=Math.max(0,Math.round(Number(row.amount)||0));
   if(!amount)continue;

   const status=String(row.status||"pending").toLowerCase();

   let tx=old.find(x=>String(x?.withdrawalId||"")===id);
   if(!tx){
     tx={
       name:"Penarikan - "+rupiah(amount),
       amount,
       type:"minus",
       status,
       date:row.created_at||new Date().toISOString(),
       withdrawalId:id,
       withdrawalStatus:status,
       refundApplied:false
     };
   }

   tx.name="Penarikan - "+rupiah(amount);
   tx.amount=amount;
   tx.type="minus";
   tx.status=status;
   tx.withdrawalStatus=status;
   tx.withdrawalId=id;
   tx.date=row.created_at||tx.date;
   if(row.processed_at)tx.processedAt=row.processed_at;

   /*
    * Untuk rejected/refund, saldo dikembalikan langsung melalui row wallets
    * Supabase. refundApplied baru ditandai setelah UPDATE dan verifikasi
    * berhasil, sehingga kegagalan RLS/koneksi akan dicoba kembali pada poll
    * berikutnya dan tidak menyebabkan saldo hilang.
    */
   const needsRefund=(status==="rejected"||status==="refund"||status==="refunded");

   if(needsRefund && tx.refundApplied!==true){
     if(hasWithdrawalRefundMarker(id)){
       tx.refundApplied=true;
     }else{
     try{
       const walletRead=await sb.from("wallets")
         .select("user_id,balance")
         .eq("user_id",currentUser.id)
         .maybeSingle();

       if(walletRead.error){
         console.warn("Gagal membaca saldo wallet untuk refund:",walletRead.error);
       }else if(walletRead.data){
         const dbBalance=Math.max(0,Math.round(Number(walletRead.data.balance)||0));
         const refundBalance=dbBalance+amount;

         const walletUpdate=await sb.from("wallets")
           .update({
             balance:refundBalance,
             updated_at:new Date().toISOString()
           })
           .eq("user_id",currentUser.id)
           .select("user_id,balance")
           .maybeSingle();

         if(walletUpdate.error){
           console.warn("Gagal mengembalikan saldo refund:",walletUpdate.error);
         }else if(walletUpdate.data){
           const savedBalance=Math.round(Number(walletUpdate.data.balance)||0);

           if(savedBalance===refundBalance){
             state.balance=savedBalance;
             tx.refundApplied=true;
             tx.refundAppliedAt=new Date().toISOString();
             setWithdrawalRefundMarker(id);
             changed=true;
             __bhLastVerifiedWalletBalance=savedBalance;
             __bhLastVerifiedWalletAt=Date.now();
           }else{
             console.warn("Verifikasi saldo refund tidak cocok:",{
               expected:refundBalance,
               saved:savedBalance
             });
           }
         }
       }else{
         console.warn("Row wallet tidak ditemukan; refund belum ditandai selesai.");
       }
     }catch(refundError){
       console.warn("Exception saat refund saldo:",refundError);
     }
     }
   }

   withdrawals.push(tx);
  }

  const legacy=old.filter(x=>!x?.withdrawalId&&String(x?.name||"").toLowerCase().startsWith("penarikan"));
  for(const x of legacy){
   if(!withdrawals.some(w=>Math.round(Number(w.amount)||0)===Math.round(Number(x.amount)||0)))withdrawals.push(x);
  }

  const seen=new Set();
  state.tx=[...withdrawals,...other]
    .sort((a,b)=>new Date(b.date||0)-new Date(a.date||0))
    .filter(x=>{
      if(!x?.withdrawalId)return true;
      const id=String(x.withdrawalId);
      if(seen.has(id))return false;
      seen.add(id);
      return true;
    })
    .slice(0,100);

  renderTx();

  if(changed){
    saveWalletForCurrentAccount();
    await persistTxHistoryToAuth().catch(()=>{});
    forceWalletBalanceUI();
  }

  return changed;
 }catch(e){
   console.warn("Exception sinkronisasi withdrawal:",e);
   return false;
 }finally{
   __bhWithdrawalSyncBusy=false;
 }
}
async function startWithdrawalLiveSync(){
 clearInterval(__bhWithdrawalSyncTimer);

 // Supabase Realtime is the primary path; polling remains as a safe fallback
 // because content:// browsers can occasionally block websocket events.
 try{
  if(__bhWithdrawalRealtimeChannel){
   try{await sb.removeChannel(__bhWithdrawalRealtimeChannel);}catch(_){}
   __bhWithdrawalRealtimeChannel=null;
  }
  if(currentUser?.id){
   const uid=String(currentUser.id);
   __bhWithdrawalRealtimeChannel=sb.channel("bh-withdrawals-"+uid+"-"+Date.now())
    .on("postgres_changes",{
      event:"*",
      schema:"public",
      table:"withdrawals",
      filter:"user_id=eq."+uid
    },()=>{
      // Re-read the authoritative withdrawal + wallet immediately.
      syncWithdrawalsFromSupabase().catch(()=>{});
    })
    .subscribe(status=>{
      if(status==="CHANNEL_ERROR" || status==="TIMED_OUT" || status==="CLOSED"){
       console.warn("Supabase Realtime withdrawal tidak tersedia:",status);
      }
    });
  }
 }catch(e){
  console.warn("Gagal menyalakan Realtime withdrawal:",e);
  __bhWithdrawalRealtimeChannel=null;
 }

 if(!currentUser?.id)return;
 syncWithdrawalsFromSupabase().catch(()=>{});

 // Fallback polling keeps status and refund balance live without refresh.
 __bhWithdrawalSyncTimer=setInterval(()=>{
  if(document.visibilityState!=="hidden")syncWithdrawalsFromSupabase().catch(()=>{});
 },1500);
}

async function stopWithdrawalLiveSync(){
 clearInterval(__bhWithdrawalSyncTimer);
 __bhWithdrawalSyncTimer=null;
 if(__bhWithdrawalRealtimeChannel){
  try{await sb.removeChannel(__bhWithdrawalRealtimeChannel);}catch(_){}
  __bhWithdrawalRealtimeChannel=null;
 }
}

document.addEventListener("visibilitychange",()=>{
 if(document.visibilityState==="visible"&&currentUser?.id)syncWithdrawalsFromSupabase().catch(()=>{});
});

/* ===== DEPOSIT STATUS + WALLET LIVE SYNC =====
   Hanya membaca perubahan deposit milik UID aktif. Pesanan 1-5, saldo
   tersimpan, voucher, dan alur lain tidak disentuh. Polling dipakai sebagai
   fallback yang stabil karena halaman content:// tidak selalu menerima
   event Realtime Supabase. */
let __bhDepositSyncTimer=null;
let __bhDepositSyncBusy=false;

async function syncApprovedDepositsFromSupabase(){
  if(!currentUser?.id || __bhDepositSyncBusy)return false;
  __bhDepositSyncBusy=true;
  let changed=false;
  try{
    const {data,error}=await sb.from("deposits")
      .select("id,amount,status,created_at,approved_at,sender_name,payment_method")
      .eq("user_id",currentUser.id)
      .order("created_at",{ascending:false})
      .limit(30);

    if(error){
      console.warn("Sinkronisasi status deposit gagal:",error);
      return false;
    }
    if(!Array.isArray(data)||!data.length)return false;

    state.tx=Array.isArray(state.tx)?state.tx:[];
    const deposits=data;
    const usedTx=new Set();

    for(const dep of deposits){
      const depStatus=String(dep?.status||"").toLowerCase();
      if(depStatus!=="approved")continue;
      const amount=Math.max(0,Number(dep?.amount)||0);
      if(!amount)continue;

      let txIndex=-1;
      // Prioritas pertama: ID deposit jika versi data sudah memilikinya.
      if(dep?.id){
        txIndex=state.tx.findIndex(x=>String(x?.depositId||"")===String(dep.id));
      }
      // Fallback aman untuk transaksi versi sebelumnya: cocokkan nominal +
      // waktu pengajuan, tanpa menyentuh transaksi pesanan.
      if(txIndex<0){
        const depTime=Date.parse(dep?.created_at||"");
        let bestDiff=Infinity;
        state.tx.forEach((x,i)=>{
          if(usedTx.has(i)||!x)return;
          const isDeposit=String(x.name||"").toLowerCase().startsWith("deposit");
          if(!isDeposit || String(x.status||"").toLowerCase()==="approved")return;
          if(Math.round(Number(x.amount)||0)!==Math.round(amount))return;
          const txTime=Date.parse(x.date||"");
          const diff=(Number.isFinite(depTime)&&Number.isFinite(txTime))?Math.abs(txTime-depTime):999999999;
          if(diff<bestDiff && diff<=30*60*1000){bestDiff=diff;txIndex=i;}
        });
      }

      if(txIndex>=0){
        const tx=state.tx[txIndex];
        usedTx.add(txIndex);
        if(String(tx.status||"").toLowerCase()!=="approved" || String(tx.depositId||"")!==String(dep.id||"") || String(tx.type||"").toLowerCase()!=="plus"){
          tx.status="approved";
          tx.depositId=dep.id?String(dep.id):String(tx.depositId||"");
          // Deposit approved = saldo masuk permanen, bukan transaksi pending.
          tx.type="plus";
          if(dep.approved_at)tx.approvedAt=dep.approved_at;
          changed=true;
        }
      }
    }

    if(changed){
      try{saveWalletForCurrentAccount();}catch(_){}
      try{await persistTxHistoryToAuth();}catch(_){}
      renderTx();
    }

    // Wallet Supabase adalah sumber saldo permanen. Setelah approval admin,
    // ambil ulang row wallet agar saldo berubah tanpa reload halaman.
    const walletChanged=await loadWalletFromSupabase();
    if(walletChanged){
      forceWalletBalanceUI();
      if(changed)renderTx();
    }
    return changed||walletChanged;
  }catch(e){
    console.warn("Exception sinkronisasi deposit:",e);
    return false;
  }finally{
    __bhDepositSyncBusy=false;
  }
}

function startDepositLiveSync(){
  clearInterval(__bhDepositSyncTimer);
  __bhDepositSyncTimer=null;
  if(!currentUser?.id)return;
  // Cek segera, lalu ulangi berkala agar approval admin langsung tercermin.
  syncApprovedDepositsFromSupabase().catch(()=>{});
  __bhDepositSyncTimer=setInterval(()=>{
    if(document.visibilityState!=="hidden")syncApprovedDepositsFromSupabase().catch(()=>{});
  },2500);
  window.__bhDepositSyncTimer=__bhDepositSyncTimer;
}

document.addEventListener("visibilitychange",()=>{
  if(document.visibilityState==="visible" && currentUser?.id){
    syncApprovedDepositsFromSupabase().catch(()=>{});
  }
});

function showModal(){document.getElementById("modalBg").classList.add("show")}
function closeModal(){const m=document.querySelector("#modal .modal");if(m)m.classList.remove("voucher-modal","finance-modal");document.getElementById("modalBg").classList.remove("show")}
function prepareFinanceModal(){
  const modal=document.querySelector("#modal .modal");
  if(modal) modal.classList.add("finance-modal");
  if(modal) modal.classList.remove("voucher-modal");
}
let currentTopupMethod="bank";

function selectTopupMethod(method){
  currentTopupMethod=method==="qris"?"qris":"bank";
  document.querySelectorAll(".qris-method-tab").forEach(btn=>btn.classList.toggle("active",btn.dataset.method===currentTopupMethod));
  document.querySelectorAll(".topup-method-panel").forEach(panel=>panel.classList.toggle("active",panel.dataset.method===currentTopupMethod));
  const sender=document.getElementById("topupSender");
  if(sender) sender.placeholder=currentTopupMethod==="qris"?"Nama pemilik rekening / pengirim":"Nama sesuai rekening pengirim";
}

function openTopup(amount=""){
  prepareFinanceModal();
  document.getElementById("modalTitle").textContent="";
  const suggested=amount?Number(amount):"";
  currentTopupMethod="bank";
  document.getElementById("modalBody").innerHTML=`
    <div class="finance-head">
      <div class="finance-icon">💳</div>
      <h3>Isi Saldo</h3>
      <p>Transfer sesuai nominal, lalu konfirmasi pembayaran untuk proses verifikasi.</p>
      <button class="close" aria-label="Tutup" onclick="closeModal()">×</button>
    </div>
    <div class="finance-content">
      <div class="qris-method-tabs">
        <button type="button" class="qris-method-tab active" data-method="bank" onclick="selectTopupMethod('bank')">🏦 Transfer Bank</button>
        <button type="button" class="qris-method-tab" data-method="qris" onclick="selectTopupMethod('qris')">▦ QRIS</button>
      </div>

      <div class="topup-method-panel active" data-method="bank">
        <div class="finance-card">
          <div class="finance-card-title">🏦 Transfer Bank</div>
          <div class="finance-card-text">Silakan transfer sesuai nominal ke rekening tujuan berikut.</div>
          <div class="finance-account">
            <strong>Allo Bank</strong>
            <span class="account-number">082230191502</span>
          </div>
        </div>
      </div>

      <div class="topup-method-panel" data-method="qris">
        <div class="qris-payment-card">
          <div class="qris-title">▦ QRIS</div>
          <div class="qris-desc">Scan QRIS di bawah menggunakan aplikasi pembayaran yang mendukung QRIS.</div>
          <img class="qris-payment-image" src="assets/img-e5bf3900791f2062.png" alt="QRIS Perusahaan BeautyHaul Career">
          <div class="qris-note">💡 Pastikan nominal pembayaran sesuai dengan nominal Isi Saldo sebelum melakukan pembayaran.</div>
        </div>
      </div>

      <div class="finance-field">
        <label class="finance-label" for="topupAmount">Nominal Isi Saldo</label>
        <input id="topupAmount" type="number" min="10000" value="${suggested||""}" placeholder="Minimal Rp 10.000">
      </div>

      <div class="finance-field">
        <label class="finance-label" for="topupSender">Nama Pengirim</label>
        <input id="topupSender" type="text" placeholder="Nama sesuai rekening pengirim">
      </div>

      <div class="finance-field">
        <label class="finance-label" for="topupPhone">Nomor Telepon Terdaftar</label>
        <input id="topupPhone" type="tel" value="${phoneDisplay()}" readonly style="background:#f4f6f9;color:#667085">
      </div>

      <div class="finance-note">💡 Setelah pembayaran, tekan <b>Konfirmasi Pembayaran</b>. Saldo belum bertambah sampai pembayaran diverifikasi.</div>
      <button class="finance-submit" onclick="confirmTopup()">Konfirmasi Pembayaran</button>
    </div>`;
  showModal();
}

async function confirmTopup(){
  const n=Number(document.getElementById("topupAmount")?.value);
  const sender=String(document.getElementById("topupSender")?.value||"").trim();
  const phone=String(document.getElementById("topupPhone")?.value||phoneOf()||"").trim();

  if(!n || n<10000)return toast("Nominal minimal Rp 10.000.");
  if(!sender)return toast("Nama pengirim wajib diisi.");
  if(!phone)return toast("Nomor telepon terdaftar tidak ditemukan.");
  if(!currentUser?.id)return toast("Sesi akun belum siap. Silakan login ulang lalu coba lagi.");

  const paymentMethod=currentTopupMethod==="qris"?"QRIS":"Allo Bank";
  const request={
    id:"TOPUP-"+Date.now(),
    amount:n,
    sender,
    phone,
    bank:paymentMethod,
    account:currentTopupMethod==="qris"?"QRIS Perusahaan":"082230191502",
    status:"pending",
    date:new Date().toISOString()
  };

  try{
    const {data:authData,error:authError}=await sb.auth.getUser();
    const authUser=authData?.user;
    if(authError || !authUser?.id){
      console.error("Sesi Supabase tidak tersedia:",authError);
      return toast("Sesi akun belum siap. Silakan masuk ulang lalu coba lagi.");
    }

    request.user_id=authUser.id;

    const {error:depositError}=await sb.from("deposits")
      .insert({
        user_id:authUser.id,
        amount:n,
        status:"pending",
        created_at:request.date,
        payment_method:paymentMethod,
        sender_name:request.sender
      });

    if(depositError){
      console.error("Gagal menyimpan deposit ke Supabase:",depositError);
      console.error("Detail deposit:",depositError.code,depositError.message,depositError.details,depositError.hint);
      return toast("✨ Deposit belum tersimpan. Coba lagi sebentar.");
    }

  }catch(e){
    console.error("Exception saat menyimpan deposit ke Supabase:",e);
    return toast("✨ Deposit belum tersimpan. Coba lagi sebentar.");
  }

  state.topups=Array.isArray(state.topups)?state.topups:[];
  state.topups.unshift(request);
  state.tx.unshift({
    name:`Deposit - ${rupiah(n)}`,
    amount:n,
    type:"pending",
    status:"processing",
    date:request.date,
    topupId:request.id,
    depositId:null,
    paymentMethod
  });

  localStorage.setItem("bh_topups",JSON.stringify(state.topups));
  save();
  try{ await persistTxHistoryToAuth(); }catch(_){ }
  renderTx();
  syncWalletBalanceFromLedger();
  startDepositLiveSync();

  closeModal();
  setTimeout(()=>showDepositVerificationPopup(n),60);
}

function showDepositVerificationPopup(amount){
  prepareFinanceModal();
  document.getElementById("modalTitle").textContent="";
  document.getElementById("modalBody").innerHTML=`
    <div class="finance-head" style="text-align:center;padding:8px 4px 4px;">
      <div class="finance-icon" style="margin:0 auto 12px;background:#e9fbf2;color:#18a568;">✓</div>
      <h3 style="margin:0 0 8px;color:#17233d;">Pengisian Saldo Sedang Diverifikasi 💗</h3>
      <p style="margin:0;color:#66748a;font-size:13px;line-height:1.55;">Pengisian saldo Anda sebesar <b>${rupiah(amount)}</b> sedang diverifikasi. Saldo akan bertambah setelah pembayaran berhasil diverifikasi.</p>
      <div class="flow-mini-card" style="margin-top:16px;text-align:center;">
        <b>Nominal Deposit</b>
        <span style="font-size:16px;color:#ef3f87;font-weight:900;">${rupiah(amount)}</span>
      </div>
      <button class="finance-submit" onclick="closeModal()" style="margin-top:12px;">Baik, Mengerti 💕</button>
    </div>`;
  showModal();
}

function getCompletedOrderCount(){
  const synced=syncCompletedOrdersFromLedger();
  return Math.max(Number(state.completedOrders)||0, Number(synced)||0, calculateCompletedOrderCount());
}
function getWithdrawalEligibility(){
  const completed=getCompletedOrderCount();
  if(completed<5){
    return {unlocked:false,completed,max:0,title:"Penarikan belum tersedia",
      message:`Selesaikan pesanan ke-5 terlebih dahulu. Anda baru menyelesaikan ${completed} pesanan.`};
  }
  if(completed<10){
    return {unlocked:true,completed,max:50000,title:"Level penarikan: Pesanan 5",
      message:"Setelah menyelesaikan pesanan ke-5, penarikan maksimal Rp50.000."};
  }
  if(completed<15){
    return {unlocked:true,completed,max:Infinity,title:"Level penarikan: Pesanan 10",
      message:"Setelah menyelesaikan pesanan ke-10, penarikan dapat dilakukan hingga seluruh saldo yang tersedia."};
  }
  return {unlocked:true,completed,max:Infinity,title:"Level penarikan: Pesanan 15",
    message:"Setelah menyelesaikan pesanan ke-15, penarikan dapat dilakukan hingga seluruh saldo yang tersedia."};
}

function openWithdraw(){
  prepareFinanceModal();
  const rule=getWithdrawalEligibility();
  document.getElementById("modalTitle").textContent="";
  const maxLabel=rule.max===Infinity?"Seluruh saldo":(rule.max?rupiah(rule.max):"Belum terbuka");
  document.getElementById("modalBody").innerHTML=`
    <div class="finance-head">
      <div class="finance-icon">💸</div>
      <h3>Tarik Dana</h3>
      <p>Penarikan mengikuti jumlah pesanan yang benar-benar sudah selesai.</p>
      <button class="close" aria-label="Tutup" onclick="closeModal()">×</button>
    </div>
    <div class="finance-content">
      <div class="finance-summary">
        <div class="finance-summary-item"><small>Pesanan Selesai</small><b>${rule.completed}</b></div>
        <div class="finance-summary-item"><small>Batas Saat Ini</small><b>${maxLabel}</b></div>
      </div>
      <div class="finance-card" style="${rule.unlocked?'border-color:#b8ddc9;background:#f2fff8;':'border-color:#f1d5a0;background:#fff9ec;'}">
        <div class="finance-card-title">${rule.unlocked?'✅':'🔒'} ${rule.title}</div>
        <div class="finance-card-text">${rule.message}</div>
      </div>
      <div class="finance-card" style="margin-top:10px">
        <div class="finance-card-title">🎯 Ketentuan Penarikan</div>
        <div class="finance-card-text">
          Pesanan 5 → maksimal <b>Rp50.000 (Validasi Rekening)</b><br>
          Pesanan 10 → <b>seluruh saldo</b><br>
          Pesanan 15 → <b>seluruh saldo</b>
        </div>
      </div>
      <div class="finance-field">
        <label class="finance-label" for="withdrawAmount">Nominal Penarikan</label>
        <input id="withdrawAmount" type="number" min="10000" ${rule.unlocked?'':'disabled'} ${rule.max!==Infinity&&rule.max>0?`max="${rule.max}"`:''} placeholder="${rule.unlocked?'Masukkan nominal penarikan':'Selesaikan pesanan ke-5 terlebih dahulu'}">
      </div>
      <div class="finance-note">💡 Saldo hanya dapat ditarik sesuai level pesanan selesai. Data dihitung dari status <b>SELESAI</b> pada akun.</div>
      <button class="finance-submit" onclick="confirmWithdraw()" ${rule.unlocked?'':'disabled'} style="${rule.unlocked?'':'opacity:.55;cursor:not-allowed;'}">${rule.unlocked?'Ajukan Penarikan':'Belum Dapat Menarik Dana'}</button>
      <button class="finance-secondary" onclick="openBank()">Atur Rekening / E-Wallet</button>
    </div>`;
  showModal();
}

async function confirmWithdraw(){
  const rule=getWithdrawalEligibility();
  const n=Math.round(Number(document.getElementById("withdrawAmount")?.value)||0);

  if(!rule.unlocked)return toast("Penarikan baru tersedia setelah menyelesaikan pesanan ke-5.");
  if(!state.bank)return toast("Tambahkan rekening bank terlebih dahulu.");
  if(!n||n<10000)return toast("Nominal minimal Rp 10.000.");
  if(rule.max!==Infinity && n>rule.max)return toast("Batas penarikan saat ini maksimal "+rupiah(rule.max)+".");
  if(n>Number(state.balance||0))return toast("Saldo tidak mencukupi.");
  if(!currentUser?.id)return toast("Sesi akun belum siap. Silakan masuk kembali.");

  const btn=document.querySelector(".finance-submit");
  if(btn){btn.disabled=true;btn.textContent="Mengajukan...";}

  const createdAt=new Date().toISOString();

  try{
    /* 1. Simpan pengajuan ke Supabase terlebih dahulu.
       Supabase adalah sumber status penarikan. */
    const {data,error}=await sb.from("withdrawals").insert({
      user_id:currentUser.id,
      amount:n,
      status:"pending",
      created_at:createdAt
    }).select("*").single();

    if(error){
      console.error("Pengajuan withdrawal Supabase gagal:",error);
      toast("Pengajuan penarikan gagal disimpan. Saldo belum dipotong.");
      return false;
    }

    const id=data?.id?String(data.id):"";
    const date=data?.created_at||createdAt;

    /* 2. Potong saldo hanya setelah INSERT Supabase berhasil. */
    state.balance=Math.max(0,Math.round(Number(state.balance||0)-n));

    /* 3. Masukkan transaksi pending langsung ke UI.
       Tidak perlu refresh halaman. */
    state.tx=Array.isArray(state.tx)?state.tx:[];
    state.tx=state.tx.filter(x=>String(x?.withdrawalId||"")!==id);
    state.tx.unshift({
      name:"Penarikan - "+rupiah(n),
      amount:n,
      type:"minus",
      status:"pending",
      date,
      withdrawalId:id,
      withdrawalStatus:"pending",
      refundApplied:false,
      description:"Pengajuan penarikan melalui Supabase"
    });

    if(!Array.isArray(state.publicWithdrawals))state.publicWithdrawals=[];
    state.publicWithdrawals.unshift({
      name:maskWithdrawalName(nameOf()),
      amount:n,
      date
    });
    state.publicWithdrawals=state.publicWithdrawals.slice(0,100);

    /* 4. Simpan state dan repaint tampilan saat ini.
       Jangan memanggil refreshAll() karena itu dapat mengembalikan
       tampilan lama sebelum sinkronisasi selesai. */
    saveWalletForCurrentAccount();
    forceWalletBalanceUI();
    await persistWalletToSupabase().catch(e=>console.warn("Persist wallet:",e));
    await persistTxHistoryToAuth().catch(e=>console.warn("Persist tx history:",e));

    renderTx();

    /* 5. Tutup modal pengajuan lalu tampilkan popup yang sudah ditentukan. */
    closeModal();

    /* Pastikan daftar transaksi langsung terlihat pada halaman Dompet. */
    renderTx();
    forceWalletBalanceUI();

    showWithdrawalSuccessOverlay(n);

    /* Sinkronisasi ringan setelah popup tampil.
       Tidak mengubah status pending secara lokal; hanya membaca Supabase. */
    setTimeout(()=>{
      syncWithdrawalsFromSupabase().catch(()=>{});
    },300);

    return true;
  }catch(err){
    console.error("Exception pengajuan withdrawal:",err);
    toast("Terjadi kesalahan saat mengajukan penarikan. Saldo belum dipotong.");
    return false;
  }finally{
    if(btn){btn.disabled=false;btn.textContent="Ajukan Penarikan";}
  }
}

function showWithdrawalSuccessOverlay(amount){
  document.getElementById("withdrawSuccessOverlay")?.remove();
  const wrap=document.createElement("div");
  wrap.id="withdrawSuccessOverlay";
  wrap.style.cssText="position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(10,28,58,.58);backdrop-filter:blur(5px)";
  wrap.innerHTML=`<div style="width:min(100%,370px);background:#fff;border-radius:26px;padding:28px 22px 22px;text-align:center;box-shadow:0 25px 80px rgba(0,0,0,.28)">
    <div style="width:70px;height:70px;margin:0 auto 14px;border-radius:50%;display:grid;place-items:center;background:#e8faf1;color:#18a568;font-size:38px;font-weight:900">✓</div>
    <h3 style="margin:0 0 8px;color:#17233d;font-size:20px;font-weight:900">Penarikan Berhasil Diajukan</h3>
    <p style="margin:0;color:#65748a;font-size:12px;line-height:1.6">Penarikan sebesar</p>
    <div style="display:inline-block;margin:12px 0 8px;padding:9px 18px;border-radius:999px;background:#e8faf1;color:#168b56;font-size:19px;font-weight:900">${rupiah(amount)}</div>
    <p style="margin:0 0 18px;color:#53657d;font-size:11px;line-height:1.6">Penarikan sebesar <b>${rupiah(amount)}</b> berhasil diajukan dan sedang dalam proses.</p>
    <button onclick="document.getElementById('withdrawSuccessOverlay')?.remove()" style="width:100%;height:46px;border:0;border-radius:14px;background:linear-gradient(135deg,#0755b8,#0d67cf);color:#fff;font-size:13px;font-weight:900">Mengerti</button>
  </div>`;
  document.body.appendChild(wrap);
}
function openBank(editMode=false){
 prepareFinanceModal();
 document.getElementById("modalTitle").textContent="";
 const b=state.bank||{};
 const hasSaved=!!(b.bank && b.number && b.owner);
 const banks=["Bank Central Asia (BCA)","Bank Mandiri","Bank Negara Indonesia (BNI)","Bank Rakyat Indonesia (BRI)","CIMB Niaga","Bank Tabungan Negara (BTN)","Bank Syariah Indonesia (BSI)","Bank Permata","Bank Danamon","Bank Panin","Bank OCBC NISP","Bank Mega","Bank Jago","Bank Neo Commerce","Bank Seabank Indonesia","Bank Bukopin","Bank Muamalat","Bank Sinarmas","Bank Maybank Indonesia","Bank Commonwealth"];
 const wallets=["DANA","GoPay","LinkAja","ShopeePay"];
 window.bankChoices={banks,wallets};

 if(hasSaved && !editMode){
   const typeLabel=b.type==="ewallet"?"E-Wallet":"Rekening Bank";
   const masked=String(b.number).length>4 ? "•••• " + String(b.number).slice(-4) : String(b.number);
   document.getElementById("modalBody").innerHTML=`
     <div class="finance-head">
       <div class="finance-icon">🏦</div>
       <h3>Rekening Bank Tersimpan</h3>
       <p>Rekening yang tersimpan dan terhubung dengan akun Anda.</p>
       <button class="close" aria-label="Tutup" onclick="closeModal()">×</button>
     </div>
     <div class="finance-content">
       <div style="border:1px solid #dbe7f5;border-radius:18px;padding:18px;background:linear-gradient(145deg,#f8fbff,#eef6ff);margin-bottom:16px">
         <div style="font-size:11px;color:#728197;font-weight:800;margin-bottom:7px">JENIS</div>
         <div style="font-size:15px;color:#17233d;font-weight:900;margin-bottom:15px">${typeLabel}</div>
         <div style="font-size:11px;color:#728197;font-weight:800;margin-bottom:7px">BANK / E-WALLET</div>
         <div style="font-size:16px;color:#0755b8;font-weight:900;margin-bottom:15px">${b.bank||"-"}</div>
         <div style="font-size:11px;color:#728197;font-weight:800;margin-bottom:7px">NOMOR REKENING</div>
         <div style="font-size:16px;color:#17233d;font-weight:900;letter-spacing:.5px;margin-bottom:15px">${masked}</div>
         <div style="font-size:11px;color:#728197;font-weight:800;margin-bottom:7px">NAMA PEMILIK</div>
         <div style="font-size:16px;color:#17233d;font-weight:900">${b.owner||"-"}</div>
       </div>
       <button class="primary" onclick="openBank(true)">Ubah Rekening</button>
     </div>`;
   showModal();
   return;
 }

 document.getElementById("modalBody").innerHTML=`
   <div class="finance-head">
     <div class="finance-icon">🏦</div>
     <h3>Tambah Rekening Bank</h3>
     <p>Tambahkan rekening yang akan digunakan untuk penarikan dana.</p>
     <button class="close" aria-label="Tutup" onclick="closeModal()">×</button>
   </div>
   <div class="finance-content">
     <label>Jenis Pencairan</label>
     <select id="bankType" onchange="renderBankAccountOptions()">
       <option value="bank" ${(!b.type||b.type==="bank")?"selected":""}>Rekening Bank</option>
       <option value="ewallet" ${b.type==="ewallet"?"selected":""}>E-Wallet</option>
     </select>
     <label>Nama Bank / E-Wallet</label>
     <select id="bankName"></select>
     <label>Nomor Rekening / Nomor E-Wallet</label>
     <input id="bankNumber" inputmode="numeric" value="${b.number||""}" placeholder="Nomor rekening atau nomor HP">
     <label>Nama Pemilik</label>
     <input id="bankOwner" value="${b.owner||nameOf()}" placeholder="Nama pemilik rekening">
     <button class="primary" onclick="saveBank()">Simpan Rekening</button>
   </div>`;
 renderBankAccountOptions();
 showModal();
}
function renderBankAccountOptions(){
 const type=document.getElementById("bankType")?.value||"bank";
 const sel=document.getElementById("bankName");
 if(!sel)return;
 const current=state.bank?.bank||"";
 const arr=type==="ewallet"?window.bankChoices.wallets:window.bankChoices.banks;
 sel.innerHTML=arr.map(x=>`<option ${x===current?"selected":""}>${x}</option>`).join("");
}
async function loadBankAccountFromSupabase(){
 if(!currentUser?.id)return false;
 try{
   const {data,error}=await sb.from("bank_accounts")
     .select("id,user_id,bank_name,account_number,account_name,created_at")
     .eq("user_id",currentUser.id)
     .order("created_at",{ascending:false})
     .limit(1);

   if(error){
     console.warn("Gagal membaca bank_accounts:",error);
     return false;
   }

   const row=Array.isArray(data)&&data.length?data[0]:null;
   if(row){
     state.bank={
       type: state.bank?.type || "bank",
       bank: row.bank_name || "",
       number: row.account_number || "",
       owner: row.account_name || "",
       id: row.id
     };
     try{save();}catch(_){}
     return true;
   }

   state.bank=null;
   return false;
 }catch(e){
   console.warn("Bank account Supabase tidak dapat dimuat:",e);
   return false;
 }
}

async function saveBank(){
 const type=document.getElementById("bankType")?.value||"bank";
 const bank=document.getElementById("bankName")?.value||"";
 const number=document.getElementById("bankNumber")?.value.trim()||"";
 const owner=document.getElementById("bankOwner")?.value.trim()||"";

 if(!number||!owner)return toast("Lengkapi data rekening.");
 if(!currentUser?.id)return toast("Sesi akun belum siap. Silakan masuk kembali.");

 const btn=document.querySelector("#modalBody .primary");
 if(btn){btn.disabled=true;btn.textContent="Menyimpan...";}

 try{
   const payload={
     user_id:String(currentUser.id),
     bank_name:bank,
     account_number:number,
     account_name:owner
   };

   // Cari rekening milik UID aktif. Jika sudah ada, update row tersebut;
   // jika belum ada, buat row baru. Tidak menyentuh rekening member lain.
   const {data:existing,error:findError}=await sb.from("bank_accounts")
     .select("id")
     .eq("user_id",currentUser.id)
     .order("created_at",{ascending:false})
     .limit(1);

   if(findError){
     console.error("Gagal mencari rekening:",findError);
     toast("Rekening gagal disimpan ke database.");
     return false;
   }

   let savedRow=null;
   if(Array.isArray(existing)&&existing.length&&existing[0]?.id){
     const {data,error}=await sb.from("bank_accounts")
       .update(payload)
       .eq("id",existing[0].id)
       .eq("user_id",currentUser.id)
       .select("id,user_id,bank_name,account_number,account_name,created_at")
       .single();

     if(error){
       console.error("Gagal memperbarui rekening:",error);
       toast("Rekening gagal disimpan ke database.");
       return false;
     }
     savedRow=data;
   }else{
     const {data,error}=await sb.from("bank_accounts")
       .insert(payload)
       .select("id,user_id,bank_name,account_number,account_name,created_at")
       .single();

     if(error){
       console.error("Gagal menyimpan rekening:",error);
       toast("Rekening gagal disimpan ke database.");
       return false;
     }
     savedRow=data;
   }

   state.bank={
     type,
     bank:savedRow?.bank_name || bank,
     number:savedRow?.account_number || number,
     owner:savedRow?.account_name || owner,
     id:savedRow?.id || state.bank?.id || null
   };

   save();
   closeModal();
   toast("Rekening / e-wallet berhasil disimpan.");
   return true;
 }catch(e){
   console.error("Exception penyimpanan rekening:",e);
   toast("Terjadi kesalahan saat menyimpan rekening.");
   return false;
 }finally{
   if(btn){btn.disabled=false;btn.textContent="Simpan Rekening";}
 }
}
function openPassword(){
 document.getElementById("modalTitle").textContent="Ganti Password";
 document.getElementById("modalBody").innerHTML=`
 <label>Password Baru</label><input id="newPass" type="password" minlength="6" placeholder="Minimal 6 karakter">
 <label>Ulangi Password</label><input id="newPass2" type="password" minlength="6" placeholder="Ulangi password">
 <button class="primary" onclick="changePassword()">Update Password</button>`;
 showModal();
}
async function changePassword(){
 const a=document.getElementById("newPass").value,b=document.getElementById("newPass2").value;
 if(a.length<6)return toast("Password minimal 6 karakter.");
 if(a!==b)return toast("Konfirmasi password tidak sama.");
 const {error}=await sb.auth.updateUser({password:a});
 if(error)return toast(error.message||"Gagal mengubah password.");
 closeModal();toast("Password berhasil diubah.");
}
function openPin(){
 document.getElementById("modalTitle").textContent="Ganti PIN";
 document.getElementById("modalBody").innerHTML=`
 <label>PIN Lama</label><input id="oldPin" type="password" inputmode="numeric" maxlength="6" placeholder="6 digit">
 <label>PIN Baru</label><input id="newPin" type="password" inputmode="numeric" maxlength="6" placeholder="6 digit">
 <button class="primary" onclick="changePin()">Update PIN</button>`;
 showModal();
}
async function changePin(){
 const oldPin=document.getElementById("oldPin").value,newPin=document.getElementById("newPin").value;
 if(!/^\d{6}$/.test(oldPin)||!/^\d{6}$/.test(newPin))return toast("PIN harus 6 digit.");
 const oldHash=await hashPin(oldPin);
 const stored=currentUser?.user_metadata?.pin_penarikan_hash;
 if(stored&&stored!==oldHash)return toast("PIN lama salah.");
 const newHash=await hashPin(newPin);
 const {data,error}=await sb.auth.updateUser({data:{pin_penarikan_hash:newHash}});
 if(error)return toast(error.message||"Gagal mengubah PIN.");
 currentUser=data.user;closeModal();toast("PIN berhasil diubah.");
}
async function logout(){
 await stopWithdrawalLiveSync();
 await sb.auth.signOut();currentUser=null;
 state.balance=0; state.tx=[]; state.bank=null; state.vouchers=0;
 document.getElementById("appView").classList.add("hidden");document.getElementById("authView").classList.remove("hidden");
 setAuthMode("login");document.getElementById("loginForm").reset();toast("Kamu sudah keluar.");
}
sb.auth.onAuthStateChange((event,session)=>{
 if(session?.user&&!currentUser){
   paintCachedCompletedCountForUser(session.user);
   startApp(session.user).then(()=>{
     forceCompletedCountAfterLogin(session.user);
   }).catch(()=>{});
 }
 if(event==="SIGNED_OUT"){
   clearInterval(__bhDepositSyncTimer);
   __bhDepositSyncTimer=null;
   currentUser=null;
 }
});
(async()=>{
 try{
   const {data}=await sb.auth.getSession();
   if(data?.session?.user){
     // Counter terakhir langsung tampil; startApp tetap memverifikasi
     // angka tersebut ke Supabase setelahnya.
     paintCachedCompletedCountForUser(data.session.user);
     await startApp(data.session.user);
     await forceCompletedCountAfterLogin(data.session.user);
   }
 }catch(e){console.error(e)}
})();
