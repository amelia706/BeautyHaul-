
let deferredInstallPrompt = null;

window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault();
  deferredInstallPrompt = event;
});

async function downloadAppFile(){
  const btn = document.getElementById('downloadAppBtn');
  const original = btn ? btn.innerHTML : '⬇ Download';

  // If the site is installed as a PWA-capable app, use the native install dialog.
  if (deferredInstallPrompt) {
    deferredInstallPrompt.prompt();
    try { await deferredInstallPrompt.userChoice; } catch(e) {}
    deferredInstallPrompt = null;
    if (btn) btn.innerHTML = '✓ Terpasang';
    setTimeout(() => { if (btn) btn.innerHTML = original; }, 1800);
    return;
  }

  // Fallback: download the current, complete BeautyHaul HTML application.
  try {
    const source = '<!doctype html>\n' + document.documentElement.outerHTML;
    const blob = new Blob([source], {type:'text/html;charset=utf-8'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'BeautyHaul-App.html';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);

    if (btn) btn.innerHTML = '✓ Berhasil';
    setTimeout(() => { if (btn) btn.innerHTML = original; }, 1800);
  } catch (error) {
    if (btn) btn.innerHTML = original;
    alert('Aplikasi belum dapat diunduh. Silakan coba lagi.');
  }
}
