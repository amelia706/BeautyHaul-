# BeautyHaul WebView app - no custom shrinking rules required.
