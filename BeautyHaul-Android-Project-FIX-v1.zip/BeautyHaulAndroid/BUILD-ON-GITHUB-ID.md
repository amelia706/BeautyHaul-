# Cara menghasilkan APK tanpa Android Studio

Project ini sudah disiapkan dengan GitHub Actions. Setelah folder project di-upload ke repository GitHub:

1. Buka repository.
2. Masuk ke tab **Actions**.
3. Pilih **Build BeautyHaul APK**.
4. Tekan **Run workflow** (jika belum otomatis berjalan setelah push).
5. Tunggu sampai status hijau/Success.
6. Buka hasil workflow dan bagian **Artifacts**.
7. Download `BeautyHaul-debug-apk`.
8. Ekstrak ZIP artifact tersebut untuk mendapatkan `app-debug.apk`.
9. Instal APK di HP Android.

Setelah APK terinstal, ikon launcher menggunakan logo BeautyHaul dan nama aplikasi **BeautyHaul**.
