# BeautyHaul Android APK

Project Android WebView berbasis ZIP `beautyhaul-lupa-password-FIX-v4.zip`.

## Isi
- Nama aplikasi: BeautyHaul
- Application ID: `com.beautyhaul.app`
- Ikon launcher: logo BeautyHaul biru
- Website dikemas ke dalam APK pada `app/src/main/assets/www/`
- Internet permission aktif agar Supabase dan layanan eksternal tetap dapat digunakan.

## Build APK
Buka folder ini di Android Studio terbaru, lalu Build > Generate App Bundles or APKs > Generate APKs.

Project menggunakan Android Gradle Plugin 9.3.0 dan Gradle 9.6.1, dengan compile/target SDK 36.

## Catatan penting
APK ini adalah wrapper WebView dari website yang sudah ada. Edge Function `reset-password` tetap berada di Supabase; APK tidak menyimpan secret Supabase service-role.
